import hashlib, json, os, pathlib, subprocess, sys, time
E = pathlib.Path(__file__).parent
C = json.loads((E / 'gate-config.json').read_text())
records = json.loads((E / 'narrow-records.json').read_text())
for module in C['freshActualDag']:
    record = records.get(module)
    source = pathlib.Path(C['root']) / (module.replace('.', '/') + '.lean')
    if not record or record['returncode'] != 0 or hashlib.sha256(source.read_bytes()).hexdigest() != record['sourceSha256']:
        raise RuntimeError('Fresh actual DAG narrow is not current GREEN: ' + module)
env = os.environ.copy()
env['LEAN_PATH'] = C['leanPath']
for key in ['LEAN_SRC_PATH', 'LEAN_ABORT_ON_PANIC', 'LEAN_SYSROOT']:
    env.pop(key, None)
source = E / 'ReachableInternalFullRaw.lean'
args = [C['compiler'], *C['arguments'], '--root=' + str(E), str(source)]
version = 1 + sum(1 for _ in E.glob('full-raw-attempt*.log'))
log = E / ('full-raw-attempt' + str(version) + '.log')
start = time.monotonic()
with log.open('w') as stream:
    result = subprocess.run(args, cwd=C['root'], env=env, stdout=stream, stderr=subprocess.STDOUT)
record = {'args': args, 'sourceSha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'returncode': result.returncode, 'seconds': time.monotonic() - start, 'log': str(log), 'scope': 'ALL declarations in SIX NEW defining modules; EACHroot+union independent, type+value, opaque/private/compiler/ctors/full paths, frozen exact old75 baseline; no frozen628/old465/world340 FULL rerun'}
(E / ('full-raw-attempt' + str(version) + '-result.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
if result.returncode:
    print(log.read_text(), flush=True)
    sys.exit(result.returncode)
lease = subprocess.run([sys.executable, str(E / 'run_narrow.py'), '--snapshot-after'], cwd=C['root'])
if lease.returncode:
    sys.exit(lease.returncode)
print('SIX_NEW_MODULE_FULL_RAW_AND_STRICT_LEASE_GREEN', flush=True)
