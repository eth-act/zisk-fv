import hashlib, json, os, pathlib, subprocess, sys, time
E = pathlib.Path(__file__).parent
C = json.loads((E / 'gate-config.json').read_text())
R = pathlib.Path(C['root'])
O = pathlib.Path(C['overlay'])

def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def borrowed_snapshot():
    files = {}
    for root in C['borrowRoots']:
        root = pathlib.Path(root)
        for path in root.rglob('*'):
            if not path.is_file() or not ('.olean' in path.name or path.name.endswith('.ir')):
                continue
            resolved = path.resolve()
            if '/zisk-fv-m-inputs/' in str(resolved) or '/zisk-fv-api-loads-approved/' in str(resolved):
                raise RuntimeError('Forbidden borrowed-cache resolution: ' + str(path))
            files[str(path)] = {'resolved': str(resolved), 'sha256': digest(path), 'size': path.stat().st_size}
    for entry in C['generatedInputs']:
        path = pathlib.Path(entry['path'])
        if digest(path) != entry['sha256']:
            raise RuntimeError('Generated current-source mismatch: ' + str(path))
        files[str(path)] = {'resolved': str(path.resolve()), 'sha256': digest(path), 'size': path.stat().st_size}
    for item in C['ciRecipe']:
        for label, root in [('current', R), ('lender', pathlib.Path(C['lenderRoot']))]:
            path = root / item['source']
            if digest(path) != item[label]:
                raise RuntimeError('Source/CI recipe changed: ' + str(path))
            files[str(path)] = {'resolved': str(path.resolve()), 'sha256': digest(path), 'size': path.stat().st_size}
    if digest(pathlib.Path(C['compiler'])) != C['compilerSha256']:
        raise RuntimeError('Compiler identity mismatch')
    return files

if '--snapshot-after' in sys.argv:
    before = json.loads((E / 'borrowed-before.json').read_text())
    after = borrowed_snapshot()
    (E / 'borrowed-after.json').write_text(json.dumps(after, indent=2) + '\n')
    if before != after:
        raise RuntimeError('Strict borrowed-input lease changed')
    print('STRICT_BORROWED_SOURCE_CI_COMPILER_OBJECT_LEASE_PASS', len(after), flush=True)
    sys.exit(0)

if not (E / 'borrowed-before.json').exists():
    before = borrowed_snapshot()
    (E / 'borrowed-before.json').write_text(json.dumps(before, indent=2) + '\n')
    print('STRICT_BEFORE_LEASE', len(before), flush=True)

records = json.loads((E / 'narrow-records.json').read_text()) if (E / 'narrow-records.json').exists() else {}
env = os.environ.copy()
env['LEAN_PATH'] = C['leanPath']
for key in ['LEAN_SRC_PATH', 'LEAN_ABORT_ON_PANIC', 'LEAN_SYSROOT']:
    env.pop(key, None)
only = next((set(arg[len('--only='):].split(',')) for arg in sys.argv[1:] if arg.startswith('--only=')), None)
failed = []
for module in C['freshActualDag']:
    if only is not None and module not in only:
        continue
    source = R / (module.replace('.', '/') + '.lean')
    output = O / (module.replace('.', '/') + '.olean')
    unavailable = [name for name in C['sourceDag'][module]['imports'] if name in C['freshActualDag'] and not (O / (name.replace('.', '/') + '.olean')).exists()]
    if unavailable:
        failed.append(module)
        print('BLOCKED_BY_FAILED_FRESH_IMPORT', module, unavailable, flush=True)
        continue
    deps = {name: digest(O / (name.replace('.', '/') + '.olean')) for name in C['sourceDag'][module]['imports'] if name in C['freshActualDag']}
    current_source = digest(source)
    previous = records.get(module)
    if previous and previous['returncode'] != 0 and previous['sourceSha256'] == current_source and previous['freshDependencies'] == deps:
        failed.append(module)
        print('KNOWN_UNCHANGED_FAILURE_NOT_RERUN', module, previous['log'], flush=True)
        continue
    if previous and previous['returncode'] == 0 and previous['sourceSha256'] == current_source and previous['freshDependencies'] == deps and output.exists() and previous['outputSha256'] == digest(output):
        print('OWN_FRESH_EXACT_REUSE', module, flush=True)
        continue
    output.parent.mkdir(parents=True, exist_ok=True)
    stem = output.name[:-6]
    for file in output.parent.glob(stem + '.*'):
        if file.is_symlink():
            raise RuntimeError('Fresh output unexpectedly borrowed: ' + str(file))
        if file.is_file():
            file.unlink()
    version = 1 + sum(1 for _ in E.glob(module + '.attempt*.log'))
    log = E / (module + '.attempt' + str(version) + '.log')
    args = [C['compiler'], *C['arguments'], '--root=' + str(R), '-o', str(output), str(source)]
    start = time.monotonic()
    print('COMPILE', module, flush=True)
    with log.open('w') as stream:
        result = subprocess.run(args, cwd=R, env=env, stdout=stream, stderr=subprocess.STDOUT)
    record = {'module': module, 'source': str(source), 'sourceSha256': current_source, 'freshDependencies': deps, 'args': args, 'returncode': result.returncode, 'seconds': time.monotonic() - start, 'log': str(log), 'outputSha256': digest(output) if result.returncode == 0 and output.exists() else None}
    records[module] = record
    (E / 'narrow-records.json').write_text(json.dumps(records, indent=2) + '\n')
    print('RESULT', module, result.returncode, round(record['seconds'], 3), str(log), flush=True)
    if result.returncode:
        print(log.read_text(), flush=True)
        failed.append(module)
if failed:
    print('NARROW_FAILED_MODULES', failed, flush=True)
    sys.exit(1)
print('SCOPED_NARROW_TARGETS_GREEN' if only is not None else 'ALL_ACTUAL_FRESH_DAG_NARROW_GREEN', len(only) if only is not None else len(C['freshActualDag']), 'EXACT_TARGETS', len(C['exact15Targets']), flush=True)
