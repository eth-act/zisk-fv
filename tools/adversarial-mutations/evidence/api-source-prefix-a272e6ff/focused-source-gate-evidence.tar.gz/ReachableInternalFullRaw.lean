import ZiskFv.Compliance.TraceLevelExport.CheckedPhysicalSourceCuts
import ZiskFv.Compliance.TraceLevelExport.SourceHeadRegisterPcPlatform
import ZiskFv.Compliance.TraceLevelExport.SourceHeadActualRegisterPrefix
import ZiskFv.Compliance.TraceLevelExport.SourceMutableMemoryPresenceSourceFlags
import ZiskFv.Compliance.TraceLevelExport.SourceMutableMemoryPresence
import ZiskFv.Compliance.TraceLevelExport.NarrowLoadProviderObstruction
import Lean
open Lean Meta Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace ReachableInternal417RawAudit

structure Graph where
  visited : NameSet := {}
  axioms : NameSet := {}
  parents : NameMap (Array Name) := {}

/-- Full union graph, no namespace/private/compiler/foreign-axiom cutoffs. -/
partial def build (env : Environment) (roots : Array Name) : Except String Graph :=
  go roots.toList (Graph.mk (roots.foldl (fun s n => s.insert n) {}) {} {})
where
  go (todo : List Name) (g : Graph) : Except String Graph := do
    match todo with
    | [] => return g
    | declName :: rest =>
      let some ci := env.checked.get.find? declName | throw s!"Missing kernel constant: {declName}"
      let refs := ci.type.getUsedConstants.toList ++
        (match ci with
        | .defnInfo v => v.value.getUsedConstants.toList
        | .thmInfo v => v.value.getUsedConstants.toList
        | .opaqueInfo v => v.value.getUsedConstants.toList
        | .inductInfo v => v.ctors
        | _ => [])
      let refs := (refs.foldl (fun (s : NameSet) n => s.insert n) {}).toList.toArray
      let axioms := match ci with
        | .axiomInfo _ => g.axioms.insert declName
        | _ => g.axioms
      let g := Graph.mk g.visited axioms g.parents
      let (g, next) := refs.foldl (fun (g, next) child =>
        let parents := g.parents.insert child (((g.parents.find? child).getD #[]).push declName)
        if g.visited.contains child then
          (Graph.mk g.visited g.axioms parents, next)
        else
          (Graph.mk (g.visited.insert child) g.axioms parents, child :: next)) (g, [])
      go (next ++ rest) g

/-- Reverse reachability computes each root's complete closure even through
cycles. The next map gives a checked-edge path FROM that root TO the axiom. -/
partial def reaches (g : Graph) (leaf : Name) : NameSet × NameMap Name :=
  go [leaf] (({} : NameSet).insert leaf) {}
where
  go (todo : List Name) (seen : NameSet) (next : NameMap Name) : NameSet × NameMap Name :=
    match todo with
    | [] => (seen, next)
    | child :: rest =>
      let (seen, next, pending) := ((g.parents.find? child).getD #[]).foldl
        (fun (seen, next, pending) parent =>
          if seen.contains parent then (seen, next, pending)
          else (seen.insert parent, next.insert parent child, parent :: pending)) (seen, next, [])
      go (pending ++ rest) seen next

partial def path (next : NameMap Name) (start leaf : Name) : Except String (List Name) := do
  if start == leaf then return [leaf]
  let some child := next.find? start | throw s!"Missing dependency path: {start} -> {leaf}"
  return start :: (← path next child leaf)

def sorted (s : NameSet) : Array Name :=
  s.toList.toArray.qsort (fun a b => a.toString < b.toString)

def collect (env : Environment) (roots : Array Name) : Lean.CollectAxioms.State :=
  roots.foldl (fun s n => ((Lean.CollectAxioms.collect n).run env).run s |>.snd) {}

end ReachableInternal417RawAudit

run_cmd do
  let env ← getEnv
  let modules := #[`ZiskFv.Compliance.TraceLevelExport.CheckedPhysicalSourceCuts, `ZiskFv.Compliance.TraceLevelExport.SourceHeadRegisterPcPlatform, `ZiskFv.Compliance.TraceLevelExport.SourceHeadActualRegisterPrefix, `ZiskFv.Compliance.TraceLevelExport.SourceMutableMemoryPresenceSourceFlags, `ZiskFv.Compliance.TraceLevelExport.SourceMutableMemoryPresence, `ZiskFv.Compliance.TraceLevelExport.NarrowLoadProviderObstruction]
  let moduleRoots := env.constants.toList.toArray.filterMap fun entry => do
    let index ← env.getModuleIdxFor? entry.1
    let moduleName ← env.header.moduleNames[index.toNat]?
    if modules.contains moduleName then some entry.1 else none
  for moduleName in modules do
    let localRoots := moduleRoots.filter fun n =>
      match env.getModuleIdxFor? n with
      | some index => env.header.moduleNames[index.toNat]? == some moduleName
      | none => false
    unless !localRoots.isEmpty do throwError "Missing source-only module: {moduleName}"
    logInfo m!"ALL_CURRENT_MODULE_DECLARATIONS {moduleName}: {localRoots.size}"
  let roots := moduleRoots
  let graph ← match ReachableInternal417RawAudit.build env roots with
    | .ok result => pure result
    | .error message => throwError message
  let actual := ReachableInternal417RawAudit.sorted graph.axioms
  let independent := (ReachableInternal417RawAudit.collect env roots).axioms.qsort (fun a b => a.toString < b.toString)
  unless actual == independent do throwError "Full independent UNION mismatch"
  let standard := #[`Classical.choice, `Quot.sound, `propext]
  let generic := (ReachableInternal417RawAudit.collect env #[`ZiskFv.Compliance.chainedSailStates]).axioms.qsort
    (fun a b => a.toString < b.toString)
  let exactOld75 := #[`Classical.choice, `Quot.sound, `cancel_reservation, `get_16_random_bits, `load_reservation, `match_reservation, `plat_term_write, `propext, `riscv_f16Add, `riscv_f16Div, `riscv_f16Eq, `riscv_f16Le, `riscv_f16Le_quiet, `riscv_f16Lt, `riscv_f16Lt_quiet, `riscv_f16Mul, `riscv_f16MulAdd, `riscv_f16Sqrt, `riscv_f16Sub, `riscv_f16ToF32, `riscv_f16ToF64, `riscv_f16ToI32, `riscv_f16ToI64, `riscv_f16ToUi32, `riscv_f16ToUi64, `riscv_f16roundToInt, `riscv_f32Add, `riscv_f32Div, `riscv_f32Eq, `riscv_f32Le, `riscv_f32Le_quiet, `riscv_f32Lt, `riscv_f32Lt_quiet, `riscv_f32Mul, `riscv_f32MulAdd, `riscv_f32Sqrt, `riscv_f32Sub, `riscv_f32ToBF16, `riscv_f32ToF16, `riscv_f32ToF64, `riscv_f32ToI32, `riscv_f32ToI64, `riscv_f32ToUi32, `riscv_f32ToUi64, `riscv_f32roundToInt, `riscv_f64Add, `riscv_f64Div, `riscv_f64Eq, `riscv_f64Le, `riscv_f64Le_quiet, `riscv_f64Lt, `riscv_f64Lt_quiet, `riscv_f64Mul, `riscv_f64MulAdd, `riscv_f64Sqrt, `riscv_f64Sub, `riscv_f64ToF16, `riscv_f64ToF32, `riscv_f64ToI32, `riscv_f64ToI64, `riscv_f64ToUi32, `riscv_f64ToUi64, `riscv_f64roundToInt, `riscv_i32ToF16, `riscv_i32ToF32, `riscv_i32ToF64, `riscv_i64ToF16, `riscv_i64ToF32, `riscv_i64ToF64, `riscv_ui32ToF16, `riscv_ui32ToF32, `riscv_ui32ToF64, `riscv_ui64ToF16, `riscv_ui64ToF32, `riscv_ui64ToF64].qsort (fun a b => a.toString < b.toString)
  unless generic == exactOld75 do throwError "Current generic baseline differs from frozen checked old75"
  logInfo m!"ALL_NEW_CURRENT_ROOT_COUNT {roots.size}"
  logInfo m!"ALL_NEW_CURRENT_KERNEL_CONSTANT_COUNT {graph.visited.toList.length}"
  logInfo m!"CURRENT_FULL_UNFILTERED_UNION {actual}"
  logInfo m!"CURRENT_GENERIC_SAIL_BASELINE {generic}"
  logInfo m!"UNION_MINUS_GENERIC {actual.filter (fun n => !generic.contains n)}"
  unless actual.all generic.contains do throwError "Trust beyond actual old generic Sail75"
  let mut perRoot : NameMap NameSet := {}
  let mut paths : NameMap (NameMap Name) := {}
  for axiomName in actual do
    let (reachable, next) := ReachableInternal417RawAudit.reaches graph axiomName
    paths := paths.insert axiomName next
    for declName in roots do
      if reachable.contains declName then
        perRoot := perRoot.insert declName (((perRoot.find? declName).getD {}).insert axiomName)
  for declName in roots.qsort (fun a b => a.toString < b.toString) do
    let axioms := ReachableInternal417RawAudit.sorted ((perRoot.find? declName).getD {})
    let independent := (ReachableInternal417RawAudit.collect env #[declName]).axioms.qsort
      (fun a b => a.toString < b.toString)
    unless axioms == independent do throwError "EVERY-root collector mismatch: {declName}"
    logInfo m!"EVERY_CURRENT_ROOT_FULL_RAW {declName}: {axioms}"
    logInfo m!"EVERY_CURRENT_ROOT_STD3 {declName}: {axioms.all standard.contains}"
    logInfo m!"EVERY_CURRENT_ROOT_WITHIN_GENERIC {declName}: {axioms.all generic.contains}"
    for axiomName in axioms do
      let some next := paths.find? axiomName | throwError "Missing axiom path index"
      let path ← match ReachableInternal417RawAudit.path next declName axiomName with
        | .ok result => pure result
        | .error message => throwError message
      logInfo m!"EVERY_CURRENT_ROOT_AXIOM_PATH {declName} -> {axiomName}: {path}"
  for forbidden in #[`ZiskFv.Compliance.root_soundness,
      `ZiskFv.Compliance.stepSound_of_evidence, `Lean.ofReduceBool, `Lean.trustCompiler,
      `sorryAx] do
    unless !graph.visited.contains forbidden do throwError "Forbidden Root-value/native/sorry dependency: {forbidden}"
  logInfo "ALL_SIX_ACTUAL_NEW_MODULES_EACH_ROOT_AND_UNION_INDEPENDENT_FULL_RAW_PASS true"
