import Lean

open Lean

namespace RawDependencyObserver

def sorted (names : Array Name) : Array Name :=
  names.qsort (fun a b => a.toString < b.toString)

def rawState (env : Environment) (roots : Array Name) : Lean.CollectAxioms.State := Id.run do
  let mut state : Lean.CollectAxioms.State := {}
  for root in roots do
    state := ((Lean.CollectAxioms.collect root).run env).run state |>.snd
  return state

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def refs (ci : ConstantInfo) : Array Name × Array Name × Array Name :=
  let types := sorted ci.type.getUsedConstants
  let values := sorted ((ci.value? (allowOpaque := true)).map Expr.getUsedConstants |>.getD #[])
  let constructors := match ci with
    | .inductInfo info => sorted info.ctors.toArray
    | _ => #[]
  (types, values, constructors)

def merged (parts : Array Name × Array Name × Array Name) : Array Name := Id.run do
  let mut names : NameSet := {}
  for name in parts.1 ++ parts.2.1 ++ parts.2.2 do
    names := names.insert name
  return sorted names.toList.toArray

def isAxiom (ci : ConstantInfo) : Bool :=
  match ci with
  | .axiomInfo _ => true
  | _ => false

def observe (env : Environment) (target : Name) (directory : System.FilePath) : IO Unit := do
  let roots := sorted <| env.constants.fold (init := #[]) fun roots name _ =>
    if moduleOf env name == some target then roots.push name else roots
  if roots.isEmpty then
    throw (IO.userError s!"No elaborated declarations found in module {target}")
  IO.FS.createDirAll directory
  let graphFile ← IO.FS.Handle.mk (directory / "full-graph.jsonl") .write
  let mut todo := roots
  let mut seen : NameSet := roots.foldl (fun names name => names.insert name) {}
  let mut graph : Std.HashMap Name (Array Name) := {}
  let mut axioms : NameSet := {}
  let mut cursor := 0
  let mut edgeCount := 0
  while cursor < todo.size do
    let name := todo[cursor]!
    cursor := cursor + 1
    let some ci := env.checked.get.find? name
      | throw (IO.userError s!"Missing checked kernel declaration: {name}")
    let direct := refs ci
    let children := merged direct
    graph := graph.insert name children
    edgeCount := edgeCount + children.size
    if isAxiom ci then axioms := axioms.insert name
    graphFile.putStrLn <| Json.compress <| Json.mkObj [
      ("name", toJson name.toString), ("axiom", toJson (isAxiom ci)),
      ("type_refs", toJson (direct.1.map Name.toString)),
      ("value_refs", toJson (direct.2.1.map Name.toString)),
      ("constructor_refs", toJson (direct.2.2.map Name.toString))]
    for child in children do
      if !seen.contains child then
        seen := seen.insert child
        todo := todo.push child
  graphFile.flush
  let union := sorted axioms.toList.toArray
  let standardUnion := sorted (rawState env roots).axioms
  unless union == standardUnion do
    throw (IO.userError s!"Complete graph and Lean.collectAxioms disagree: graph={union}, Lean={standardUnion}")
  let rootsFile ← IO.FS.Handle.mk (directory / "all-roots.jsonl") .write
  for root in roots do
    let mut work := #[root]
    let mut visited : NameSet := ({} : NameSet).insert root
    let mut parent : Std.HashMap Name Name := {}
    let mut index := 0
    let mut localAxioms : NameSet := {}
    while index < work.size do
      let name := work[index]!
      index := index + 1
      if axioms.contains name then localAxioms := localAxioms.insert name
      let some children := graph[name]?
        | throw (IO.userError s!"Missing complete graph node: {name}")
      for child in children do
        if !visited.contains child then
          visited := visited.insert child
          parent := parent.insert child name
          work := work.push child
    let actual := sorted localAxioms.toList.toArray
    let standard := sorted (rawState env #[root]).axioms
    unless actual == standard do
      throw (IO.userError s!"Per-root graph and Lean.collectAxioms disagree for {root}: graph={actual}, Lean={standard}")
    let mut paths : Array Json := #[]
    for axiomName in actual do
      let mut path := #[axiomName]
      let mut name := axiomName
      while name != root do
        let some previous := parent[name]?
          | throw (IO.userError s!"Missing dependency path from {root} to {axiomName}")
        path := path.push previous
        name := previous
      paths := paths.push <| Json.mkObj [
        ("axiom", toJson axiomName.toString),
        ("path", toJson (path.reverse.map Name.toString))]
    rootsFile.putStrLn <| Json.compress <| Json.mkObj [
      ("root", toJson root.toString), ("reachable_nodes", toJson work.size),
      ("raw_axioms", toJson (actual.map Name.toString)), ("axiom_paths", toJson paths)]
  rootsFile.flush
  let summary := Json.mkObj [
    ("module", toJson target.toString), ("root_count", toJson roots.size),
    ("roots", toJson (roots.map Name.toString)),
    ("nodes", toJson todo.size), ("edges", toJson edgeCount),
    ("raw_axiom_union", toJson (union.map Name.toString)),
    ("coverage", toJson "Every module declaration, including private/compiler declarations; complete checked kernel type/value and inductive-constructor dependency closure; no namespace pruning or axiom allowlist"),
    ("cross_check", toJson "Union and EVERY individual root agree with the installed Lean.collectAxioms implementation")]
  IO.FS.writeFile (directory / "summary.json") (summary.pretty ++ "\n")
  IO.println summary.pretty

end RawDependencyObserver

unsafe def main (args : List String) : IO UInt32 := do
  Lean.initSearchPath (← Lean.findSysroot)
  match args with
  | [target, directory] =>
    Lean.withImportModules #[{ module := target.toName }] {} fun env => do
      RawDependencyObserver.observe env target.toName directory
      return 0
  | _ => throw (IO.userError "Expected MODULE OUTPUT_DIRECTORY")
