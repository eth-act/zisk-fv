import Mathlib

set_option linter.all false

namespace Extraction.LookupWiring

/-!
Lossless, constraint-linked extraction of gsum lookup wiring.

A `ValidatedLink` contains a hint tuple only after its `constraint`
is definitionally equal to the standard template instantiated with
that tuple. Final-row links instead retain the exact group value,
global-sum accumulator, selector, and direct terms.
Hints which have no such link are represented only by their per-AIR
count; their tuple payload is deliberately withheld.
-/

inductive Expr where
  | constant (value : String)
  | witness (stage column : Nat) (rowOffset : Int)
  | fixed (column : Nat) (rowOffset : Int)
  | challenge (stage index : Nat)
  | airValue (index : Nat)
  | airGroupValue (index : Nat)
  | opaque (kind payload : String)
  | add (lhs rhs : Expr)
  | sub (lhs rhs : Expr)
  | mul (lhs rhs : Expr)
  | neg (value : Expr)
  deriving Repr, DecidableEq

structure Slot where
  name : String
  value : Expr

structure HintTuple where
  hintIndex : Nat
  piop : String
  proves : Bool
  busId : Expr
  multiplicity : Expr
  slots : List Slot

structure DerivedTuple where
  piop : String
  proves : Bool
  busId : Expr
  multiplicity : Expr
  slots : List Slot

inductive LinkShape where
  | direct
  | cluster2
  | gsumFinalRow
  | directZeroTail
  | cluster2ZeroTail
  | directAssumesNegForm
  | directAssumesNegFormZeroTail
  deriving Repr, DecidableEq

structure ConstraintOnly where
  air : String
  constraintIndex : Nat
  constraint : Expr
  reason : String

structure AirStatus where
  groupIndex : Nat
  airIndex : Nat
  group : String
  air : String
  emittedConstraintFile : Bool
  mixedConstraintCount : Nat
  unlinkedMixedConstraintCount : Nat
  gsumHintCount : Nat
  validatedLinkCount : Nat

def stdMix (alpha gamma busId : Expr) (slots : List Slot) : Expr :=
  match slots.reverse with
  | [] => .add busId gamma
  | first :: rest =>
    .add (.add (.mul (rest.foldl (fun acc slot => .add (.mul acc alpha) slot.value) first.value) alpha) busId) gamma

def literalZeroSlot : Slot → Bool
  | ⟨_, .constant "0"⟩ => true
  | _ => false

def zeroTailSlots (slots : List Slot) : List Slot :=
  (slots.reverse.dropWhile literalZeroSlot).reverse

def normalise : Expr → Expr
  | .add lhs rhs =>
    match normalise lhs, normalise rhs with
    | lhs, .constant "0" => lhs
    | .constant "0", rhs => rhs
    | lhs, rhs => .add lhs rhs
  | .sub lhs rhs =>
    match normalise lhs, normalise rhs with
    | lhs, .constant "0" => lhs
    | lhs, rhs => .sub lhs rhs
  | .mul lhs rhs =>
    match normalise lhs, normalise rhs with
    | lhs, .constant "1" => lhs
    | .constant "1", rhs => rhs
    | lhs, rhs => .mul lhs rhs
  | .neg value => .neg (normalise value)
  | value => value

def directTemplate (alpha gamma accumulator : Expr) (hint : HintTuple) : Expr :=
  if hint.proves then
    .sub (.mul accumulator (stdMix alpha gamma hint.busId hint.slots)) hint.multiplicity
  else
    .add (.mul accumulator (stdMix alpha gamma hint.busId hint.slots)) hint.multiplicity

def directZeroTailTemplate (alpha gamma accumulator : Expr) (hint : HintTuple) : Expr :=
  if hint.proves then
    .sub (.mul accumulator (stdMix alpha gamma hint.busId (zeroTailSlots hint.slots))) hint.multiplicity
  else
    .add (.mul accumulator (stdMix alpha gamma hint.busId (zeroTailSlots hint.slots))) hint.multiplicity

def assumesNegMultiplicity (hint : HintTuple) : Expr :=
  .sub (.constant "0") hint.multiplicity

def directAssumesNegFormTemplate (alpha gamma accumulator : Expr) (hint : HintTuple) : Expr :=
  .sub (.mul accumulator (stdMix alpha gamma hint.busId hint.slots)) (assumesNegMultiplicity hint)

def directAssumesNegFormZeroTailTemplate (alpha gamma accumulator : Expr) (hint : HintTuple) : Expr :=
  .sub (.mul accumulator (stdMix alpha gamma hint.busId (zeroTailSlots hint.slots))) (assumesNegMultiplicity hint)

def negSelector : Expr → Expr
  | .constant "1" => .constant "18446744069414584320"
  | value => .sub (.constant "0") value

def signedSelector (hint : HintTuple) : Expr :=
  if hint.proves then hint.multiplicity else negSelector hint.multiplicity

def cluster2Template (alpha gamma accumulator : Expr) (left right : HintTuple) : Expr :=
  let leftMix := stdMix alpha gamma left.busId left.slots
  let rightMix := stdMix alpha gamma right.busId right.slots
  .sub (.mul accumulator (.mul leftMix rightMix))
    (.add (.mul (signedSelector left) rightMix) (.mul (signedSelector right) leftMix))

def cluster2ZeroTailTemplate (alpha gamma accumulator : Expr) (left right : HintTuple) : Expr :=
  let leftMix := stdMix alpha gamma left.busId (zeroTailSlots left.slots)
  let rightMix := stdMix alpha gamma right.busId (zeroTailSlots right.slots)
  .sub (.mul accumulator (.mul leftMix rightMix))
    (.add (.mul (signedSelector left) rightMix) (.mul (signedSelector right) leftMix))

def addTerms : List Expr → Expr
  | [] => .constant "0"
  | first :: rest => rest.foldl Expr.add first

def gsumFinalRowTemplate (selector groupValue gsum : Expr) (directTerms : List Expr) : Expr :=
  .mul selector (.sub (.sub groupValue gsum) (addTerms directTerms))

def templateOf (shape : LinkShape) (alpha gamma accumulator : Expr)
    (hints : List HintTuple) (derivedTuples : List DerivedTuple) : Option Expr :=
  match shape, hints, derivedTuples with
  | .direct, [hint], [] => some (normalise (directTemplate alpha gamma accumulator hint))
  | .cluster2, [left, right], [] => some (normalise (cluster2Template alpha gamma accumulator left right))
  | .directZeroTail, [hint], [] => some (normalise (directZeroTailTemplate alpha gamma accumulator hint))
  | .cluster2ZeroTail, [left, right], [] => some (normalise (cluster2ZeroTailTemplate alpha gamma accumulator left right))
  | .directAssumesNegForm, [hint], [] => some (normalise (directAssumesNegFormTemplate alpha gamma accumulator hint))
  | .directAssumesNegFormZeroTail, [hint], [] => some (normalise (directAssumesNegFormZeroTailTemplate alpha gamma accumulator hint))
  | _, _, _ => none

structure ValidatedLink where
  air : String
  constraintIndex : Nat
  shape : LinkShape
  accumulator : Expr
  alpha : Expr
  gamma : Expr
  constraint : Expr
  template : Expr
  hints : List HintTuple
  derivedTuples : List DerivedTuple
  templateFromShape : templateOf shape alpha gamma accumulator hints derivedTuples = some template
  constraintEqualsTemplate : constraint = template

theorem ValidatedLink.constraintValidated (link : ValidatedLink) :
    templateOf link.shape link.alpha link.gamma link.accumulator
      link.hints link.derivedTuples = some link.constraint := by
  rw [link.constraintEqualsTemplate]
  exact link.templateFromShape

structure ValidatedFinalRow where
  air : String
  constraintIndex : Nat
  shape : LinkShape
  selector : Expr
  groupValue : Expr
  gsum : Expr
  directTerms : List Expr
  constraint : Expr
  template : Expr
  hints : List HintTuple
  templateFromTerms : normalise (gsumFinalRowTemplate selector groupValue gsum directTerms) = template
  constraintEqualsTemplate : constraint = template

theorem ValidatedFinalRow.constraintValidated (link : ValidatedFinalRow) :
    normalise (gsumFinalRowTemplate link.selector link.groupValue link.gsum link.directTerms) =
      link.constraint := by
  rw [link.constraintEqualsTemplate]
  exact link.templateFromTerms

namespace SourceSchema

inductive Kind where
  | fixed | witness | airValue | airGroupValue
  deriving BEq, DecidableEq, Repr

/-- Raw source declarations, not inferred operand names. Array declarations
retain their base index, rank and complete dimension roster. -/
structure Symbol where
  groupIndex : Option Nat
  airIndex : Option Nat
  name : String
  kind : Kind
  stage : Option Nat
  index : Nat
  dimensions : Nat
  lengths : List Nat
  deriving DecidableEq, Repr

structure Air where
  groupIndex : Nat
  airIndex : Nat
  groupName : String
  airName : String
  symbols : List Symbol
  deriving DecidableEq, Repr

def air_Dma : Air := ⟨0, 0, "Zisk", "Dma", [
  ⟨some 0, some 0, "sel_memcpy", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 0, "sel_memcmp", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 0, "sel_memset", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 0, "fill_byte", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 0, "sel_extended", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 0, "sel_inputcpy", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 0, "h_count", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 0, "count_lt_256", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 0, "l_count", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 0, "count_diff_chunks", .witness, some 1, 9, 1, [2]⟩,
  ⟨some 0, some 0, "h_dst64", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 0, "l_dst64", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 0, "dst_offset", .witness, some 1, 13, 0, []⟩,
  ⟨some 0, some 0, "main_step", .witness, some 1, 14, 0, []⟩,
  ⟨some 0, some 0, "h_src64", .witness, some 1, 15, 0, []⟩,
  ⟨some 0, some 0, "l_src64", .witness, some 1, 16, 0, []⟩,
  ⟨some 0, some 0, "src_offset", .witness, some 1, 17, 0, []⟩,
  ⟨some 0, some 0, "src_offset_after_pre", .witness, some 1, 18, 0, []⟩,
  ⟨some 0, some 0, "src64_inc_by_pre", .witness, some 1, 19, 0, []⟩,
  ⟨some 0, some 0, "use_pre", .witness, some 1, 20, 0, []⟩,
  ⟨some 0, some 0, "use_loop", .witness, some 1, 21, 0, []⟩,
  ⟨some 0, some 0, "use_post", .witness, some 1, 22, 0, []⟩,
  ⟨some 0, some 0, "pre_count", .witness, some 1, 23, 0, []⟩,
  ⟨some 0, some 0, "l_count64", .witness, some 1, 24, 0, []⟩,
  ⟨some 0, some 0, "pre_result_nz", .witness, some 1, 25, 0, []⟩,
  ⟨some 0, some 0, "post_result_nz", .witness, some 1, 26, 0, []⟩,
  ⟨some 0, some 0, "bus_pre_result", .witness, some 1, 27, 1, [2]⟩,
  ⟨some 0, some 0, "bus_post_result", .witness, some 1, 29, 1, [2]⟩,
  ⟨some 0, some 0, "loop_b0", .witness, some 1, 31, 0, []⟩,
  ⟨some 0, some 0, "loop_extended_arg", .witness, some 1, 32, 0, []⟩,
  ⟨some 0, some 0, "static_count", .witness, some 1, 33, 0, []⟩,
  ⟨some 0, some 0, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 0, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 0, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 0, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 0, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 0, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 0, "im_single", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 0, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
]⟩

def air_DmaMemCpy : Air := ⟨0, 1, "Zisk", "DmaMemCpy", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 1, "sel_memcpy", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 1, "sel_extended", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 1, "h_count", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 1, "count_lt_256", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 1, "l_count", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 1, "h_dst64", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 1, "l_dst64", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 1, "dst_offset", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 1, "main_step", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 1, "h_src64", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 1, "l_src64", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 1, "src_offset", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 1, "src_offset_after_pre", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 1, "src64_inc_by_pre", .witness, some 1, 13, 0, []⟩,
  ⟨some 0, some 1, "use_pre", .witness, some 1, 14, 0, []⟩,
  ⟨some 0, some 1, "use_loop", .witness, some 1, 15, 0, []⟩,
  ⟨some 0, some 1, "use_post", .witness, some 1, 16, 0, []⟩,
  ⟨some 0, some 1, "pre_count", .witness, some 1, 17, 0, []⟩,
  ⟨some 0, some 1, "l_count64", .witness, some 1, 18, 0, []⟩,
  ⟨some 0, some 1, "loop_b0", .witness, some 1, 19, 0, []⟩,
  ⟨some 0, some 1, "loop_extended_arg", .witness, some 1, 20, 0, []⟩,
  ⟨some 0, some 1, "static_count", .witness, some 1, 21, 0, []⟩,
  ⟨some 0, some 1, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 1, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 1, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 1, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 1, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 1, "im_single", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 1, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_DmaInputCpy : Air := ⟨0, 2, "Zisk", "DmaInputCpy", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 2, "sel_extended", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 2, "sel_inputcpy", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 2, "h_count", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 2, "count_lt_256", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 2, "l_count", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 2, "h_dst64", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 2, "l_dst64", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 2, "dst_offset", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 2, "main_step", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 2, "use_pre", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 2, "use_loop", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 2, "use_post", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 2, "pre_count", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 2, "l_count64", .witness, some 1, 13, 0, []⟩,
  ⟨some 0, some 2, "loop_b0", .witness, some 1, 14, 0, []⟩,
  ⟨some 0, some 2, "static_count", .witness, some 1, 15, 0, []⟩,
  ⟨some 0, some 2, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 2, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 2, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 2, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 2, "im_single", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 2, "im_single", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 2, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_Dma64Aligned : Air := ⟨0, 3, "Zisk", "Dma64Aligned", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 3, "src64", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 3, "seq_end", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 3, "previous_seq_end", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 3, "sel_memcpy", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 3, "sel_memeq", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 3, "sel_memset", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 3, "fill_byte", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 3, "sel_memcpy_count_load", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 3, "sel_inputcpy", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 3, "main_step", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 3, "dst64", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 3, "count64", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 3, "sel_op_from_1", .witness, some 1, 12, 1, [3]⟩,
  ⟨some 0, some 3, "l_value_chunks", .witness, some 1, 15, 2, [4, 2]⟩,
  ⟨some 0, some 3, "h_value_chunks", .witness, some 1, 23, 2, [4, 2]⟩,
  ⟨some 0, some 3, "sel_op_mem_load", .witness, some 1, 31, 1, [4]⟩,
  ⟨some 0, some 3, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 3, "im_cluster", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 3, "im_single", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 3, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_previous_seq_end", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_previous_dst64", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_previous_main_step", .airValue, some 1, 3, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_previous_count64", .airValue, some 1, 4, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_previous_flags", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_last_seq_end", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_last_dst64", .airValue, some 1, 7, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_last_main_step", .airValue, some 1, 8, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_last_count64", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.segment_last_flags", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.is_last_segment", .airValue, some 1, 11, 0, []⟩,
  ⟨some 0, some 3, "segment_previous_src64", .airValue, some 1, 12, 0, []⟩,
  ⟨some 0, some 3, "segment_last_src64", .airValue, some 1, 13, 0, []⟩,
  ⟨some 0, some 3, "segment_previous_fill_byte", .airValue, some 1, 14, 0, []⟩,
  ⟨some 0, some 3, "segment_last_fill_byte", .airValue, some 1, 15, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.last_count_chunk", .airValue, some 1, 16, 1, [2]⟩,
  ⟨some 0, some 3, "Dma64Aligned.padding_size", .airValue, some 1, 18, 0, []⟩,
  ⟨some 0, some 3, "Dma64Aligned.im_direct", .airValue, some 2, 19, 1, [5]⟩,
]⟩

def air_Dma64AlignedInputCpy : Air := ⟨0, 4, "Zisk", "Dma64AlignedInputCpy", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 4, "seq_end", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 4, "previous_seq_end", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 4, "sel_inputcpy", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 4, "main_step", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 4, "dst64", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 4, "count64", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 4, "sel_op_from_1", .witness, some 1, 6, 1, [3]⟩,
  ⟨some 0, some 4, "l_value_chunks", .witness, some 1, 9, 2, [4, 2]⟩,
  ⟨some 0, some 4, "h_value_chunks", .witness, some 1, 17, 2, [4, 2]⟩,
  ⟨some 0, some 4, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 4, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 4, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_previous_seq_end", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_previous_dst64", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_previous_main_step", .airValue, some 1, 3, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_previous_count64", .airValue, some 1, 4, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_previous_flags", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_last_seq_end", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_last_dst64", .airValue, some 1, 7, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_last_main_step", .airValue, some 1, 8, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_last_count64", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.segment_last_flags", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.is_last_segment", .airValue, some 1, 11, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.last_count_chunk", .airValue, some 1, 12, 1, [2]⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.padding_size", .airValue, some 1, 14, 0, []⟩,
  ⟨some 0, some 4, "Dma64AlignedInputCpy.im_direct", .airValue, some 2, 15, 1, [5]⟩,
]⟩

def air_Dma64AlignedMemSet : Air := ⟨0, 5, "Zisk", "Dma64AlignedMemSet", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 5, "seq_end", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 5, "previous_seq_end", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 5, "sel_memset", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 5, "fill_byte", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 5, "main_step", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 5, "dst64", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 5, "count64", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 5, "sel_op_from_1", .witness, some 1, 7, 1, [7]⟩,
  ⟨some 0, some 5, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 5, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 5, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 5, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 5, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 5, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_previous_seq_end", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_previous_dst64", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_previous_main_step", .airValue, some 1, 3, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_previous_count64", .airValue, some 1, 4, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_previous_flags", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_last_seq_end", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_last_dst64", .airValue, some 1, 7, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_last_main_step", .airValue, some 1, 8, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_last_count64", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.segment_last_flags", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.is_last_segment", .airValue, some 1, 11, 0, []⟩,
  ⟨some 0, some 5, "segment_previous_fill_byte", .airValue, some 1, 12, 0, []⟩,
  ⟨some 0, some 5, "segment_last_fill_byte", .airValue, some 1, 13, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.last_count_chunk", .airValue, some 1, 14, 1, [2]⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.padding_size", .airValue, some 1, 16, 0, []⟩,
  ⟨some 0, some 5, "Dma64AlignedMemSet.im_direct", .airValue, some 2, 17, 1, [5]⟩,
]⟩

def air_Dma64AlignedMem : Air := ⟨0, 6, "Zisk", "Dma64AlignedMem", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 6, "src64", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 6, "seq_end", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 6, "previous_seq_end", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 6, "sel_memcpy", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 6, "sel_memeq", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 6, "sel_memset", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 6, "fill_byte", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 6, "sel_memcpy_count_load", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 6, "main_step", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 6, "dst64", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 6, "count64", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 6, "sel_op_from_1", .witness, some 1, 11, 1, [3]⟩,
  ⟨some 0, some 6, "value", .witness, some 1, 14, 2, [4, 2]⟩,
  ⟨some 0, some 6, "sel_op_mem_load", .witness, some 1, 22, 1, [4]⟩,
  ⟨some 0, some 6, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 6, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 6, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 6, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 6, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 6, "im_single", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 6, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_previous_seq_end", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_previous_dst64", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_previous_main_step", .airValue, some 1, 3, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_previous_count64", .airValue, some 1, 4, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_previous_flags", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_last_seq_end", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_last_dst64", .airValue, some 1, 7, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_last_main_step", .airValue, some 1, 8, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_last_count64", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.segment_last_flags", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.is_last_segment", .airValue, some 1, 11, 0, []⟩,
  ⟨some 0, some 6, "segment_previous_src64", .airValue, some 1, 12, 0, []⟩,
  ⟨some 0, some 6, "segment_last_src64", .airValue, some 1, 13, 0, []⟩,
  ⟨some 0, some 6, "segment_previous_fill_byte", .airValue, some 1, 14, 0, []⟩,
  ⟨some 0, some 6, "segment_last_fill_byte", .airValue, some 1, 15, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.last_count_chunk", .airValue, some 1, 16, 1, [2]⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.padding_size", .airValue, some 1, 18, 0, []⟩,
  ⟨some 0, some 6, "Dma64AlignedMem.im_direct", .airValue, some 2, 19, 1, [5]⟩,
]⟩

def air_Dma64AlignedMemCpy : Air := ⟨0, 7, "Zisk", "Dma64AlignedMemCpy", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 7, "src64", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 7, "seq_end", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 7, "previous_seq_end", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 7, "sel_memcpy", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 7, "sel_memcpy_count_load", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 7, "main_step", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 7, "dst64", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 7, "count64", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 7, "sel_op_from_1", .witness, some 1, 8, 1, [7]⟩,
  ⟨some 0, some 7, "value", .witness, some 1, 15, 2, [8, 2]⟩,
  ⟨some 0, some 7, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 7, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 7, "im_single", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 7, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_previous_seq_end", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_previous_dst64", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_previous_main_step", .airValue, some 1, 3, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_previous_count64", .airValue, some 1, 4, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_previous_flags", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_last_seq_end", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_last_dst64", .airValue, some 1, 7, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_last_main_step", .airValue, some 1, 8, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_last_count64", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.segment_last_flags", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.is_last_segment", .airValue, some 1, 11, 0, []⟩,
  ⟨some 0, some 7, "segment_previous_src64", .airValue, some 1, 12, 0, []⟩,
  ⟨some 0, some 7, "segment_last_src64", .airValue, some 1, 13, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.last_count_chunk", .airValue, some 1, 14, 1, [2]⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.padding_size", .airValue, some 1, 16, 0, []⟩,
  ⟨some 0, some 7, "Dma64AlignedMemCpy.im_direct", .airValue, some 2, 17, 1, [5]⟩,
]⟩

def air_DmaUnaligned : Air := ⟨0, 8, "Zisk", "DmaUnaligned", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 8, "main_step", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 8, "src64", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 8, "dst64", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 8, "count", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 8, "seq_end", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 8, "previous_seq_end", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 8, "is_memeq", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 8, "offset_7", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 8, "offset_6", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 8, "offset_5", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 8, "offset_4", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 8, "offset_3", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 8, "offset_2", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 8, "read_bytes", .witness, some 1, 13, 1, [8]⟩,
  ⟨some 0, some 8, "no_last_no_seq_end", .witness, some 1, 21, 0, []⟩,
  ⟨some 0, some 8, "write_value", .witness, some 1, 22, 1, [2]⟩,
  ⟨some 0, some 8, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 8, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 8, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 8, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 8, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_previous_seq_end", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_previous_src64", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_previous_dst64", .airValue, some 1, 3, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_previous_main_step", .airValue, some 1, 4, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_previous_offset", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_previous_count", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_first_bytes", .airValue, some 1, 7, 1, [8]⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_last_seq_end", .airValue, some 1, 15, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_last_src64", .airValue, some 1, 16, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_last_dst64", .airValue, some 1, 17, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_last_main_step", .airValue, some 1, 18, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_last_offset", .airValue, some 1, 19, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_last_count", .airValue, some 1, 20, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.segment_next_bytes", .airValue, some 1, 21, 1, [8]⟩,
  ⟨some 0, some 8, "DmaUnaligned.is_last_segment", .airValue, some 1, 29, 0, []⟩,
  ⟨some 0, some 8, "segment_previous_is_memeq", .airValue, some 1, 30, 0, []⟩,
  ⟨some 0, some 8, "segment_last_is_memeq", .airValue, some 1, 31, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.padding_size", .airValue, some 1, 32, 0, []⟩,
  ⟨some 0, some 8, "DmaUnaligned.last_count_chunk", .airValue, some 1, 33, 1, [2]⟩,
  ⟨some 0, some 8, "DmaUnaligned.im_direct", .airValue, some 2, 35, 1, [6]⟩,
]⟩

def air_DmaPrePost : Air := ⟨0, 9, "Zisk", "DmaPrePost", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 9, "main_step", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 9, "dst64", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 9, "dst_offset", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 9, "count", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 9, "is_post", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 9, "sel_memcpy", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 9, "sel_memcmp", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 9, "memcmp_result_nz", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 9, "l_memcmp_result", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 9, "sel_inputcpy", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 9, "sel_memset", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 9, "selr", .witness, some 1, 11, 1, [7]⟩,
  ⟨some 0, some 9, "dst_offset_gt_src_offset", .witness, some 1, 18, 0, []⟩,
  ⟨some 0, some 9, "src64", .witness, some 1, 19, 0, []⟩,
  ⟨some 0, some 9, "src_offset", .witness, some 1, 20, 0, []⟩,
  ⟨some 0, some 9, "enabled_second_read", .witness, some 1, 21, 0, []⟩,
  ⟨some 0, some 9, "fill_byte", .witness, some 1, 22, 0, []⟩,
  ⟨some 0, some 9, "rb", .witness, some 1, 23, 1, [16]⟩,
  ⟨some 0, some 9, "pb", .witness, some 1, 39, 1, [8]⟩,
  ⟨some 0, some 9, "sb", .witness, some 1, 47, 1, [8]⟩,
  ⟨some 0, some 9, "last_dst_byte", .witness, some 1, 55, 0, []⟩,
  ⟨some 0, some 9, "abs_diff_dst_src", .witness, some 1, 56, 0, []⟩,
  ⟨some 0, some 9, "memcmp_result_is_negative", .witness, some 1, 57, 0, []⟩,
  ⟨some 0, some 9, "diff_factor", .witness, some 1, 58, 1, [2]⟩,
  ⟨some 0, some 9, "bus_write_value", .witness, some 1, 60, 1, [2]⟩,
  ⟨some 0, some 9, "write_value", .witness, some 1, 62, 1, [4]⟩,
  ⟨some 0, some 9, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 9, "im_cluster", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 9, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_DmaPrePostMemCpy : Air := ⟨0, 10, "Zisk", "DmaPrePostMemCpy", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 10, "main_step", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 10, "dst64", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 10, "dst_offset", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 10, "count", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 10, "is_post", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 10, "sel_memcpy", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 10, "selr", .witness, some 1, 6, 1, [7]⟩,
  ⟨some 0, some 10, "dst_offset_gt_src_offset", .witness, some 1, 13, 0, []⟩,
  ⟨some 0, some 10, "src64", .witness, some 1, 14, 0, []⟩,
  ⟨some 0, some 10, "src_offset", .witness, some 1, 15, 0, []⟩,
  ⟨some 0, some 10, "enabled_second_read", .witness, some 1, 16, 0, []⟩,
  ⟨some 0, some 10, "rb", .witness, some 1, 17, 1, [16]⟩,
  ⟨some 0, some 10, "pb", .witness, some 1, 33, 1, [8]⟩,
  ⟨some 0, some 10, "sb", .witness, some 1, 41, 1, [8]⟩,
  ⟨some 0, some 10, "bus_write_value", .witness, some 1, 49, 1, [2]⟩,
  ⟨some 0, some 10, "write_value", .witness, some 1, 51, 1, [4]⟩,
  ⟨some 0, some 10, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 10, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 10, "im_single", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 10, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_DmaPrePostInputCpy : Air := ⟨0, 11, "Zisk", "DmaPrePostInputCpy", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 11, "main_step", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 11, "dst64", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 11, "dst_offset", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 11, "count", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 11, "is_post", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 11, "sel_inputcpy", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 11, "rb", .witness, some 1, 6, 1, [8]⟩,
  ⟨some 0, some 11, "pb", .witness, some 1, 14, 1, [8]⟩,
  ⟨some 0, some 11, "sb", .witness, some 1, 22, 1, [8]⟩,
  ⟨some 0, some 11, "bus_write_value", .witness, some 1, 30, 1, [2]⟩,
  ⟨some 0, some 11, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 11, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 11, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 11, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 11, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 11, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 11, "im_single", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 11, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_Main : Air := ⟨0, 12, "Zisk", "Main", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 12, "a", .witness, some 1, 0, 1, [2]⟩,
  ⟨some 0, some 12, "b", .witness, some 1, 2, 1, [2]⟩,
  ⟨some 0, some 12, "c", .witness, some 1, 4, 1, [2]⟩,
  ⟨some 0, some 12, "flag", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 12, "pc", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 12, "a_src_imm", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 12, "a_src_mem", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 12, "a_offset_imm0", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 12, "a_imm1", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 12, "is_precompiled", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 12, "b_src_imm", .witness, some 1, 13, 0, []⟩,
  ⟨some 0, some 12, "b_src_mem", .witness, some 1, 14, 0, []⟩,
  ⟨some 0, some 12, "b_offset_imm0", .witness, some 1, 15, 0, []⟩,
  ⟨some 0, some 12, "b_imm1", .witness, some 1, 16, 0, []⟩,
  ⟨some 0, some 12, "b_src_ind", .witness, some 1, 17, 0, []⟩,
  ⟨some 0, some 12, "ind_width", .witness, some 1, 18, 0, []⟩,
  ⟨some 0, some 12, "is_external_op", .witness, some 1, 19, 0, []⟩,
  ⟨some 0, some 12, "op", .witness, some 1, 20, 0, []⟩,
  ⟨some 0, some 12, "store_pc", .witness, some 1, 21, 0, []⟩,
  ⟨some 0, some 12, "store_mem", .witness, some 1, 22, 0, []⟩,
  ⟨some 0, some 12, "store_ind", .witness, some 1, 23, 0, []⟩,
  ⟨some 0, some 12, "store_offset", .witness, some 1, 24, 0, []⟩,
  ⟨some 0, some 12, "set_pc", .witness, some 1, 25, 0, []⟩,
  ⟨some 0, some 12, "jmp_offset1", .witness, some 1, 26, 0, []⟩,
  ⟨some 0, some 12, "jmp_offset2", .witness, some 1, 27, 0, []⟩,
  ⟨some 0, some 12, "m32", .witness, some 1, 28, 0, []⟩,
  ⟨some 0, some 12, "addr1", .witness, some 1, 29, 0, []⟩,
  ⟨some 0, some 12, "a_reg_prev_mem_step", .witness, some 1, 30, 0, []⟩,
  ⟨some 0, some 12, "b_reg_prev_mem_step", .witness, some 1, 31, 0, []⟩,
  ⟨some 0, some 12, "store_reg_prev_mem_step", .witness, some 1, 32, 0, []⟩,
  ⟨some 0, some 12, "store_reg_prev_value", .witness, some 1, 33, 1, [2]⟩,
  ⟨some 0, some 12, "a_src_reg", .witness, some 1, 35, 0, []⟩,
  ⟨some 0, some 12, "b_src_reg", .witness, some 1, 36, 0, []⟩,
  ⟨some 0, some 12, "store_reg", .witness, some 1, 37, 0, []⟩,
  ⟨some 0, some 12, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 12, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 12, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 12, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 12, "im_single", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 12, "im_single", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 12, "im_single", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 12, "im_single", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 12, "Main.SEGMENT_L1", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 12, "Main.SEGMENT_STEP", .fixed, some 0, 1, 0, []⟩,
  ⟨some 0, some 12, "__L1__", .fixed, some 0, 2, 0, []⟩,
  ⟨some 0, some 12, "Main.main_last_segment", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 12, "Main.main_segment", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 12, "Main.segment_initial_pc", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 12, "Main.segment_previous_c", .airValue, some 1, 3, 1, [2]⟩,
  ⟨some 0, some 12, "Main.segment_next_pc", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 12, "Main.segment_last_c", .airValue, some 1, 6, 1, [2]⟩,
  ⟨some 0, some 12, "Main.last_reg_value", .airValue, some 1, 8, 2, [31, 2]⟩,
  ⟨some 0, some 12, "Main.last_reg_mem_step", .airValue, some 1, 70, 1, [31]⟩,
  ⟨some 0, some 12, "Main.im_direct", .airValue, some 2, 101, 1, [96]⟩,
]⟩

def air_Rom : Air := ⟨0, 13, "Zisk", "Rom", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 13, "multiplicity", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 13, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 13, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_Mem : Air := ⟨0, 14, "Zisk", "Mem", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 14, "addr", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 14, "step", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 14, "sel", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 14, "addr_changes", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 14, "step_dual", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 14, "sel_dual", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 14, "value", .witness, some 1, 6, 1, [2]⟩,
  ⟨some 0, some 14, "wr", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 14, "previous_step", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 14, "l_increment", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 14, "h_increment", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 14, "read_same_addr", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 14, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 14, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 14, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 14, "Mem.SEGMENT_L1", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 14, "__L1__", .fixed, some 0, 1, 0, []⟩,
  ⟨some 0, some 14, "Mem.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 14, "Mem.is_first_segment", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 14, "Mem.is_last_segment", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 14, "Mem.previous_segment_value", .airValue, some 1, 3, 1, [2]⟩,
  ⟨some 0, some 14, "Mem.previous_segment_step", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 14, "Mem.previous_segment_addr", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 14, "Mem.segment_last_value", .airValue, some 1, 7, 1, [2]⟩,
  ⟨some 0, some 14, "Mem.segment_last_step", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 14, "Mem.segment_last_addr", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 14, "Mem.distance_base", .airValue, some 1, 11, 1, [2]⟩,
  ⟨some 0, some 14, "Mem.distance_end", .airValue, some 1, 13, 1, [2]⟩,
  ⟨some 0, some 14, "Mem.im_direct", .airValue, some 2, 15, 1, [6]⟩,
]⟩

def air_RomData : Air := ⟨0, 15, "Zisk", "RomData", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 15, "addr", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 15, "step", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 15, "sel", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 15, "addr_changes", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 15, "value", .witness, some 1, 4, 1, [2]⟩,
  ⟨some 0, some 15, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 15, "im_single", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 15, "im_single", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 15, "RomData.SEGMENT_L1", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 15, "__L1__", .fixed, some 0, 1, 0, []⟩,
  ⟨some 0, some 15, "RomData.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 15, "RomData.is_first_segment", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 15, "RomData.is_last_segment", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 15, "RomData.previous_segment_value", .airValue, some 1, 3, 1, [2]⟩,
  ⟨some 0, some 15, "RomData.previous_segment_step", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 15, "RomData.previous_segment_addr", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 15, "RomData.segment_last_value", .airValue, some 1, 7, 1, [2]⟩,
  ⟨some 0, some 15, "RomData.segment_last_step", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 15, "RomData.segment_last_addr", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 15, "RomData.im_direct", .airValue, some 2, 11, 1, [4]⟩,
]⟩

def air_InputData : Air := ⟨0, 16, "Zisk", "InputData", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 16, "addr", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 16, "step", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 16, "sel", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 16, "addr_changes", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 16, "value_word", .witness, some 1, 4, 1, [4]⟩,
  ⟨some 0, some 16, "is_free_read", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 16, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 16, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 16, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 16, "im_single", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 16, "InputData.SEGMENT_L1", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 16, "__L1__", .fixed, some 0, 1, 0, []⟩,
  ⟨some 0, some 16, "InputData.segment_id", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 16, "InputData.is_first_segment", .airValue, some 1, 1, 0, []⟩,
  ⟨some 0, some 16, "InputData.is_last_segment", .airValue, some 1, 2, 0, []⟩,
  ⟨some 0, some 16, "InputData.previous_segment_value", .airValue, some 1, 3, 1, [2]⟩,
  ⟨some 0, some 16, "InputData.previous_segment_step", .airValue, some 1, 5, 0, []⟩,
  ⟨some 0, some 16, "InputData.previous_segment_addr", .airValue, some 1, 6, 0, []⟩,
  ⟨some 0, some 16, "InputData.segment_last_value", .airValue, some 1, 7, 1, [2]⟩,
  ⟨some 0, some 16, "InputData.segment_last_step", .airValue, some 1, 9, 0, []⟩,
  ⟨some 0, some 16, "InputData.segment_last_addr", .airValue, some 1, 10, 0, []⟩,
  ⟨some 0, some 16, "InputData.distance_base", .airValue, some 1, 11, 1, [2]⟩,
  ⟨some 0, some 16, "InputData.distance_end", .airValue, some 1, 13, 1, [2]⟩,
  ⟨some 0, some 16, "InputData.im_direct", .airValue, some 2, 15, 1, [6]⟩,
]⟩

def air_MemAlign : Air := ⟨0, 17, "Zisk", "MemAlign", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 17, "addr", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 17, "offset", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 17, "width", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 17, "wr", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 17, "pc", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 17, "reset", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 17, "sel_up_to_down", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 17, "sel_down_to_up", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 17, "reg", .witness, some 1, 8, 1, [8]⟩,
  ⟨some 0, some 17, "sel", .witness, some 1, 16, 1, [8]⟩,
  ⟨some 0, some 17, "step", .witness, some 1, 24, 0, []⟩,
  ⟨some 0, some 17, "delta_addr", .witness, some 1, 25, 0, []⟩,
  ⟨some 0, some 17, "sel_prove", .witness, some 1, 26, 0, []⟩,
  ⟨some 0, some 17, "value", .witness, some 1, 27, 1, [2]⟩,
  ⟨some 0, some 17, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 17, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 17, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 17, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 17, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 17, "im_single", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 17, "MemAlign.L1", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 17, "__L1__", .fixed, some 0, 1, 0, []⟩,
]⟩

def air_MemAlignByte : Air := ⟨0, 18, "Zisk", "MemAlignByte", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 18, "sel_high_4b", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 18, "sel_high_2b", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 18, "sel_high_b", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 18, "direct_value", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 18, "composed_value", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 18, "written_composed_value", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 18, "written_byte_value", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 18, "value_16b", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 18, "value_8b", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 18, "byte_value", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 18, "addr_w", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 18, "step", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 18, "is_write", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 18, "mem_write_values", .witness, some 1, 13, 1, [2]⟩,
  ⟨some 0, some 18, "bus_byte", .witness, some 1, 15, 0, []⟩,
  ⟨some 0, some 18, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 18, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 18, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 18, "im_single", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 18, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 18, "MemAlignByte.padding_size", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 18, "MemAlignByte.im_direct", .airValue, some 2, 1, 1, [2]⟩,
]⟩

def air_MemAlignReadByte : Air := ⟨0, 19, "Zisk", "MemAlignReadByte", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 19, "sel_high_4b", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 19, "sel_high_2b", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 19, "sel_high_b", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 19, "direct_value", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 19, "composed_value", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 19, "value_16b", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 19, "value_8b", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 19, "byte_value", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 19, "addr_w", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 19, "step", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 19, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 19, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 19, "im_single", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 19, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 19, "MemAlignReadByte.padding_size", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 19, "MemAlignReadByte.im_direct", .airValue, some 2, 1, 1, [2]⟩,
]⟩

def air_MemAlignWriteByte : Air := ⟨0, 20, "Zisk", "MemAlignWriteByte", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 20, "sel_high_4b", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 20, "sel_high_2b", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 20, "sel_high_b", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 20, "direct_value", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 20, "composed_value", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 20, "written_composed_value", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 20, "written_byte_value", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 20, "value_16b", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 20, "value_8b", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 20, "byte_value", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 20, "addr_w", .witness, some 1, 10, 0, []⟩,
  ⟨some 0, some 20, "step", .witness, some 1, 11, 0, []⟩,
  ⟨some 0, some 20, "mem_write_values", .witness, some 1, 12, 1, [2]⟩,
  ⟨some 0, some 20, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 20, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 20, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 20, "im_single", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 20, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 20, "MemAlignWriteByte.padding_size", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 20, "MemAlignWriteByte.im_direct", .airValue, some 2, 1, 1, [3]⟩,
]⟩

def air_Arith : Air := ⟨0, 21, "Zisk", "Arith", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 21, "carry", .witness, some 1, 0, 1, [7]⟩,
  ⟨some 0, some 21, "a", .witness, some 1, 7, 1, [4]⟩,
  ⟨some 0, some 21, "b", .witness, some 1, 11, 1, [4]⟩,
  ⟨some 0, some 21, "c", .witness, some 1, 15, 1, [4]⟩,
  ⟨some 0, some 21, "d", .witness, some 1, 19, 1, [4]⟩,
  ⟨some 0, some 21, "na", .witness, some 1, 23, 0, []⟩,
  ⟨some 0, some 21, "nb", .witness, some 1, 24, 0, []⟩,
  ⟨some 0, some 21, "nr", .witness, some 1, 25, 0, []⟩,
  ⟨some 0, some 21, "np", .witness, some 1, 26, 0, []⟩,
  ⟨some 0, some 21, "sext", .witness, some 1, 27, 0, []⟩,
  ⟨some 0, some 21, "m32", .witness, some 1, 28, 0, []⟩,
  ⟨some 0, some 21, "div", .witness, some 1, 29, 0, []⟩,
  ⟨some 0, some 21, "fab", .witness, some 1, 30, 0, []⟩,
  ⟨some 0, some 21, "na_fb", .witness, some 1, 31, 0, []⟩,
  ⟨some 0, some 21, "nb_fa", .witness, some 1, 32, 0, []⟩,
  ⟨some 0, some 21, "main_div", .witness, some 1, 33, 0, []⟩,
  ⟨some 0, some 21, "main_mul", .witness, some 1, 34, 0, []⟩,
  ⟨some 0, some 21, "signed", .witness, some 1, 35, 0, []⟩,
  ⟨some 0, some 21, "div_by_zero", .witness, some 1, 36, 0, []⟩,
  ⟨some 0, some 21, "div_overflow", .witness, some 1, 37, 0, []⟩,
  ⟨some 0, some 21, "inv_sum_all_bs", .witness, some 1, 38, 0, []⟩,
  ⟨some 0, some 21, "op", .witness, some 1, 39, 0, []⟩,
  ⟨some 0, some 21, "bus_res1", .witness, some 1, 40, 0, []⟩,
  ⟨some 0, some 21, "multiplicity", .witness, some 1, 41, 0, []⟩,
  ⟨some 0, some 21, "range_ab", .witness, some 1, 42, 0, []⟩,
  ⟨some 0, some 21, "range_cd", .witness, some 1, 43, 0, []⟩,
  ⟨some 0, some 21, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 21, "im_cluster", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 21, "im_single", .witness, some 2, 12, 0, []⟩,
  ⟨some 0, some 21, "im_single", .witness, some 2, 13, 0, []⟩,
  ⟨some 0, some 21, "im_single", .witness, some 2, 14, 0, []⟩,
  ⟨some 0, some 21, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_Binary : Air := ⟨0, 22, "Zisk", "Binary", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 22, "b_op", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 22, "free_in_a", .witness, some 1, 1, 1, [8]⟩,
  ⟨some 0, some 22, "free_in_b", .witness, some 1, 9, 1, [8]⟩,
  ⟨some 0, some 22, "free_in_c", .witness, some 1, 17, 1, [8]⟩,
  ⟨some 0, some 22, "carry", .witness, some 1, 25, 1, [8]⟩,
  ⟨some 0, some 22, "mode32", .witness, some 1, 33, 0, []⟩,
  ⟨some 0, some 22, "result_is_a", .witness, some 1, 34, 0, []⟩,
  ⟨some 0, some 22, "use_first_byte", .witness, some 1, 35, 0, []⟩,
  ⟨some 0, some 22, "c_is_signed", .witness, some 1, 36, 0, []⟩,
  ⟨some 0, some 22, "b_op_or_sext", .witness, some 1, 37, 0, []⟩,
  ⟨some 0, some 22, "mode32_and_c_is_signed", .witness, some 1, 38, 0, []⟩,
  ⟨some 0, some 22, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 22, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 22, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 22, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 22, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 22, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 22, "Binary.padding_size", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 22, "Binary.im_direct", .airValue, some 2, 1, 1, [1]⟩,
]⟩

def air_BinaryAdd : Air := ⟨0, 23, "Zisk", "BinaryAdd", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 23, "a", .witness, some 1, 0, 1, [2]⟩,
  ⟨some 0, some 23, "b", .witness, some 1, 2, 1, [2]⟩,
  ⟨some 0, some 23, "c_chunks", .witness, some 1, 4, 1, [4]⟩,
  ⟨some 0, some 23, "cout", .witness, some 1, 8, 1, [2]⟩,
  ⟨some 0, some 23, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 23, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 23, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 23, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 23, "BinaryAdd.padding_size", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 23, "BinaryAdd.im_direct", .airValue, some 2, 1, 1, [1]⟩,
]⟩

def air_BinaryExtension : Air := ⟨0, 24, "Zisk", "BinaryExtension", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 24, "op", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 24, "free_in_a", .witness, some 1, 1, 1, [8]⟩,
  ⟨some 0, some 24, "free_in_b", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 24, "free_in_c", .witness, some 1, 10, 2, [8, 2]⟩,
  ⟨some 0, some 24, "op_is_shift", .witness, some 1, 26, 0, []⟩,
  ⟨some 0, some 24, "b", .witness, some 1, 27, 1, [2]⟩,
  ⟨some 0, some 24, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 24, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 24, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 24, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 24, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 24, "im_single", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 24, "__L1__", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 24, "BinaryExtension.padding_size", .airValue, some 1, 0, 0, []⟩,
  ⟨some 0, some 24, "BinaryExtension.im_direct", .airValue, some 2, 1, 1, [1]⟩,
]⟩

def air_Add256 : Air := ⟨0, 25, "Zisk", "Add256", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 25, "a", .witness, some 1, 0, 2, [4, 2]⟩,
  ⟨some 0, some 25, "b", .witness, some 1, 8, 2, [4, 2]⟩,
  ⟨some 0, some 25, "c_chunks", .witness, some 1, 16, 2, [4, 4]⟩,
  ⟨some 0, some 25, "cout", .witness, some 1, 32, 2, [4, 2]⟩,
  ⟨some 0, some 25, "addr_params", .witness, some 1, 40, 0, []⟩,
  ⟨some 0, some 25, "addr_a", .witness, some 1, 41, 0, []⟩,
  ⟨some 0, some 25, "addr_b", .witness, some 1, 42, 0, []⟩,
  ⟨some 0, some 25, "addr_c", .witness, some 1, 43, 0, []⟩,
  ⟨some 0, some 25, "step", .witness, some 1, 44, 0, []⟩,
  ⟨some 0, some 25, "cin", .witness, some 1, 45, 0, []⟩,
  ⟨some 0, some 25, "sel", .witness, some 1, 46, 0, []⟩,
  ⟨some 0, some 25, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 12, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 13, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 14, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 15, 0, []⟩,
  ⟨some 0, some 25, "im_cluster", .witness, some 2, 16, 0, []⟩,
  ⟨some 0, some 25, "__L1__", .fixed, some 0, 0, 0, []⟩,
]⟩

def air_ArithEq : Air := ⟨0, 26, "Zisk", "ArithEq", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 26, "x1", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 26, "y1", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 26, "x2", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 26, "y2", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 26, "x3", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 26, "y3", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 26, "q0", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 26, "q1", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 26, "q2", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 26, "s", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 26, "sel_op", .witness, some 1, 10, 1, [11]⟩,
  ⟨some 0, some 26, "sel_op_clk0", .witness, some 1, 21, 1, [11]⟩,
  ⟨some 0, some 26, "x_delta_chunk_inv", .witness, some 1, 32, 0, []⟩,
  ⟨some 0, some 26, "x_are_different", .witness, some 1, 33, 0, []⟩,
  ⟨some 0, some 26, "x3_lt", .witness, some 1, 34, 0, []⟩,
  ⟨some 0, some 26, "y3_lt", .witness, some 1, 35, 0, []⟩,
  ⟨some 0, some 26, "carry", .witness, some 1, 36, 2, [3, 2]⟩,
  ⟨some 0, some 26, "step_addr", .witness, some 1, 42, 0, []⟩,
  ⟨some 0, some 26, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 26, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 26, "im_single", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 26, "im_single", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 26, "im_single", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 26, "im_single", .witness, some 2, 12, 0, []⟩,
  ⟨some 0, some 26, "ArithEq.CLK_0", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 26, "__L1__", .fixed, some 0, 1, 0, []⟩,
]⟩

def air_ArithEq384 : Air := ⟨0, 27, "Zisk", "ArithEq384", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 27, "x1", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 27, "y1", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 27, "x2", .witness, some 1, 2, 0, []⟩,
  ⟨some 0, some 27, "y2", .witness, some 1, 3, 0, []⟩,
  ⟨some 0, some 27, "x3", .witness, some 1, 4, 0, []⟩,
  ⟨some 0, some 27, "y3", .witness, some 1, 5, 0, []⟩,
  ⟨some 0, some 27, "q0", .witness, some 1, 6, 0, []⟩,
  ⟨some 0, some 27, "q1", .witness, some 1, 7, 0, []⟩,
  ⟨some 0, some 27, "q2", .witness, some 1, 8, 0, []⟩,
  ⟨some 0, some 27, "s", .witness, some 1, 9, 0, []⟩,
  ⟨some 0, some 27, "sel_op", .witness, some 1, 10, 1, [6]⟩,
  ⟨some 0, some 27, "sel_op_clk0", .witness, some 1, 16, 1, [6]⟩,
  ⟨some 0, some 27, "x_delta_chunk_inv", .witness, some 1, 22, 0, []⟩,
  ⟨some 0, some 27, "x_are_different", .witness, some 1, 23, 0, []⟩,
  ⟨some 0, some 27, "x3_lt", .witness, some 1, 24, 0, []⟩,
  ⟨some 0, some 27, "y3_lt", .witness, some 1, 25, 0, []⟩,
  ⟨some 0, some 27, "carry", .witness, some 1, 26, 2, [3, 2]⟩,
  ⟨some 0, some 27, "step_addr", .witness, some 1, 32, 0, []⟩,
  ⟨some 0, some 27, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 27, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 27, "im_single", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 27, "im_single", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 27, "im_single", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 27, "im_single", .witness, some 2, 12, 0, []⟩,
  ⟨some 0, some 27, "ArithEq384.CLK_0", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 27, "__L1__", .fixed, some 0, 1, 0, []⟩,
]⟩

def air_Keccakf : Air := ⟨0, 28, "Zisk", "Keccakf", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 28, "in_use", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 28, "in_use_clk_0", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 28, "state", .witness, some 1, 2, 1, [1600]⟩,
  ⟨some 0, some 28, "chunk_acc", .witness, some 1, 1602, 1, [534]⟩,
  ⟨some 0, some 28, "step_addr", .witness, some 1, 2136, 0, []⟩,
  ⟨some 0, some 28, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 12, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 13, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 14, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 15, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 16, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 17, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 18, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 19, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 20, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 21, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 22, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 23, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 24, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 25, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 26, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 27, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 28, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 29, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 30, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 31, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 32, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 33, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 34, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 35, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 36, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 37, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 38, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 39, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 40, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 41, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 42, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 43, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 44, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 45, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 46, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 47, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 48, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 49, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 50, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 51, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 52, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 53, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 54, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 55, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 56, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 57, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 58, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 59, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 60, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 61, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 62, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 63, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 64, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 65, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 66, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 67, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 68, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 69, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 70, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 71, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 72, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 73, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 74, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 75, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 76, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 77, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 78, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 79, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 80, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 81, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 82, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 83, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 84, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 85, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 86, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 87, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 88, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 89, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 90, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 91, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 92, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 93, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 94, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 95, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 96, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 97, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 98, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 99, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 100, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 101, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 102, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 103, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 104, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 105, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 106, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 107, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 108, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 109, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 110, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 111, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 112, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 113, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 114, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 115, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 116, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 117, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 118, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 119, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 120, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 121, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 122, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 123, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 124, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 125, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 126, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 127, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 128, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 129, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 130, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 131, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 132, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 133, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 134, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 135, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 136, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 137, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 138, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 139, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 140, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 141, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 142, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 143, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 144, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 145, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 146, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 147, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 148, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 149, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 150, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 151, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 152, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 153, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 154, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 155, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 156, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 157, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 158, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 159, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 160, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 161, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 162, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 163, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 164, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 165, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 166, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 167, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 168, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 169, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 170, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 171, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 172, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 173, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 174, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 175, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 176, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 177, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 178, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 179, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 180, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 181, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 182, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 183, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 184, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 185, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 186, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 187, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 188, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 189, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 190, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 191, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 192, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 193, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 194, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 195, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 196, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 197, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 198, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 199, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 200, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 201, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 202, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 203, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 204, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 205, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 206, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 207, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 208, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 209, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 210, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 211, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 212, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 213, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 214, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 215, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 216, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 217, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 218, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 219, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 220, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 221, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 222, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 223, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 224, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 225, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 226, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 227, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 228, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 229, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 230, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 231, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 232, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 233, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 234, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 235, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 236, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 237, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 238, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 239, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 240, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 241, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 242, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 243, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 244, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 245, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 246, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 247, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 248, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 249, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 250, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 251, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 252, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 253, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 254, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 255, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 256, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 257, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 258, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 259, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 260, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 261, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 262, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 263, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 264, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 265, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 266, 0, []⟩,
  ⟨some 0, some 28, "im_cluster", .witness, some 2, 267, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 268, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 269, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 270, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 271, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 272, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 273, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 274, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 275, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 276, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 277, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 278, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 279, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 280, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 281, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 282, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 283, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 284, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 285, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 286, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 287, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 288, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 289, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 290, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 291, 0, []⟩,
  ⟨some 0, some 28, "im_single", .witness, some 2, 292, 0, []⟩,
  ⟨some 0, some 28, "Keccakf.CLK_0", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 28, "__L1__", .fixed, some 0, 1, 0, []⟩,
]⟩

def air_Sha256f : Air := ⟨0, 29, "Zisk", "Sha256f", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 29, "a", .witness, some 1, 0, 1, [32]⟩,
  ⟨some 0, some 29, "e", .witness, some 1, 32, 1, [32]⟩,
  ⟨some 0, some 29, "w", .witness, some 1, 64, 1, [32]⟩,
  ⟨some 0, some 29, "new_a_carry_bits", .witness, some 1, 96, 0, []⟩,
  ⟨some 0, some 29, "new_e_carry_bits", .witness, some 1, 97, 0, []⟩,
  ⟨some 0, some 29, "new_w_carry_bits", .witness, some 1, 98, 0, []⟩,
  ⟨some 0, some 29, "step_addr", .witness, some 1, 99, 0, []⟩,
  ⟨some 0, some 29, "in_use_clk_0", .witness, some 1, 100, 0, []⟩,
  ⟨some 0, some 29, "in_use", .witness, some 1, 101, 0, []⟩,
  ⟨some 0, some 29, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 29, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 29, "im_single", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 29, "Sha256f.CLK_0", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 29, "__L1__", .fixed, some 0, 1, 0, []⟩,
]⟩

def air_Poseidon2 : Air := ⟨0, 30, "Zisk", "Poseidon2", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 30, "in_use_clk_0", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 30, "in_use", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 30, "chunks", .witness, some 1, 2, 2, [16, 2]⟩,
  ⟨some 0, some 30, "step_addr", .witness, some 1, 34, 0, []⟩,
  ⟨some 0, some 30, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 30, "im_single", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 30, "im_single", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 30, "im_single", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 30, "im_single", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 30, "Poseidon2.CLK_0", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 30, "__L1__", .fixed, some 0, 1, 0, []⟩,
]⟩

def air_Blake2br : Air := ⟨0, 31, "Zisk", "Blake2br", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 31, "in_use", .witness, some 1, 0, 0, []⟩,
  ⟨some 0, some 31, "round_idx", .witness, some 1, 1, 0, []⟩,
  ⟨some 0, some 31, "round_idx_sel", .witness, some 1, 2, 1, [10]⟩,
  ⟨some 0, some 31, "sigma_idx", .witness, some 1, 12, 0, []⟩,
  ⟨some 0, some 31, "m_limbs", .witness, some 1, 13, 2, [2, 2]⟩,
  ⟨some 0, some 31, "ms", .witness, some 1, 17, 1, [2]⟩,
  ⟨some 0, some 31, "perm_active", .witness, some 1, 19, 0, []⟩,
  ⟨some 0, some 31, "g_active", .witness, some 1, 20, 0, []⟩,
  ⟨some 0, some 31, "va_limbs", .witness, some 1, 21, 2, [2, 2]⟩,
  ⟨some 0, some 31, "vc_limbs", .witness, some 1, 25, 2, [2, 2]⟩,
  ⟨some 0, some 31, "vb", .witness, some 1, 29, 2, [2, 32]⟩,
  ⟨some 0, some 31, "vd", .witness, some 1, 93, 2, [2, 32]⟩,
  ⟨some 0, some 31, "step_addr", .witness, some 1, 157, 0, []⟩,
  ⟨some 0, some 31, "in_use_clk_0", .witness, some 1, 158, 0, []⟩,
  ⟨some 0, some 31, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 31, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 31, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 31, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 31, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 31, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 31, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 31, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 31, "im_single", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 31, "im_single", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 31, "im_single", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 31, "im_single", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 31, "Blake2br.CLK_0", .fixed, some 0, 0, 0, []⟩,
  ⟨some 0, some 31, "Blake2br.MSG_IDX", .fixed, some 0, 1, 0, []⟩,
  ⟨some 0, some 31, "__L1__", .fixed, some 0, 2, 0, []⟩,
]⟩

def air_SpecifiedRanges : Air := ⟨0, 32, "Zisk", "SpecifiedRanges", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 32, "mul", .witness, some 1, 0, 1, [29]⟩,
  ⟨some 0, some 32, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 5, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 6, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 7, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 8, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 9, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 10, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 11, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 12, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 13, 0, []⟩,
  ⟨some 0, some 32, "im_cluster", .witness, some 2, 14, 0, []⟩,
  ⟨some 0, some 32, "SpecifiedRanges.OPID", .fixed, some 0, 0, 1, [29]⟩,
  ⟨some 0, some 32, "SpecifiedRanges.VALS", .fixed, some 0, 29, 1, [29]⟩,
  ⟨some 0, some 32, "__L1__", .fixed, some 0, 58, 0, []⟩,
]⟩

def air_VirtualTable0 : Air := ⟨0, 33, "Zisk", "VirtualTable0", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 33, "multiplicity", .witness, some 1, 0, 1, [8]⟩,
  ⟨some 0, some 33, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 33, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 33, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 33, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 33, "im_single", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 33, "VirtualTable0.UID", .fixed, some 0, 0, 1, [8]⟩,
  ⟨some 0, some 33, "VirtualTable0.column", .fixed, some 0, 8, 1, [43]⟩,
  ⟨some 0, some 33, "__L1__", .fixed, some 0, 51, 0, []⟩,
]⟩

def air_VirtualTable1 : Air := ⟨0, 34, "Zisk", "VirtualTable1", [
  ⟨some 0, none, "Zisk.gsum_result", .airGroupValue, some 2, 0, 0, []⟩,
  ⟨some 0, some 34, "multiplicity", .witness, some 1, 0, 1, [8]⟩,
  ⟨some 0, some 34, "gsum", .witness, some 2, 0, 0, []⟩,
  ⟨some 0, some 34, "im_cluster", .witness, some 2, 1, 0, []⟩,
  ⟨some 0, some 34, "im_cluster", .witness, some 2, 2, 0, []⟩,
  ⟨some 0, some 34, "im_cluster", .witness, some 2, 3, 0, []⟩,
  ⟨some 0, some 34, "im_single", .witness, some 2, 4, 0, []⟩,
  ⟨some 0, some 34, "VirtualTable1.UID", .fixed, some 0, 0, 1, [8]⟩,
  ⟨some 0, some 34, "VirtualTable1.column", .fixed, some 0, 8, 1, [64]⟩,
  ⟨some 0, some 34, "__L1__", .fixed, some 0, 72, 0, []⟩,
]⟩

def unscopedSymbols : List Symbol := [
]

end SourceSchema

def airStatus_Dma : AirStatus := {
  groupIndex := 0,
  airIndex := 0,
  group := "Zisk",
  air := "Dma",
  emittedConstraintFile := false,
  mixedConstraintCount := 8,
  unlinkedMixedConstraintCount := 8,
  gsumHintCount := 12,
  validatedLinkCount := 0
}

def airStatus_DmaMemCpy : AirStatus := {
  groupIndex := 0,
  airIndex := 1,
  group := "Zisk",
  air := "DmaMemCpy",
  emittedConstraintFile := false,
  mixedConstraintCount := 7,
  unlinkedMixedConstraintCount := 7,
  gsumHintCount := 10,
  validatedLinkCount := 0
}

def airStatus_DmaInputCpy : AirStatus := {
  groupIndex := 0,
  airIndex := 2,
  group := "Zisk",
  air := "DmaInputCpy",
  emittedConstraintFile := false,
  mixedConstraintCount := 7,
  unlinkedMixedConstraintCount := 7,
  gsumHintCount := 9,
  validatedLinkCount := 0
}

def airStatus_Dma64Aligned : AirStatus := {
  groupIndex := 0,
  airIndex := 3,
  group := "Zisk",
  air := "Dma64Aligned",
  emittedConstraintFile := false,
  mixedConstraintCount := 48,
  unlinkedMixedConstraintCount := 48,
  gsumHintCount := 27,
  validatedLinkCount := 0
}

def airStatus_Dma64AlignedInputCpy : AirStatus := {
  groupIndex := 0,
  airIndex := 4,
  group := "Zisk",
  air := "Dma64AlignedInputCpy",
  emittedConstraintFile := false,
  mixedConstraintCount := 37,
  unlinkedMixedConstraintCount := 37,
  gsumHintCount := 22,
  validatedLinkCount := 0
}

def airStatus_Dma64AlignedMemSet : AirStatus := {
  groupIndex := 0,
  airIndex := 5,
  group := "Zisk",
  air := "Dma64AlignedMemSet",
  emittedConstraintFile := false,
  mixedConstraintCount := 37,
  unlinkedMixedConstraintCount := 37,
  gsumHintCount := 14,
  validatedLinkCount := 0
}

def airStatus_Dma64AlignedMem : AirStatus := {
  groupIndex := 0,
  airIndex := 6,
  group := "Zisk",
  air := "Dma64AlignedMem",
  emittedConstraintFile := false,
  mixedConstraintCount := 42,
  unlinkedMixedConstraintCount := 42,
  gsumHintCount := 15,
  validatedLinkCount := 0
}

def airStatus_Dma64AlignedMemCpy : AirStatus := {
  groupIndex := 0,
  airIndex := 7,
  group := "Zisk",
  air := "Dma64AlignedMemCpy",
  emittedConstraintFile := false,
  mixedConstraintCount := 42,
  unlinkedMixedConstraintCount := 42,
  gsumHintCount := 23,
  validatedLinkCount := 0
}

def airStatus_DmaUnaligned : AirStatus := {
  groupIndex := 0,
  airIndex := 8,
  group := "Zisk",
  air := "DmaUnaligned",
  emittedConstraintFile := false,
  mixedConstraintCount := 58,
  unlinkedMixedConstraintCount := 58,
  gsumHintCount := 13,
  validatedLinkCount := 0
}

def airStatus_DmaPrePost : AirStatus := {
  groupIndex := 0,
  airIndex := 9,
  group := "Zisk",
  air := "DmaPrePost",
  emittedConstraintFile := false,
  mixedConstraintCount := 11,
  unlinkedMixedConstraintCount := 11,
  gsumHintCount := 19,
  validatedLinkCount := 0
}

def airStatus_DmaPrePostMemCpy : AirStatus := {
  groupIndex := 0,
  airIndex := 10,
  group := "Zisk",
  air := "DmaPrePostMemCpy",
  emittedConstraintFile := false,
  mixedConstraintCount := 11,
  unlinkedMixedConstraintCount := 11,
  gsumHintCount := 18,
  validatedLinkCount := 0
}

def airStatus_DmaPrePostInputCpy : AirStatus := {
  groupIndex := 0,
  airIndex := 11,
  group := "Zisk",
  air := "DmaPrePostInputCpy",
  emittedConstraintFile := false,
  mixedConstraintCount := 8,
  unlinkedMixedConstraintCount := 8,
  gsumHintCount := 12,
  validatedLinkCount := 0
}

def airStatus_Main : AirStatus := {
  groupIndex := 0,
  airIndex := 12,
  group := "Zisk",
  air := "Main",
  emittedConstraintFile := true,
  mixedConstraintCount := 114,
  unlinkedMixedConstraintCount := 9,
  gsumHintCount := 107,
  validatedLinkCount := 105
}

def airStatus_Rom : AirStatus := {
  groupIndex := 0,
  airIndex := 13,
  group := "Zisk",
  air := "Rom",
  emittedConstraintFile := false,
  mixedConstraintCount := 2,
  unlinkedMixedConstraintCount := 2,
  gsumHintCount := 1,
  validatedLinkCount := 0
}

def airStatus_Mem : AirStatus := {
  groupIndex := 0,
  airIndex := 14,
  group := "Zisk",
  air := "Mem",
  emittedConstraintFile := true,
  mixedConstraintCount := 25,
  unlinkedMixedConstraintCount := 16,
  gsumHintCount := 11,
  validatedLinkCount := 9
}

def airStatus_RomData : AirStatus := {
  groupIndex := 0,
  airIndex := 15,
  group := "Zisk",
  air := "RomData",
  emittedConstraintFile := false,
  mixedConstraintCount := 18,
  unlinkedMixedConstraintCount := 18,
  gsumHintCount := 6,
  validatedLinkCount := 0
}

def airStatus_InputData : AirStatus := {
  groupIndex := 0,
  airIndex := 16,
  group := "Zisk",
  air := "InputData",
  emittedConstraintFile := false,
  mixedConstraintCount := 24,
  unlinkedMixedConstraintCount := 24,
  gsumHintCount := 12,
  validatedLinkCount := 0
}

def airStatus_MemAlign : AirStatus := {
  groupIndex := 0,
  airIndex := 17,
  group := "Zisk",
  air := "MemAlign",
  emittedConstraintFile := true,
  mixedConstraintCount := 7,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 10,
  validatedLinkCount := 7
}

def airStatus_MemAlignByte : AirStatus := {
  groupIndex := 0,
  airIndex := 18,
  group := "Zisk",
  air := "MemAlignByte",
  emittedConstraintFile := true,
  mixedConstraintCount := 7,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 8,
  validatedLinkCount := 7
}

def airStatus_MemAlignReadByte : AirStatus := {
  groupIndex := 0,
  airIndex := 19,
  group := "Zisk",
  air := "MemAlignReadByte",
  emittedConstraintFile := true,
  mixedConstraintCount := 6,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 6,
  validatedLinkCount := 6
}

def airStatus_MemAlignWriteByte : AirStatus := {
  groupIndex := 0,
  airIndex := 20,
  group := "Zisk",
  air := "MemAlignWriteByte",
  emittedConstraintFile := true,
  mixedConstraintCount := 8,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 9,
  validatedLinkCount := 8
}

def airStatus_Arith : AirStatus := {
  groupIndex := 0,
  airIndex := 21,
  group := "Zisk",
  air := "Arith",
  emittedConstraintFile := true,
  mixedConstraintCount := 16,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 26,
  validatedLinkCount := 16
}

def airStatus_Binary : AirStatus := {
  groupIndex := 0,
  airIndex := 22,
  group := "Zisk",
  air := "Binary",
  emittedConstraintFile := true,
  mixedConstraintCount := 7,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 10,
  validatedLinkCount := 7
}

def airStatus_BinaryAdd : AirStatus := {
  groupIndex := 0,
  airIndex := 23,
  group := "Zisk",
  air := "BinaryAdd",
  emittedConstraintFile := true,
  mixedConstraintCount := 5,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 6,
  validatedLinkCount := 5
}

def airStatus_BinaryExtension : AirStatus := {
  groupIndex := 0,
  airIndex := 24,
  group := "Zisk",
  air := "BinaryExtension",
  emittedConstraintFile := true,
  mixedConstraintCount := 8,
  unlinkedMixedConstraintCount := 0,
  gsumHintCount := 11,
  validatedLinkCount := 8
}

def airStatus_Add256 : AirStatus := {
  groupIndex := 0,
  airIndex := 25,
  group := "Zisk",
  air := "Add256",
  emittedConstraintFile := false,
  mixedConstraintCount := 18,
  unlinkedMixedConstraintCount := 18,
  gsumHintCount := 33,
  validatedLinkCount := 0
}

def airStatus_ArithEq : AirStatus := {
  groupIndex := 0,
  airIndex := 26,
  group := "Zisk",
  air := "ArithEq",
  emittedConstraintFile := false,
  mixedConstraintCount := 14,
  unlinkedMixedConstraintCount := 14,
  gsumHintCount := 21,
  validatedLinkCount := 0
}

def airStatus_ArithEq384 : AirStatus := {
  groupIndex := 0,
  airIndex := 27,
  group := "Zisk",
  air := "ArithEq384",
  emittedConstraintFile := false,
  mixedConstraintCount := 14,
  unlinkedMixedConstraintCount := 14,
  gsumHintCount := 21,
  validatedLinkCount := 0
}

def airStatus_Keccakf : AirStatus := {
  groupIndex := 0,
  airIndex := 28,
  group := "Zisk",
  air := "Keccakf",
  emittedConstraintFile := false,
  mixedConstraintCount := 294,
  unlinkedMixedConstraintCount := 294,
  gsumHintCount := 560,
  validatedLinkCount := 0
}

def airStatus_Sha256f : AirStatus := {
  groupIndex := 0,
  airIndex := 29,
  group := "Zisk",
  air := "Sha256f",
  emittedConstraintFile := false,
  mixedConstraintCount := 4,
  unlinkedMixedConstraintCount := 4,
  gsumHintCount := 4,
  validatedLinkCount := 0
}

def airStatus_Poseidon2 : AirStatus := {
  groupIndex := 0,
  airIndex := 30,
  group := "Zisk",
  air := "Poseidon2",
  emittedConstraintFile := false,
  mixedConstraintCount := 6,
  unlinkedMixedConstraintCount := 6,
  gsumHintCount := 5,
  validatedLinkCount := 0
}

def airStatus_Blake2br : AirStatus := {
  groupIndex := 0,
  airIndex := 31,
  group := "Zisk",
  air := "Blake2br",
  emittedConstraintFile := false,
  mixedConstraintCount := 13,
  unlinkedMixedConstraintCount := 13,
  gsumHintCount := 19,
  validatedLinkCount := 0
}

def airStatus_SpecifiedRanges : AirStatus := {
  groupIndex := 0,
  airIndex := 32,
  group := "Zisk",
  air := "SpecifiedRanges",
  emittedConstraintFile := false,
  mixedConstraintCount := 16,
  unlinkedMixedConstraintCount := 16,
  gsumHintCount := 29,
  validatedLinkCount := 0
}

def airStatus_VirtualTable0 : AirStatus := {
  groupIndex := 0,
  airIndex := 33,
  group := "Zisk",
  air := "VirtualTable0",
  emittedConstraintFile := false,
  mixedConstraintCount := 6,
  unlinkedMixedConstraintCount := 6,
  gsumHintCount := 8,
  validatedLinkCount := 0
}

def airStatus_VirtualTable1 : AirStatus := {
  groupIndex := 0,
  airIndex := 34,
  group := "Zisk",
  air := "VirtualTable1",
  emittedConstraintFile := false,
  mixedConstraintCount := 6,
  unlinkedMixedConstraintCount := 6,
  gsumHintCount := 8,
  validatedLinkCount := 0
}

def constraintOnly_Main_0 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 0,
  constraint := Expr.mul (Expr.airValue 0) (Expr.sub (Expr.constant "1") (Expr.airValue 0)),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:86 Main.main_last_segment*(1-Main.main_last_segment)"
}

def constraintOnly_Main_3 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 3,
  constraint := Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.constant "1") (Expr.witness 1 9 (0))) (Expr.witness 1 8 (0))) (Expr.witness 1 35 (0))) (Expr.sub (Expr.witness 1 0 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 3) (Expr.witness 1 4 (-1)))) (Expr.witness 1 4 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:385 (a_src_c)*(a[0]-(previous_c))"
}

def constraintOnly_Main_4 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 4,
  constraint := Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.sub (Expr.constant "1") (Expr.witness 1 14 (0))) (Expr.witness 1 13 (0))) (Expr.witness 1 17 (0))) (Expr.witness 1 36 (0))) (Expr.sub (Expr.witness 1 2 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 3) (Expr.witness 1 4 (-1)))) (Expr.witness 1 4 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:386 (b_src_c)*(b[0]-(previous_c))"
}

def constraintOnly_Main_9 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 9,
  constraint := Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.constant "1") (Expr.witness 1 9 (0))) (Expr.witness 1 8 (0))) (Expr.witness 1 35 (0))) (Expr.sub (Expr.witness 1 1 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 4) (Expr.witness 1 5 (-1)))) (Expr.witness 1 5 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:385 (a_src_c)*(a[1]-(previous_c))"
}

def constraintOnly_Main_10 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 10,
  constraint := Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.sub (Expr.constant "1") (Expr.witness 1 14 (0))) (Expr.witness 1 13 (0))) (Expr.witness 1 17 (0))) (Expr.witness 1 36 (0))) (Expr.sub (Expr.witness 1 3 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 4) (Expr.witness 1 5 (-1)))) (Expr.witness 1 5 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:386 (b_src_c)*(b[1]-(previous_c))"
}

def constraintOnly_Main_19 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 19,
  constraint := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.airValue 5) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 25 (0)) (Expr.add (Expr.witness 1 4 (0)) (Expr.witness 1 26 (0)))) (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 25 (0))) (Expr.add (Expr.witness 1 7 (0)) (Expr.witness 1 27 (0))))) (Expr.mul (Expr.witness 1 6 (0)) (Expr.sub (Expr.witness 1 26 (0)) (Expr.witness 1 27 (0)))))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:423 Main.SEGMENT_L1'*(Main.segment_next_pc-(next_pc'))"
}

def constraintOnly_Main_20 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 20,
  constraint := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.airValue 6) (Expr.witness 1 4 (0))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:426 Main.SEGMENT_L1'*(Main.segment_last_c[0]-c[0])"
}

def constraintOnly_Main_21 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 21,
  constraint := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.airValue 7) (Expr.witness 1 5 (0))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:426 Main.SEGMENT_L1'*(Main.segment_last_c[1]-c[1])"
}

def constraintOnly_Main_38 : ConstraintOnly := {
  air := "Main",
  constraintIndex := 38,
  constraint := Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 2) (Expr.witness 1 7 (0))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: main/pil/main.pil:508 Main.SEGMENT_L1*(Main.segment_initial_pc-pc)"
}

def hint_Main_39_0 : HintTuple := {
  hintIndex := 626,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.witness 1 9 (0)) (Expr.witness 1 35 (0)),
  slots := [
    { name := "a_src_mem + 3 * a_src_reg", value := Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "3") (Expr.witness 1 35 (0))) },
    { name := "a_offset_imm0", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
    { name := "a_mem_step", value := Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "a[0]", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "a[1]", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
  ]
}

def hint_Main_39_1 : HintTuple := {
  hintIndex := 627,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.witness 1 36 (0)) (Expr.constant "0"),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "b_offset_imm0", value := Expr.add (Expr.witness 1 15 (0)) (Expr.constant "0") },
    { name := "b_reg_prev_mem_step", value := Expr.add (Expr.witness 1 31 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "b[0]", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "b[1]", value := Expr.add (Expr.witness 1 3 (0)) (Expr.constant "0") },
  ]
}

def constraint_Main_39 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 1 (0)) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0)))))) (Expr.challenge 2 0)) (Expr.witness 1 10 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "3") (Expr.witness 1 35 (0))))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 31 (0))) (Expr.challenge 2 0)) (Expr.witness 1 15 (0))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.sub (Expr.constant "0") (Expr.add (Expr.witness 1 9 (0)) (Expr.witness 1 35 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 31 (0))) (Expr.challenge 2 0)) (Expr.witness 1 15 (0))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.mul (Expr.witness 1 36 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 1 (0)) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0)))))) (Expr.challenge 2 0)) (Expr.witness 1 10 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "3") (Expr.witness 1 35 (0))))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))))
def template_Main_39 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_Main_39_0 hint_Main_39_1)
def link_Main_39 : ValidatedLink := {
  air := "Main",
  constraintIndex := 39,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_39,
  template := template_Main_39,
  hints := [hint_Main_39_0, hint_Main_39_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_40_0 : HintTuple := {
  hintIndex := 629,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.witness 1 37 (0)) (Expr.constant "0"),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "store_offset", value := Expr.add (Expr.witness 1 24 (0)) (Expr.constant "0") },
    { name := "store_reg_prev_mem_step", value := Expr.add (Expr.witness 1 32 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "store_reg_prev_value[0]", value := Expr.add (Expr.witness 1 33 (0)) (Expr.constant "0") },
    { name := "store_reg_prev_value[1]", value := Expr.add (Expr.witness 1 34 (0)) (Expr.constant "0") },
  ]
}

def hint_Main_40_1 : HintTuple := {
  hintIndex := 632,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.add (Expr.witness 1 35 (0)) (Expr.constant "0"),
  slots := [
    { name := "(a_mem_step - a_reg_prev_mem_step) - 1", value := Expr.sub (Expr.sub (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.witness 1 30 (0))) (Expr.constant "1") },
  ]
}

def constraint_Main_40 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 34 (0)) (Expr.challenge 2 0)) (Expr.witness 1 33 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 32 (0))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.witness 1 30 (0))) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.witness 1 37 (0)) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.witness 1 30 (0))) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.mul (Expr.sub (Expr.constant "0") (Expr.witness 1 35 (0))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 34 (0)) (Expr.challenge 2 0)) (Expr.witness 1 33 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 32 (0))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))))
def template_Main_40 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_Main_40_0 hint_Main_40_1)
def link_Main_40 : ValidatedLink := {
  air := "Main",
  constraintIndex := 40,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_40,
  template := template_Main_40,
  hints := [hint_Main_40_0, hint_Main_40_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_41_0 : HintTuple := {
  hintIndex := 634,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.add (Expr.witness 1 36 (0)) (Expr.constant "0"),
  slots := [
    { name := "(b_mem_step - b_reg_prev_mem_step) - 1", value := Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "1")) (Expr.witness 1 31 (0))) (Expr.constant "1") },
  ]
}

def hint_Main_41_1 : HintTuple := {
  hintIndex := 636,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.add (Expr.witness 1 37 (0)) (Expr.constant "0"),
  slots := [
    { name := "(store_mem_step - store_reg_prev_mem_step) - 1", value := Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "2")) (Expr.witness 1 32 (0))) (Expr.constant "1") },
  ]
}

def constraint_Main_41 : Expr := Expr.sub (Expr.mul (Expr.witness 2 3 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "1")) (Expr.witness 1 31 (0))) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "2")) (Expr.witness 1 32 (0))) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.sub (Expr.constant "0") (Expr.witness 1 36 (0))) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "2")) (Expr.witness 1 32 (0))) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.mul (Expr.sub (Expr.constant "0") (Expr.witness 1 37 (0))) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "1")) (Expr.witness 1 31 (0))) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))))
def template_Main_41 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 3 (0)) hint_Main_41_0 hint_Main_41_1)
def link_Main_41 : ValidatedLink := {
  air := "Main",
  constraintIndex := 41,
  shape := .cluster2,
  accumulator := Expr.witness 2 3 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_41,
  template := template_Main_41,
  hints := [hint_Main_41_0, hint_Main_41_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_42_0 : HintTuple := {
  hintIndex := 762,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "7890",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "pc", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
    { name := "a_offset_imm0", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
    { name := "a_imm1", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
    { name := "b_offset_imm0", value := Expr.add (Expr.witness 1 15 (0)) (Expr.constant "0") },
    { name := "b_imm1", value := Expr.add (Expr.witness 1 16 (0)) (Expr.constant "0") },
    { name := "ind_width", value := Expr.add (Expr.witness 1 18 (0)) (Expr.constant "0") },
    { name := "op", value := Expr.add (Expr.witness 1 20 (0)) (Expr.constant "0") },
    { name := "store_offset", value := Expr.add (Expr.witness 1 24 (0)) (Expr.constant "0") },
    { name := "jmp_offset1", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
    { name := "jmp_offset2", value := Expr.add (Expr.witness 1 27 (0)) (Expr.constant "0") },
    { name := "rom_flags", value := Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "2") (Expr.witness 1 8 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 9 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 12 (0)))) (Expr.mul (Expr.constant "16") (Expr.witness 1 13 (0)))) (Expr.mul (Expr.constant "32") (Expr.witness 1 14 (0)))) (Expr.mul (Expr.constant "64") (Expr.witness 1 19 (0)))) (Expr.mul (Expr.constant "128") (Expr.witness 1 21 (0)))) (Expr.mul (Expr.constant "256") (Expr.witness 1 22 (0)))) (Expr.mul (Expr.constant "512") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "1024") (Expr.witness 1 25 (0)))) (Expr.mul (Expr.constant "2048") (Expr.witness 1 28 (0)))) (Expr.mul (Expr.constant "4096") (Expr.witness 1 17 (0)))) (Expr.mul (Expr.constant "8192") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "16384") (Expr.witness 1 36 (0)))) (Expr.mul (Expr.constant "32768") (Expr.witness 1 37 (0)))) (Expr.constant "0") },
  ]
}

def constraint_Main_42 : Expr := Expr.add (Expr.mul (Expr.witness 2 4 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "2") (Expr.witness 1 8 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 9 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 12 (0)))) (Expr.mul (Expr.constant "16") (Expr.witness 1 13 (0)))) (Expr.mul (Expr.constant "32") (Expr.witness 1 14 (0)))) (Expr.mul (Expr.constant "64") (Expr.witness 1 19 (0)))) (Expr.mul (Expr.constant "128") (Expr.witness 1 21 (0)))) (Expr.mul (Expr.constant "256") (Expr.witness 1 22 (0)))) (Expr.mul (Expr.constant "512") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "1024") (Expr.witness 1 25 (0)))) (Expr.mul (Expr.constant "2048") (Expr.witness 1 28 (0)))) (Expr.mul (Expr.constant "4096") (Expr.witness 1 17 (0)))) (Expr.mul (Expr.constant "8192") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "16384") (Expr.witness 1 36 (0)))) (Expr.mul (Expr.constant "32768") (Expr.witness 1 37 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 27 (0))) (Expr.challenge 2 0)) (Expr.witness 1 26 (0))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.witness 1 20 (0))) (Expr.challenge 2 0)) (Expr.witness 1 18 (0))) (Expr.challenge 2 0)) (Expr.witness 1 16 (0))) (Expr.challenge 2 0)) (Expr.witness 1 15 (0))) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.witness 1 10 (0))) (Expr.challenge 2 0)) (Expr.witness 1 7 (0))) (Expr.challenge 2 0)) (Expr.constant "7890")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_42 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 4 (0)) hint_Main_42_0)
def link_Main_42 : ValidatedLink := {
  air := "Main",
  constraintIndex := 42,
  shape := .direct,
  accumulator := Expr.witness 2 4 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_42,
  template := template_Main_42,
  hints := [hint_Main_42_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_43_0 : HintTuple := {
  hintIndex := 628,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.add (Expr.witness 1 14 (0)) (Expr.witness 1 17 (0))) (Expr.witness 1 36 (0)),
  slots := [
    { name := "sel_mem_b + 3 * b_src_reg", value := Expr.add (Expr.add (Expr.witness 1 14 (0)) (Expr.witness 1 17 (0))) (Expr.mul (Expr.constant "3") (Expr.witness 1 36 (0))) },
    { name := "addr1", value := Expr.add (Expr.witness 1 29 (0)) (Expr.constant "0") },
    { name := "b_mem_step", value := Expr.add (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "1")) (Expr.constant "0") },
    { name := "b_src_ind * (ind_width - 8) + 8", value := Expr.add (Expr.mul (Expr.witness 1 17 (0)) (Expr.sub (Expr.witness 1 18 (0)) (Expr.constant "8"))) (Expr.constant "8") },
    { name := "b[0]", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "b[1]", value := Expr.add (Expr.witness 1 3 (0)) (Expr.constant "0") },
  ]
}

def constraint_Main_43 : Expr := Expr.sub (Expr.mul (Expr.witness 2 5 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 17 (0)) (Expr.sub (Expr.witness 1 18 (0)) (Expr.constant "8"))) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.witness 1 29 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.witness 1 14 (0)) (Expr.witness 1 17 (0))) (Expr.mul (Expr.constant "3") (Expr.witness 1 36 (0))))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.add (Expr.add (Expr.witness 1 14 (0)) (Expr.witness 1 17 (0))) (Expr.witness 1 36 (0))))
def template_Main_43 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 5 (0)) hint_Main_43_0)
def link_Main_43 : ValidatedLink := {
  air := "Main",
  constraintIndex := 43,
  shape := .directAssumesNegForm,
  accumulator := Expr.witness 2 5 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_43,
  template := template_Main_43,
  hints := [hint_Main_43_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_44_0 : HintTuple := {
  hintIndex := 630,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.add (Expr.witness 1 22 (0)) (Expr.witness 1 23 (0))) (Expr.witness 1 37 (0)),
  slots := [
    { name := "2 * (store_mem + store_ind) + 3 * store_reg", value := Expr.add (Expr.mul (Expr.constant "2") (Expr.add (Expr.witness 1 22 (0)) (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "3") (Expr.witness 1 37 (0))) },
    { name := "addr2", value := Expr.add (Expr.add (Expr.witness 1 24 (0)) (Expr.mul (Expr.witness 1 23 (0)) (Expr.witness 1 0 (0)))) (Expr.constant "0") },
    { name := "store_mem_step", value := Expr.add (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "2")) (Expr.constant "0") },
    { name := "store_ind * (ind_width - 8) + 8", value := Expr.add (Expr.mul (Expr.witness 1 23 (0)) (Expr.sub (Expr.witness 1 18 (0)) (Expr.constant "8"))) (Expr.constant "8") },
    { name := "store_pc * ((pc + jmp_offset2) - c[0]) + c[0]", value := Expr.add (Expr.mul (Expr.witness 1 21 (0)) (Expr.sub (Expr.add (Expr.witness 1 7 (0)) (Expr.witness 1 27 (0))) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)) },
    { name := "(1 - store_pc) * c[1]", value := Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 21 (0))) (Expr.witness 1 5 (0)) },
  ]
}

def constraint_Main_44 : Expr := Expr.sub (Expr.mul (Expr.witness 2 6 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 21 (0))) (Expr.witness 1 5 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 21 (0)) (Expr.sub (Expr.add (Expr.witness 1 7 (0)) (Expr.witness 1 27 (0))) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 23 (0)) (Expr.sub (Expr.witness 1 18 (0)) (Expr.constant "8"))) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))))) (Expr.constant "2"))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 24 (0)) (Expr.mul (Expr.witness 1 23 (0)) (Expr.witness 1 0 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.constant "2") (Expr.add (Expr.witness 1 22 (0)) (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "3") (Expr.witness 1 37 (0))))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.add (Expr.add (Expr.witness 1 22 (0)) (Expr.witness 1 23 (0))) (Expr.witness 1 37 (0))))
def template_Main_44 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 6 (0)) hint_Main_44_0)
def link_Main_44 : ValidatedLink := {
  air := "Main",
  constraintIndex := 44,
  shape := .directAssumesNegForm,
  accumulator := Expr.witness 2 6 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_44,
  template := template_Main_44,
  hints := [hint_Main_44_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_45_0 : HintTuple := {
  hintIndex := 637,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "5000",
  multiplicity := Expr.add (Expr.witness 1 19 (0)) (Expr.constant "0"),
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 20 (0)) (Expr.constant "0") },
    { name := "a[0]", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "(1 - m32) * a[1]", value := Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 28 (0))) (Expr.witness 1 1 (0)) },
    { name := "b[0]", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "(1 - m32) * b[1]", value := Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 28 (0))) (Expr.witness 1 3 (0)) },
    { name := "c[0]", value := Expr.add (Expr.witness 1 4 (0)) (Expr.constant "0") },
    { name := "c[1]", value := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0") },
    { name := "flag", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
    { name := "STEP * is_precompiled", value := Expr.mul (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))) (Expr.witness 1 12 (0)) },
    { name := "jmp_offset1 * is_precompiled", value := Expr.mul (Expr.witness 1 26 (0)) (Expr.witness 1 12 (0)) },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_Main_45 : Expr := Expr.sub (Expr.mul (Expr.witness 2 7 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 26 (0)) (Expr.witness 1 12 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.add (Expr.mul (Expr.airValue 1) (Expr.constant "4194304")) (Expr.fixed 1 (0))) (Expr.witness 1 12 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.witness 1 5 (0))) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 28 (0))) (Expr.witness 1 3 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 28 (0))) (Expr.witness 1 1 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.witness 1 20 (0))) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.witness 1 19 (0)))
def template_Main_45 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 7 (0)) hint_Main_45_0)
def link_Main_45 : ValidatedLink := {
  air := "Main",
  constraintIndex := 45,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.witness 2 7 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_45,
  template := template_Main_45,
  hints := [hint_Main_45_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_46_0 : HintTuple := {
  hintIndex := 625,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.witness 1 35 (0)) (Expr.constant "0"),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "a_offset_imm0", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
    { name := "a_reg_prev_mem_step", value := Expr.add (Expr.witness 1 30 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "a[0]", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "a[1]", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
  ]
}

def constraint_Main_46 : Expr := Expr.sub (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 2 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))) (Expr.witness 2 6 (0))) (Expr.witness 2 7 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 1 (0)) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 30 (0))) (Expr.challenge 2 0)) (Expr.witness 1 10 (0))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.witness 1 35 (0))
def template_Main_46 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 2 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))) (Expr.witness 2 6 (0))) (Expr.witness 2 7 (0)))) hint_Main_46_0)
def link_Main_46 : ValidatedLink := {
  air := "Main",
  constraintIndex := 46,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 2 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))) (Expr.witness 2 6 (0))) (Expr.witness 2 7 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_46,
  template := template_Main_46,
  hints := [hint_Main_46_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_47_0 : HintTuple := {
  hintIndex := 763,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "1000",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "Main.main_segment", value := Expr.add (Expr.airValue 1) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
    { name := "Main.segment_initial_pc", value := Expr.add (Expr.airValue 2) (Expr.constant "0") },
    { name := "Main.segment_previous_c[0]", value := Expr.add (Expr.airValue 3) (Expr.constant "0") },
    { name := "Main.segment_previous_c[1]", value := Expr.add (Expr.airValue 4) (Expr.constant "0") },
  ]
}

def constraint_Main_47 : Expr := Expr.add (Expr.mul (Expr.airValue 101) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 4) (Expr.challenge 2 0)) (Expr.airValue 3)) (Expr.challenge 2 0)) (Expr.airValue 2)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.airValue 1)) (Expr.challenge 2 0)) (Expr.constant "1000")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_47 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 101) hint_Main_47_0)
def link_Main_47 : ValidatedLink := {
  air := "Main",
  constraintIndex := 47,
  shape := .direct,
  accumulator := Expr.airValue 101,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_47,
  template := template_Main_47,
  hints := [hint_Main_47_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_48_0 : HintTuple := {
  hintIndex := 764,
  piop := "Direct",
  proves := true,
  busId := Expr.constant "1000",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "main_next_segment", value := Expr.add (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.sub (Expr.constant "1") (Expr.airValue 0))) (Expr.constant "0") },
    { name := "Main.main_last_segment", value := Expr.add (Expr.airValue 0) (Expr.constant "0") },
    { name := "Main.segment_next_pc", value := Expr.add (Expr.airValue 5) (Expr.constant "0") },
    { name := "Main.segment_last_c[0]", value := Expr.add (Expr.airValue 6) (Expr.constant "0") },
    { name := "Main.segment_last_c[1]", value := Expr.add (Expr.airValue 7) (Expr.constant "0") },
  ]
}

def constraint_Main_48 : Expr := Expr.sub (Expr.mul (Expr.airValue 102) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 7) (Expr.challenge 2 0)) (Expr.airValue 6)) (Expr.challenge 2 0)) (Expr.airValue 5)) (Expr.challenge 2 0)) (Expr.airValue 0)) (Expr.challenge 2 0)) (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.sub (Expr.constant "1") (Expr.airValue 0)))) (Expr.challenge 2 0)) (Expr.constant "1000")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_48 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 102) hint_Main_48_0)
def link_Main_48 : ValidatedLink := {
  air := "Main",
  constraintIndex := 48,
  shape := .direct,
  accumulator := Expr.airValue 102,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_48,
  template := template_Main_48,
  hints := [hint_Main_48_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_49_0 : HintTuple := {
  hintIndex := 639,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[0]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 70)) (Expr.constant "1") },
  ]
}

def constraint_Main_49 : Expr := Expr.add (Expr.mul (Expr.airValue 103) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 70)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_49 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 103) hint_Main_49_0)
def link_Main_49 : ValidatedLink := {
  air := "Main",
  constraintIndex := 49,
  shape := .direct,
  accumulator := Expr.airValue 103,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_49,
  template := template_Main_49,
  hints := [hint_Main_49_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_50_0 : HintTuple := {
  hintIndex := 640,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "1", value := Expr.constant "1" },
    { name := "Main.last_reg_mem_step[0]", value := Expr.add (Expr.airValue 70) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[0][0]", value := Expr.add (Expr.airValue 8) (Expr.constant "0") },
    { name := "Main.last_reg_value[0][1]", value := Expr.add (Expr.airValue 9) (Expr.constant "0") },
  ]
}

def constraint_Main_50 : Expr := Expr.sub (Expr.mul (Expr.airValue 104) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 9) (Expr.challenge 2 0)) (Expr.airValue 8)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 70)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_50 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 104) hint_Main_50_0)
def link_Main_50 : ValidatedLink := {
  air := "Main",
  constraintIndex := 50,
  shape := .direct,
  accumulator := Expr.airValue 104,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_50,
  template := template_Main_50,
  hints := [hint_Main_50_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_51_0 : HintTuple := {
  hintIndex := 641,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "1", value := Expr.constant "1" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[0][0]", value := Expr.add (Expr.airValue 8) (Expr.constant "0") },
    { name := "Main.last_reg_value[0][1]", value := Expr.add (Expr.airValue 9) (Expr.constant "0") },
  ]
}

def constraint_Main_51 : Expr := Expr.sub (Expr.mul (Expr.airValue 105) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 9) (Expr.challenge 2 0)) (Expr.airValue 8)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_51 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 105) hint_Main_51_0)
def link_Main_51 : ValidatedLink := {
  air := "Main",
  constraintIndex := 51,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 105,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_51,
  template := template_Main_51,
  hints := [hint_Main_51_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_52_0 : HintTuple := {
  hintIndex := 643,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[1]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 71)) (Expr.constant "1") },
  ]
}

def constraint_Main_52 : Expr := Expr.add (Expr.mul (Expr.airValue 106) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 71)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_52 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 106) hint_Main_52_0)
def link_Main_52 : ValidatedLink := {
  air := "Main",
  constraintIndex := 52,
  shape := .direct,
  accumulator := Expr.airValue 106,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_52,
  template := template_Main_52,
  hints := [hint_Main_52_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_53_0 : HintTuple := {
  hintIndex := 644,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "2", value := Expr.constant "2" },
    { name := "Main.last_reg_mem_step[1]", value := Expr.add (Expr.airValue 71) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[1][0]", value := Expr.add (Expr.airValue 10) (Expr.constant "0") },
    { name := "Main.last_reg_value[1][1]", value := Expr.add (Expr.airValue 11) (Expr.constant "0") },
  ]
}

def constraint_Main_53 : Expr := Expr.sub (Expr.mul (Expr.airValue 107) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 11) (Expr.challenge 2 0)) (Expr.airValue 10)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 71)) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_53 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 107) hint_Main_53_0)
def link_Main_53 : ValidatedLink := {
  air := "Main",
  constraintIndex := 53,
  shape := .direct,
  accumulator := Expr.airValue 107,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_53,
  template := template_Main_53,
  hints := [hint_Main_53_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_54_0 : HintTuple := {
  hintIndex := 645,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "2", value := Expr.constant "2" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[1][0]", value := Expr.add (Expr.airValue 10) (Expr.constant "0") },
    { name := "Main.last_reg_value[1][1]", value := Expr.add (Expr.airValue 11) (Expr.constant "0") },
  ]
}

def constraint_Main_54 : Expr := Expr.sub (Expr.mul (Expr.airValue 108) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 11) (Expr.challenge 2 0)) (Expr.airValue 10)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_54 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 108) hint_Main_54_0)
def link_Main_54 : ValidatedLink := {
  air := "Main",
  constraintIndex := 54,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 108,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_54,
  template := template_Main_54,
  hints := [hint_Main_54_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_55_0 : HintTuple := {
  hintIndex := 647,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[2]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 72)) (Expr.constant "1") },
  ]
}

def constraint_Main_55 : Expr := Expr.add (Expr.mul (Expr.airValue 109) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 72)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_55 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 109) hint_Main_55_0)
def link_Main_55 : ValidatedLink := {
  air := "Main",
  constraintIndex := 55,
  shape := .direct,
  accumulator := Expr.airValue 109,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_55,
  template := template_Main_55,
  hints := [hint_Main_55_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_56_0 : HintTuple := {
  hintIndex := 648,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "3", value := Expr.constant "3" },
    { name := "Main.last_reg_mem_step[2]", value := Expr.add (Expr.airValue 72) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[2][0]", value := Expr.add (Expr.airValue 12) (Expr.constant "0") },
    { name := "Main.last_reg_value[2][1]", value := Expr.add (Expr.airValue 13) (Expr.constant "0") },
  ]
}

def constraint_Main_56 : Expr := Expr.sub (Expr.mul (Expr.airValue 110) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 13) (Expr.challenge 2 0)) (Expr.airValue 12)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 72)) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_56 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 110) hint_Main_56_0)
def link_Main_56 : ValidatedLink := {
  air := "Main",
  constraintIndex := 56,
  shape := .direct,
  accumulator := Expr.airValue 110,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_56,
  template := template_Main_56,
  hints := [hint_Main_56_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_57_0 : HintTuple := {
  hintIndex := 649,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "3", value := Expr.constant "3" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[2][0]", value := Expr.add (Expr.airValue 12) (Expr.constant "0") },
    { name := "Main.last_reg_value[2][1]", value := Expr.add (Expr.airValue 13) (Expr.constant "0") },
  ]
}

def constraint_Main_57 : Expr := Expr.sub (Expr.mul (Expr.airValue 111) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 13) (Expr.challenge 2 0)) (Expr.airValue 12)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_57 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 111) hint_Main_57_0)
def link_Main_57 : ValidatedLink := {
  air := "Main",
  constraintIndex := 57,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 111,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_57,
  template := template_Main_57,
  hints := [hint_Main_57_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_58_0 : HintTuple := {
  hintIndex := 651,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[3]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 73)) (Expr.constant "1") },
  ]
}

def constraint_Main_58 : Expr := Expr.add (Expr.mul (Expr.airValue 112) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 73)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_58 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 112) hint_Main_58_0)
def link_Main_58 : ValidatedLink := {
  air := "Main",
  constraintIndex := 58,
  shape := .direct,
  accumulator := Expr.airValue 112,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_58,
  template := template_Main_58,
  hints := [hint_Main_58_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_59_0 : HintTuple := {
  hintIndex := 652,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "4", value := Expr.constant "4" },
    { name := "Main.last_reg_mem_step[3]", value := Expr.add (Expr.airValue 73) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[3][0]", value := Expr.add (Expr.airValue 14) (Expr.constant "0") },
    { name := "Main.last_reg_value[3][1]", value := Expr.add (Expr.airValue 15) (Expr.constant "0") },
  ]
}

def constraint_Main_59 : Expr := Expr.sub (Expr.mul (Expr.airValue 113) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 15) (Expr.challenge 2 0)) (Expr.airValue 14)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 73)) (Expr.challenge 2 0)) (Expr.constant "4")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_59 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 113) hint_Main_59_0)
def link_Main_59 : ValidatedLink := {
  air := "Main",
  constraintIndex := 59,
  shape := .direct,
  accumulator := Expr.airValue 113,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_59,
  template := template_Main_59,
  hints := [hint_Main_59_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_60_0 : HintTuple := {
  hintIndex := 653,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "4", value := Expr.constant "4" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[3][0]", value := Expr.add (Expr.airValue 14) (Expr.constant "0") },
    { name := "Main.last_reg_value[3][1]", value := Expr.add (Expr.airValue 15) (Expr.constant "0") },
  ]
}

def constraint_Main_60 : Expr := Expr.sub (Expr.mul (Expr.airValue 114) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 15) (Expr.challenge 2 0)) (Expr.airValue 14)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "4")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_60 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 114) hint_Main_60_0)
def link_Main_60 : ValidatedLink := {
  air := "Main",
  constraintIndex := 60,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 114,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_60,
  template := template_Main_60,
  hints := [hint_Main_60_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_61_0 : HintTuple := {
  hintIndex := 655,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[4]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 74)) (Expr.constant "1") },
  ]
}

def constraint_Main_61 : Expr := Expr.add (Expr.mul (Expr.airValue 115) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 74)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_61 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 115) hint_Main_61_0)
def link_Main_61 : ValidatedLink := {
  air := "Main",
  constraintIndex := 61,
  shape := .direct,
  accumulator := Expr.airValue 115,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_61,
  template := template_Main_61,
  hints := [hint_Main_61_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_62_0 : HintTuple := {
  hintIndex := 656,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "5", value := Expr.constant "5" },
    { name := "Main.last_reg_mem_step[4]", value := Expr.add (Expr.airValue 74) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[4][0]", value := Expr.add (Expr.airValue 16) (Expr.constant "0") },
    { name := "Main.last_reg_value[4][1]", value := Expr.add (Expr.airValue 17) (Expr.constant "0") },
  ]
}

def constraint_Main_62 : Expr := Expr.sub (Expr.mul (Expr.airValue 116) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 17) (Expr.challenge 2 0)) (Expr.airValue 16)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 74)) (Expr.challenge 2 0)) (Expr.constant "5")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_62 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 116) hint_Main_62_0)
def link_Main_62 : ValidatedLink := {
  air := "Main",
  constraintIndex := 62,
  shape := .direct,
  accumulator := Expr.airValue 116,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_62,
  template := template_Main_62,
  hints := [hint_Main_62_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_63_0 : HintTuple := {
  hintIndex := 657,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "5", value := Expr.constant "5" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[4][0]", value := Expr.add (Expr.airValue 16) (Expr.constant "0") },
    { name := "Main.last_reg_value[4][1]", value := Expr.add (Expr.airValue 17) (Expr.constant "0") },
  ]
}

def constraint_Main_63 : Expr := Expr.sub (Expr.mul (Expr.airValue 117) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 17) (Expr.challenge 2 0)) (Expr.airValue 16)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "5")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_63 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 117) hint_Main_63_0)
def link_Main_63 : ValidatedLink := {
  air := "Main",
  constraintIndex := 63,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 117,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_63,
  template := template_Main_63,
  hints := [hint_Main_63_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_64_0 : HintTuple := {
  hintIndex := 659,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[5]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 75)) (Expr.constant "1") },
  ]
}

def constraint_Main_64 : Expr := Expr.add (Expr.mul (Expr.airValue 118) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 75)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_64 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 118) hint_Main_64_0)
def link_Main_64 : ValidatedLink := {
  air := "Main",
  constraintIndex := 64,
  shape := .direct,
  accumulator := Expr.airValue 118,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_64,
  template := template_Main_64,
  hints := [hint_Main_64_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_65_0 : HintTuple := {
  hintIndex := 660,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "6", value := Expr.constant "6" },
    { name := "Main.last_reg_mem_step[5]", value := Expr.add (Expr.airValue 75) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[5][0]", value := Expr.add (Expr.airValue 18) (Expr.constant "0") },
    { name := "Main.last_reg_value[5][1]", value := Expr.add (Expr.airValue 19) (Expr.constant "0") },
  ]
}

def constraint_Main_65 : Expr := Expr.sub (Expr.mul (Expr.airValue 119) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 19) (Expr.challenge 2 0)) (Expr.airValue 18)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 75)) (Expr.challenge 2 0)) (Expr.constant "6")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_65 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 119) hint_Main_65_0)
def link_Main_65 : ValidatedLink := {
  air := "Main",
  constraintIndex := 65,
  shape := .direct,
  accumulator := Expr.airValue 119,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_65,
  template := template_Main_65,
  hints := [hint_Main_65_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_66_0 : HintTuple := {
  hintIndex := 661,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "6", value := Expr.constant "6" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[5][0]", value := Expr.add (Expr.airValue 18) (Expr.constant "0") },
    { name := "Main.last_reg_value[5][1]", value := Expr.add (Expr.airValue 19) (Expr.constant "0") },
  ]
}

def constraint_Main_66 : Expr := Expr.sub (Expr.mul (Expr.airValue 120) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 19) (Expr.challenge 2 0)) (Expr.airValue 18)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "6")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_66 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 120) hint_Main_66_0)
def link_Main_66 : ValidatedLink := {
  air := "Main",
  constraintIndex := 66,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 120,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_66,
  template := template_Main_66,
  hints := [hint_Main_66_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_67_0 : HintTuple := {
  hintIndex := 663,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[6]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 76)) (Expr.constant "1") },
  ]
}

def constraint_Main_67 : Expr := Expr.add (Expr.mul (Expr.airValue 121) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 76)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_67 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 121) hint_Main_67_0)
def link_Main_67 : ValidatedLink := {
  air := "Main",
  constraintIndex := 67,
  shape := .direct,
  accumulator := Expr.airValue 121,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_67,
  template := template_Main_67,
  hints := [hint_Main_67_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_68_0 : HintTuple := {
  hintIndex := 664,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "7", value := Expr.constant "7" },
    { name := "Main.last_reg_mem_step[6]", value := Expr.add (Expr.airValue 76) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[6][0]", value := Expr.add (Expr.airValue 20) (Expr.constant "0") },
    { name := "Main.last_reg_value[6][1]", value := Expr.add (Expr.airValue 21) (Expr.constant "0") },
  ]
}

def constraint_Main_68 : Expr := Expr.sub (Expr.mul (Expr.airValue 122) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 21) (Expr.challenge 2 0)) (Expr.airValue 20)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 76)) (Expr.challenge 2 0)) (Expr.constant "7")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_68 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 122) hint_Main_68_0)
def link_Main_68 : ValidatedLink := {
  air := "Main",
  constraintIndex := 68,
  shape := .direct,
  accumulator := Expr.airValue 122,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_68,
  template := template_Main_68,
  hints := [hint_Main_68_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_69_0 : HintTuple := {
  hintIndex := 665,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "7", value := Expr.constant "7" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[6][0]", value := Expr.add (Expr.airValue 20) (Expr.constant "0") },
    { name := "Main.last_reg_value[6][1]", value := Expr.add (Expr.airValue 21) (Expr.constant "0") },
  ]
}

def constraint_Main_69 : Expr := Expr.sub (Expr.mul (Expr.airValue 123) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 21) (Expr.challenge 2 0)) (Expr.airValue 20)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "7")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_69 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 123) hint_Main_69_0)
def link_Main_69 : ValidatedLink := {
  air := "Main",
  constraintIndex := 69,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 123,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_69,
  template := template_Main_69,
  hints := [hint_Main_69_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_70_0 : HintTuple := {
  hintIndex := 667,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[7]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 77)) (Expr.constant "1") },
  ]
}

def constraint_Main_70 : Expr := Expr.add (Expr.mul (Expr.airValue 124) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 77)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_70 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 124) hint_Main_70_0)
def link_Main_70 : ValidatedLink := {
  air := "Main",
  constraintIndex := 70,
  shape := .direct,
  accumulator := Expr.airValue 124,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_70,
  template := template_Main_70,
  hints := [hint_Main_70_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_71_0 : HintTuple := {
  hintIndex := 668,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_mem_step[7]", value := Expr.add (Expr.airValue 77) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[7][0]", value := Expr.add (Expr.airValue 22) (Expr.constant "0") },
    { name := "Main.last_reg_value[7][1]", value := Expr.add (Expr.airValue 23) (Expr.constant "0") },
  ]
}

def constraint_Main_71 : Expr := Expr.sub (Expr.mul (Expr.airValue 125) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 23) (Expr.challenge 2 0)) (Expr.airValue 22)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 77)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_71 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 125) hint_Main_71_0)
def link_Main_71 : ValidatedLink := {
  air := "Main",
  constraintIndex := 71,
  shape := .direct,
  accumulator := Expr.airValue 125,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_71,
  template := template_Main_71,
  hints := [hint_Main_71_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_72_0 : HintTuple := {
  hintIndex := 669,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "8", value := Expr.constant "8" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[7][0]", value := Expr.add (Expr.airValue 22) (Expr.constant "0") },
    { name := "Main.last_reg_value[7][1]", value := Expr.add (Expr.airValue 23) (Expr.constant "0") },
  ]
}

def constraint_Main_72 : Expr := Expr.sub (Expr.mul (Expr.airValue 126) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 23) (Expr.challenge 2 0)) (Expr.airValue 22)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_72 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 126) hint_Main_72_0)
def link_Main_72 : ValidatedLink := {
  air := "Main",
  constraintIndex := 72,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 126,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_72,
  template := template_Main_72,
  hints := [hint_Main_72_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_73_0 : HintTuple := {
  hintIndex := 671,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[8]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 78)) (Expr.constant "1") },
  ]
}

def constraint_Main_73 : Expr := Expr.add (Expr.mul (Expr.airValue 127) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 78)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_73 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 127) hint_Main_73_0)
def link_Main_73 : ValidatedLink := {
  air := "Main",
  constraintIndex := 73,
  shape := .direct,
  accumulator := Expr.airValue 127,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_73,
  template := template_Main_73,
  hints := [hint_Main_73_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_74_0 : HintTuple := {
  hintIndex := 672,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "9", value := Expr.constant "9" },
    { name := "Main.last_reg_mem_step[8]", value := Expr.add (Expr.airValue 78) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[8][0]", value := Expr.add (Expr.airValue 24) (Expr.constant "0") },
    { name := "Main.last_reg_value[8][1]", value := Expr.add (Expr.airValue 25) (Expr.constant "0") },
  ]
}

def constraint_Main_74 : Expr := Expr.sub (Expr.mul (Expr.airValue 128) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 25) (Expr.challenge 2 0)) (Expr.airValue 24)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 78)) (Expr.challenge 2 0)) (Expr.constant "9")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_74 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 128) hint_Main_74_0)
def link_Main_74 : ValidatedLink := {
  air := "Main",
  constraintIndex := 74,
  shape := .direct,
  accumulator := Expr.airValue 128,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_74,
  template := template_Main_74,
  hints := [hint_Main_74_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_75_0 : HintTuple := {
  hintIndex := 673,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "9", value := Expr.constant "9" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[8][0]", value := Expr.add (Expr.airValue 24) (Expr.constant "0") },
    { name := "Main.last_reg_value[8][1]", value := Expr.add (Expr.airValue 25) (Expr.constant "0") },
  ]
}

def constraint_Main_75 : Expr := Expr.sub (Expr.mul (Expr.airValue 129) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 25) (Expr.challenge 2 0)) (Expr.airValue 24)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "9")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_75 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 129) hint_Main_75_0)
def link_Main_75 : ValidatedLink := {
  air := "Main",
  constraintIndex := 75,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 129,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_75,
  template := template_Main_75,
  hints := [hint_Main_75_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_76_0 : HintTuple := {
  hintIndex := 675,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[9]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 79)) (Expr.constant "1") },
  ]
}

def constraint_Main_76 : Expr := Expr.add (Expr.mul (Expr.airValue 130) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 79)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_76 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 130) hint_Main_76_0)
def link_Main_76 : ValidatedLink := {
  air := "Main",
  constraintIndex := 76,
  shape := .direct,
  accumulator := Expr.airValue 130,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_76,
  template := template_Main_76,
  hints := [hint_Main_76_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_77_0 : HintTuple := {
  hintIndex := 676,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "10", value := Expr.constant "10" },
    { name := "Main.last_reg_mem_step[9]", value := Expr.add (Expr.airValue 79) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[9][0]", value := Expr.add (Expr.airValue 26) (Expr.constant "0") },
    { name := "Main.last_reg_value[9][1]", value := Expr.add (Expr.airValue 27) (Expr.constant "0") },
  ]
}

def constraint_Main_77 : Expr := Expr.sub (Expr.mul (Expr.airValue 131) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 27) (Expr.challenge 2 0)) (Expr.airValue 26)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 79)) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_77 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 131) hint_Main_77_0)
def link_Main_77 : ValidatedLink := {
  air := "Main",
  constraintIndex := 77,
  shape := .direct,
  accumulator := Expr.airValue 131,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_77,
  template := template_Main_77,
  hints := [hint_Main_77_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_78_0 : HintTuple := {
  hintIndex := 677,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "10", value := Expr.constant "10" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[9][0]", value := Expr.add (Expr.airValue 26) (Expr.constant "0") },
    { name := "Main.last_reg_value[9][1]", value := Expr.add (Expr.airValue 27) (Expr.constant "0") },
  ]
}

def constraint_Main_78 : Expr := Expr.sub (Expr.mul (Expr.airValue 132) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 27) (Expr.challenge 2 0)) (Expr.airValue 26)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_78 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 132) hint_Main_78_0)
def link_Main_78 : ValidatedLink := {
  air := "Main",
  constraintIndex := 78,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 132,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_78,
  template := template_Main_78,
  hints := [hint_Main_78_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_79_0 : HintTuple := {
  hintIndex := 679,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[10]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 80)) (Expr.constant "1") },
  ]
}

def constraint_Main_79 : Expr := Expr.add (Expr.mul (Expr.airValue 133) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 80)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_79 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 133) hint_Main_79_0)
def link_Main_79 : ValidatedLink := {
  air := "Main",
  constraintIndex := 79,
  shape := .direct,
  accumulator := Expr.airValue 133,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_79,
  template := template_Main_79,
  hints := [hint_Main_79_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_80_0 : HintTuple := {
  hintIndex := 680,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "11", value := Expr.constant "11" },
    { name := "Main.last_reg_mem_step[10]", value := Expr.add (Expr.airValue 80) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[10][0]", value := Expr.add (Expr.airValue 28) (Expr.constant "0") },
    { name := "Main.last_reg_value[10][1]", value := Expr.add (Expr.airValue 29) (Expr.constant "0") },
  ]
}

def constraint_Main_80 : Expr := Expr.sub (Expr.mul (Expr.airValue 134) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 29) (Expr.challenge 2 0)) (Expr.airValue 28)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 80)) (Expr.challenge 2 0)) (Expr.constant "11")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_80 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 134) hint_Main_80_0)
def link_Main_80 : ValidatedLink := {
  air := "Main",
  constraintIndex := 80,
  shape := .direct,
  accumulator := Expr.airValue 134,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_80,
  template := template_Main_80,
  hints := [hint_Main_80_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_81_0 : HintTuple := {
  hintIndex := 681,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "11", value := Expr.constant "11" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[10][0]", value := Expr.add (Expr.airValue 28) (Expr.constant "0") },
    { name := "Main.last_reg_value[10][1]", value := Expr.add (Expr.airValue 29) (Expr.constant "0") },
  ]
}

def constraint_Main_81 : Expr := Expr.sub (Expr.mul (Expr.airValue 135) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 29) (Expr.challenge 2 0)) (Expr.airValue 28)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "11")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_81 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 135) hint_Main_81_0)
def link_Main_81 : ValidatedLink := {
  air := "Main",
  constraintIndex := 81,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 135,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_81,
  template := template_Main_81,
  hints := [hint_Main_81_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_82_0 : HintTuple := {
  hintIndex := 683,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[11]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 81)) (Expr.constant "1") },
  ]
}

def constraint_Main_82 : Expr := Expr.add (Expr.mul (Expr.airValue 136) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 81)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_82 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 136) hint_Main_82_0)
def link_Main_82 : ValidatedLink := {
  air := "Main",
  constraintIndex := 82,
  shape := .direct,
  accumulator := Expr.airValue 136,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_82,
  template := template_Main_82,
  hints := [hint_Main_82_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_83_0 : HintTuple := {
  hintIndex := 684,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "12", value := Expr.constant "12" },
    { name := "Main.last_reg_mem_step[11]", value := Expr.add (Expr.airValue 81) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[11][0]", value := Expr.add (Expr.airValue 30) (Expr.constant "0") },
    { name := "Main.last_reg_value[11][1]", value := Expr.add (Expr.airValue 31) (Expr.constant "0") },
  ]
}

def constraint_Main_83 : Expr := Expr.sub (Expr.mul (Expr.airValue 137) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 31) (Expr.challenge 2 0)) (Expr.airValue 30)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 81)) (Expr.challenge 2 0)) (Expr.constant "12")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_83 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 137) hint_Main_83_0)
def link_Main_83 : ValidatedLink := {
  air := "Main",
  constraintIndex := 83,
  shape := .direct,
  accumulator := Expr.airValue 137,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_83,
  template := template_Main_83,
  hints := [hint_Main_83_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_84_0 : HintTuple := {
  hintIndex := 685,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "12", value := Expr.constant "12" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[11][0]", value := Expr.add (Expr.airValue 30) (Expr.constant "0") },
    { name := "Main.last_reg_value[11][1]", value := Expr.add (Expr.airValue 31) (Expr.constant "0") },
  ]
}

def constraint_Main_84 : Expr := Expr.sub (Expr.mul (Expr.airValue 138) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 31) (Expr.challenge 2 0)) (Expr.airValue 30)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "12")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_84 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 138) hint_Main_84_0)
def link_Main_84 : ValidatedLink := {
  air := "Main",
  constraintIndex := 84,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 138,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_84,
  template := template_Main_84,
  hints := [hint_Main_84_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_85_0 : HintTuple := {
  hintIndex := 687,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[12]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 82)) (Expr.constant "1") },
  ]
}

def constraint_Main_85 : Expr := Expr.add (Expr.mul (Expr.airValue 139) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 82)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_85 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 139) hint_Main_85_0)
def link_Main_85 : ValidatedLink := {
  air := "Main",
  constraintIndex := 85,
  shape := .direct,
  accumulator := Expr.airValue 139,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_85,
  template := template_Main_85,
  hints := [hint_Main_85_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_86_0 : HintTuple := {
  hintIndex := 688,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "13", value := Expr.constant "13" },
    { name := "Main.last_reg_mem_step[12]", value := Expr.add (Expr.airValue 82) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[12][0]", value := Expr.add (Expr.airValue 32) (Expr.constant "0") },
    { name := "Main.last_reg_value[12][1]", value := Expr.add (Expr.airValue 33) (Expr.constant "0") },
  ]
}

def constraint_Main_86 : Expr := Expr.sub (Expr.mul (Expr.airValue 140) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 33) (Expr.challenge 2 0)) (Expr.airValue 32)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 82)) (Expr.challenge 2 0)) (Expr.constant "13")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_86 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 140) hint_Main_86_0)
def link_Main_86 : ValidatedLink := {
  air := "Main",
  constraintIndex := 86,
  shape := .direct,
  accumulator := Expr.airValue 140,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_86,
  template := template_Main_86,
  hints := [hint_Main_86_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_87_0 : HintTuple := {
  hintIndex := 689,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "13", value := Expr.constant "13" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[12][0]", value := Expr.add (Expr.airValue 32) (Expr.constant "0") },
    { name := "Main.last_reg_value[12][1]", value := Expr.add (Expr.airValue 33) (Expr.constant "0") },
  ]
}

def constraint_Main_87 : Expr := Expr.sub (Expr.mul (Expr.airValue 141) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 33) (Expr.challenge 2 0)) (Expr.airValue 32)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "13")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_87 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 141) hint_Main_87_0)
def link_Main_87 : ValidatedLink := {
  air := "Main",
  constraintIndex := 87,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 141,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_87,
  template := template_Main_87,
  hints := [hint_Main_87_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_88_0 : HintTuple := {
  hintIndex := 691,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[13]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 83)) (Expr.constant "1") },
  ]
}

def constraint_Main_88 : Expr := Expr.add (Expr.mul (Expr.airValue 142) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 83)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_88 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 142) hint_Main_88_0)
def link_Main_88 : ValidatedLink := {
  air := "Main",
  constraintIndex := 88,
  shape := .direct,
  accumulator := Expr.airValue 142,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_88,
  template := template_Main_88,
  hints := [hint_Main_88_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_89_0 : HintTuple := {
  hintIndex := 692,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "14", value := Expr.constant "14" },
    { name := "Main.last_reg_mem_step[13]", value := Expr.add (Expr.airValue 83) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[13][0]", value := Expr.add (Expr.airValue 34) (Expr.constant "0") },
    { name := "Main.last_reg_value[13][1]", value := Expr.add (Expr.airValue 35) (Expr.constant "0") },
  ]
}

def constraint_Main_89 : Expr := Expr.sub (Expr.mul (Expr.airValue 143) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 35) (Expr.challenge 2 0)) (Expr.airValue 34)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 83)) (Expr.challenge 2 0)) (Expr.constant "14")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_89 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 143) hint_Main_89_0)
def link_Main_89 : ValidatedLink := {
  air := "Main",
  constraintIndex := 89,
  shape := .direct,
  accumulator := Expr.airValue 143,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_89,
  template := template_Main_89,
  hints := [hint_Main_89_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_90_0 : HintTuple := {
  hintIndex := 693,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "14", value := Expr.constant "14" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[13][0]", value := Expr.add (Expr.airValue 34) (Expr.constant "0") },
    { name := "Main.last_reg_value[13][1]", value := Expr.add (Expr.airValue 35) (Expr.constant "0") },
  ]
}

def constraint_Main_90 : Expr := Expr.sub (Expr.mul (Expr.airValue 144) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 35) (Expr.challenge 2 0)) (Expr.airValue 34)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "14")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_90 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 144) hint_Main_90_0)
def link_Main_90 : ValidatedLink := {
  air := "Main",
  constraintIndex := 90,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 144,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_90,
  template := template_Main_90,
  hints := [hint_Main_90_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_91_0 : HintTuple := {
  hintIndex := 695,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[14]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 84)) (Expr.constant "1") },
  ]
}

def constraint_Main_91 : Expr := Expr.add (Expr.mul (Expr.airValue 145) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 84)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_91 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 145) hint_Main_91_0)
def link_Main_91 : ValidatedLink := {
  air := "Main",
  constraintIndex := 91,
  shape := .direct,
  accumulator := Expr.airValue 145,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_91,
  template := template_Main_91,
  hints := [hint_Main_91_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_92_0 : HintTuple := {
  hintIndex := 696,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "15", value := Expr.constant "15" },
    { name := "Main.last_reg_mem_step[14]", value := Expr.add (Expr.airValue 84) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[14][0]", value := Expr.add (Expr.airValue 36) (Expr.constant "0") },
    { name := "Main.last_reg_value[14][1]", value := Expr.add (Expr.airValue 37) (Expr.constant "0") },
  ]
}

def constraint_Main_92 : Expr := Expr.sub (Expr.mul (Expr.airValue 146) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 37) (Expr.challenge 2 0)) (Expr.airValue 36)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 84)) (Expr.challenge 2 0)) (Expr.constant "15")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_92 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 146) hint_Main_92_0)
def link_Main_92 : ValidatedLink := {
  air := "Main",
  constraintIndex := 92,
  shape := .direct,
  accumulator := Expr.airValue 146,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_92,
  template := template_Main_92,
  hints := [hint_Main_92_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_93_0 : HintTuple := {
  hintIndex := 697,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "15", value := Expr.constant "15" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[14][0]", value := Expr.add (Expr.airValue 36) (Expr.constant "0") },
    { name := "Main.last_reg_value[14][1]", value := Expr.add (Expr.airValue 37) (Expr.constant "0") },
  ]
}

def constraint_Main_93 : Expr := Expr.sub (Expr.mul (Expr.airValue 147) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 37) (Expr.challenge 2 0)) (Expr.airValue 36)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "15")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_93 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 147) hint_Main_93_0)
def link_Main_93 : ValidatedLink := {
  air := "Main",
  constraintIndex := 93,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 147,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_93,
  template := template_Main_93,
  hints := [hint_Main_93_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_94_0 : HintTuple := {
  hintIndex := 699,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[15]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 85)) (Expr.constant "1") },
  ]
}

def constraint_Main_94 : Expr := Expr.add (Expr.mul (Expr.airValue 148) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 85)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_94 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 148) hint_Main_94_0)
def link_Main_94 : ValidatedLink := {
  air := "Main",
  constraintIndex := 94,
  shape := .direct,
  accumulator := Expr.airValue 148,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_94,
  template := template_Main_94,
  hints := [hint_Main_94_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_95_0 : HintTuple := {
  hintIndex := 700,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "16", value := Expr.constant "16" },
    { name := "Main.last_reg_mem_step[15]", value := Expr.add (Expr.airValue 85) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[15][0]", value := Expr.add (Expr.airValue 38) (Expr.constant "0") },
    { name := "Main.last_reg_value[15][1]", value := Expr.add (Expr.airValue 39) (Expr.constant "0") },
  ]
}

def constraint_Main_95 : Expr := Expr.sub (Expr.mul (Expr.airValue 149) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 39) (Expr.challenge 2 0)) (Expr.airValue 38)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 85)) (Expr.challenge 2 0)) (Expr.constant "16")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_95 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 149) hint_Main_95_0)
def link_Main_95 : ValidatedLink := {
  air := "Main",
  constraintIndex := 95,
  shape := .direct,
  accumulator := Expr.airValue 149,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_95,
  template := template_Main_95,
  hints := [hint_Main_95_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_96_0 : HintTuple := {
  hintIndex := 701,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "16", value := Expr.constant "16" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[15][0]", value := Expr.add (Expr.airValue 38) (Expr.constant "0") },
    { name := "Main.last_reg_value[15][1]", value := Expr.add (Expr.airValue 39) (Expr.constant "0") },
  ]
}

def constraint_Main_96 : Expr := Expr.sub (Expr.mul (Expr.airValue 150) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 39) (Expr.challenge 2 0)) (Expr.airValue 38)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "16")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_96 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 150) hint_Main_96_0)
def link_Main_96 : ValidatedLink := {
  air := "Main",
  constraintIndex := 96,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 150,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_96,
  template := template_Main_96,
  hints := [hint_Main_96_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_97_0 : HintTuple := {
  hintIndex := 703,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[16]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 86)) (Expr.constant "1") },
  ]
}

def constraint_Main_97 : Expr := Expr.add (Expr.mul (Expr.airValue 151) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 86)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_97 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 151) hint_Main_97_0)
def link_Main_97 : ValidatedLink := {
  air := "Main",
  constraintIndex := 97,
  shape := .direct,
  accumulator := Expr.airValue 151,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_97,
  template := template_Main_97,
  hints := [hint_Main_97_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_98_0 : HintTuple := {
  hintIndex := 704,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "17", value := Expr.constant "17" },
    { name := "Main.last_reg_mem_step[16]", value := Expr.add (Expr.airValue 86) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[16][0]", value := Expr.add (Expr.airValue 40) (Expr.constant "0") },
    { name := "Main.last_reg_value[16][1]", value := Expr.add (Expr.airValue 41) (Expr.constant "0") },
  ]
}

def constraint_Main_98 : Expr := Expr.sub (Expr.mul (Expr.airValue 152) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 41) (Expr.challenge 2 0)) (Expr.airValue 40)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 86)) (Expr.challenge 2 0)) (Expr.constant "17")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_98 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 152) hint_Main_98_0)
def link_Main_98 : ValidatedLink := {
  air := "Main",
  constraintIndex := 98,
  shape := .direct,
  accumulator := Expr.airValue 152,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_98,
  template := template_Main_98,
  hints := [hint_Main_98_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_99_0 : HintTuple := {
  hintIndex := 705,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "17", value := Expr.constant "17" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[16][0]", value := Expr.add (Expr.airValue 40) (Expr.constant "0") },
    { name := "Main.last_reg_value[16][1]", value := Expr.add (Expr.airValue 41) (Expr.constant "0") },
  ]
}

def constraint_Main_99 : Expr := Expr.sub (Expr.mul (Expr.airValue 153) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 41) (Expr.challenge 2 0)) (Expr.airValue 40)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "17")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_99 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 153) hint_Main_99_0)
def link_Main_99 : ValidatedLink := {
  air := "Main",
  constraintIndex := 99,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 153,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_99,
  template := template_Main_99,
  hints := [hint_Main_99_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_100_0 : HintTuple := {
  hintIndex := 707,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[17]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 87)) (Expr.constant "1") },
  ]
}

def constraint_Main_100 : Expr := Expr.add (Expr.mul (Expr.airValue 154) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 87)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_100 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 154) hint_Main_100_0)
def link_Main_100 : ValidatedLink := {
  air := "Main",
  constraintIndex := 100,
  shape := .direct,
  accumulator := Expr.airValue 154,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_100,
  template := template_Main_100,
  hints := [hint_Main_100_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_101_0 : HintTuple := {
  hintIndex := 708,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "18", value := Expr.constant "18" },
    { name := "Main.last_reg_mem_step[17]", value := Expr.add (Expr.airValue 87) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[17][0]", value := Expr.add (Expr.airValue 42) (Expr.constant "0") },
    { name := "Main.last_reg_value[17][1]", value := Expr.add (Expr.airValue 43) (Expr.constant "0") },
  ]
}

def constraint_Main_101 : Expr := Expr.sub (Expr.mul (Expr.airValue 155) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 43) (Expr.challenge 2 0)) (Expr.airValue 42)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 87)) (Expr.challenge 2 0)) (Expr.constant "18")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_101 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 155) hint_Main_101_0)
def link_Main_101 : ValidatedLink := {
  air := "Main",
  constraintIndex := 101,
  shape := .direct,
  accumulator := Expr.airValue 155,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_101,
  template := template_Main_101,
  hints := [hint_Main_101_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_102_0 : HintTuple := {
  hintIndex := 709,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "18", value := Expr.constant "18" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[17][0]", value := Expr.add (Expr.airValue 42) (Expr.constant "0") },
    { name := "Main.last_reg_value[17][1]", value := Expr.add (Expr.airValue 43) (Expr.constant "0") },
  ]
}

def constraint_Main_102 : Expr := Expr.sub (Expr.mul (Expr.airValue 156) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 43) (Expr.challenge 2 0)) (Expr.airValue 42)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "18")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_102 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 156) hint_Main_102_0)
def link_Main_102 : ValidatedLink := {
  air := "Main",
  constraintIndex := 102,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 156,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_102,
  template := template_Main_102,
  hints := [hint_Main_102_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_103_0 : HintTuple := {
  hintIndex := 711,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[18]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 88)) (Expr.constant "1") },
  ]
}

def constraint_Main_103 : Expr := Expr.add (Expr.mul (Expr.airValue 157) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 88)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_103 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 157) hint_Main_103_0)
def link_Main_103 : ValidatedLink := {
  air := "Main",
  constraintIndex := 103,
  shape := .direct,
  accumulator := Expr.airValue 157,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_103,
  template := template_Main_103,
  hints := [hint_Main_103_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_104_0 : HintTuple := {
  hintIndex := 712,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "19", value := Expr.constant "19" },
    { name := "Main.last_reg_mem_step[18]", value := Expr.add (Expr.airValue 88) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[18][0]", value := Expr.add (Expr.airValue 44) (Expr.constant "0") },
    { name := "Main.last_reg_value[18][1]", value := Expr.add (Expr.airValue 45) (Expr.constant "0") },
  ]
}

def constraint_Main_104 : Expr := Expr.sub (Expr.mul (Expr.airValue 158) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 45) (Expr.challenge 2 0)) (Expr.airValue 44)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 88)) (Expr.challenge 2 0)) (Expr.constant "19")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_104 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 158) hint_Main_104_0)
def link_Main_104 : ValidatedLink := {
  air := "Main",
  constraintIndex := 104,
  shape := .direct,
  accumulator := Expr.airValue 158,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_104,
  template := template_Main_104,
  hints := [hint_Main_104_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_105_0 : HintTuple := {
  hintIndex := 713,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "19", value := Expr.constant "19" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[18][0]", value := Expr.add (Expr.airValue 44) (Expr.constant "0") },
    { name := "Main.last_reg_value[18][1]", value := Expr.add (Expr.airValue 45) (Expr.constant "0") },
  ]
}

def constraint_Main_105 : Expr := Expr.sub (Expr.mul (Expr.airValue 159) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 45) (Expr.challenge 2 0)) (Expr.airValue 44)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "19")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_105 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 159) hint_Main_105_0)
def link_Main_105 : ValidatedLink := {
  air := "Main",
  constraintIndex := 105,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 159,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_105,
  template := template_Main_105,
  hints := [hint_Main_105_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_106_0 : HintTuple := {
  hintIndex := 715,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[19]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 89)) (Expr.constant "1") },
  ]
}

def constraint_Main_106 : Expr := Expr.add (Expr.mul (Expr.airValue 160) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 89)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_106 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 160) hint_Main_106_0)
def link_Main_106 : ValidatedLink := {
  air := "Main",
  constraintIndex := 106,
  shape := .direct,
  accumulator := Expr.airValue 160,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_106,
  template := template_Main_106,
  hints := [hint_Main_106_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_107_0 : HintTuple := {
  hintIndex := 716,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "20", value := Expr.constant "20" },
    { name := "Main.last_reg_mem_step[19]", value := Expr.add (Expr.airValue 89) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[19][0]", value := Expr.add (Expr.airValue 46) (Expr.constant "0") },
    { name := "Main.last_reg_value[19][1]", value := Expr.add (Expr.airValue 47) (Expr.constant "0") },
  ]
}

def constraint_Main_107 : Expr := Expr.sub (Expr.mul (Expr.airValue 161) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 47) (Expr.challenge 2 0)) (Expr.airValue 46)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 89)) (Expr.challenge 2 0)) (Expr.constant "20")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_107 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 161) hint_Main_107_0)
def link_Main_107 : ValidatedLink := {
  air := "Main",
  constraintIndex := 107,
  shape := .direct,
  accumulator := Expr.airValue 161,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_107,
  template := template_Main_107,
  hints := [hint_Main_107_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_108_0 : HintTuple := {
  hintIndex := 717,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "20", value := Expr.constant "20" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[19][0]", value := Expr.add (Expr.airValue 46) (Expr.constant "0") },
    { name := "Main.last_reg_value[19][1]", value := Expr.add (Expr.airValue 47) (Expr.constant "0") },
  ]
}

def constraint_Main_108 : Expr := Expr.sub (Expr.mul (Expr.airValue 162) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 47) (Expr.challenge 2 0)) (Expr.airValue 46)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "20")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_108 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 162) hint_Main_108_0)
def link_Main_108 : ValidatedLink := {
  air := "Main",
  constraintIndex := 108,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 162,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_108,
  template := template_Main_108,
  hints := [hint_Main_108_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_109_0 : HintTuple := {
  hintIndex := 719,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[20]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 90)) (Expr.constant "1") },
  ]
}

def constraint_Main_109 : Expr := Expr.add (Expr.mul (Expr.airValue 163) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 90)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_109 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 163) hint_Main_109_0)
def link_Main_109 : ValidatedLink := {
  air := "Main",
  constraintIndex := 109,
  shape := .direct,
  accumulator := Expr.airValue 163,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_109,
  template := template_Main_109,
  hints := [hint_Main_109_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_110_0 : HintTuple := {
  hintIndex := 720,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "21", value := Expr.constant "21" },
    { name := "Main.last_reg_mem_step[20]", value := Expr.add (Expr.airValue 90) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[20][0]", value := Expr.add (Expr.airValue 48) (Expr.constant "0") },
    { name := "Main.last_reg_value[20][1]", value := Expr.add (Expr.airValue 49) (Expr.constant "0") },
  ]
}

def constraint_Main_110 : Expr := Expr.sub (Expr.mul (Expr.airValue 164) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 49) (Expr.challenge 2 0)) (Expr.airValue 48)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 90)) (Expr.challenge 2 0)) (Expr.constant "21")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_110 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 164) hint_Main_110_0)
def link_Main_110 : ValidatedLink := {
  air := "Main",
  constraintIndex := 110,
  shape := .direct,
  accumulator := Expr.airValue 164,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_110,
  template := template_Main_110,
  hints := [hint_Main_110_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_111_0 : HintTuple := {
  hintIndex := 721,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "21", value := Expr.constant "21" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[20][0]", value := Expr.add (Expr.airValue 48) (Expr.constant "0") },
    { name := "Main.last_reg_value[20][1]", value := Expr.add (Expr.airValue 49) (Expr.constant "0") },
  ]
}

def constraint_Main_111 : Expr := Expr.sub (Expr.mul (Expr.airValue 165) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 49) (Expr.challenge 2 0)) (Expr.airValue 48)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "21")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_111 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 165) hint_Main_111_0)
def link_Main_111 : ValidatedLink := {
  air := "Main",
  constraintIndex := 111,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 165,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_111,
  template := template_Main_111,
  hints := [hint_Main_111_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_112_0 : HintTuple := {
  hintIndex := 723,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[21]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 91)) (Expr.constant "1") },
  ]
}

def constraint_Main_112 : Expr := Expr.add (Expr.mul (Expr.airValue 166) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 91)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_112 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 166) hint_Main_112_0)
def link_Main_112 : ValidatedLink := {
  air := "Main",
  constraintIndex := 112,
  shape := .direct,
  accumulator := Expr.airValue 166,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_112,
  template := template_Main_112,
  hints := [hint_Main_112_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_113_0 : HintTuple := {
  hintIndex := 724,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "22", value := Expr.constant "22" },
    { name := "Main.last_reg_mem_step[21]", value := Expr.add (Expr.airValue 91) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[21][0]", value := Expr.add (Expr.airValue 50) (Expr.constant "0") },
    { name := "Main.last_reg_value[21][1]", value := Expr.add (Expr.airValue 51) (Expr.constant "0") },
  ]
}

def constraint_Main_113 : Expr := Expr.sub (Expr.mul (Expr.airValue 167) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 51) (Expr.challenge 2 0)) (Expr.airValue 50)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 91)) (Expr.challenge 2 0)) (Expr.constant "22")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_113 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 167) hint_Main_113_0)
def link_Main_113 : ValidatedLink := {
  air := "Main",
  constraintIndex := 113,
  shape := .direct,
  accumulator := Expr.airValue 167,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_113,
  template := template_Main_113,
  hints := [hint_Main_113_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_114_0 : HintTuple := {
  hintIndex := 725,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "22", value := Expr.constant "22" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[21][0]", value := Expr.add (Expr.airValue 50) (Expr.constant "0") },
    { name := "Main.last_reg_value[21][1]", value := Expr.add (Expr.airValue 51) (Expr.constant "0") },
  ]
}

def constraint_Main_114 : Expr := Expr.sub (Expr.mul (Expr.airValue 168) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 51) (Expr.challenge 2 0)) (Expr.airValue 50)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "22")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_114 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 168) hint_Main_114_0)
def link_Main_114 : ValidatedLink := {
  air := "Main",
  constraintIndex := 114,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 168,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_114,
  template := template_Main_114,
  hints := [hint_Main_114_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_115_0 : HintTuple := {
  hintIndex := 727,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[22]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 92)) (Expr.constant "1") },
  ]
}

def constraint_Main_115 : Expr := Expr.add (Expr.mul (Expr.airValue 169) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 92)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_115 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 169) hint_Main_115_0)
def link_Main_115 : ValidatedLink := {
  air := "Main",
  constraintIndex := 115,
  shape := .direct,
  accumulator := Expr.airValue 169,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_115,
  template := template_Main_115,
  hints := [hint_Main_115_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_116_0 : HintTuple := {
  hintIndex := 728,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "23", value := Expr.constant "23" },
    { name := "Main.last_reg_mem_step[22]", value := Expr.add (Expr.airValue 92) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[22][0]", value := Expr.add (Expr.airValue 52) (Expr.constant "0") },
    { name := "Main.last_reg_value[22][1]", value := Expr.add (Expr.airValue 53) (Expr.constant "0") },
  ]
}

def constraint_Main_116 : Expr := Expr.sub (Expr.mul (Expr.airValue 170) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 53) (Expr.challenge 2 0)) (Expr.airValue 52)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 92)) (Expr.challenge 2 0)) (Expr.constant "23")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_116 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 170) hint_Main_116_0)
def link_Main_116 : ValidatedLink := {
  air := "Main",
  constraintIndex := 116,
  shape := .direct,
  accumulator := Expr.airValue 170,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_116,
  template := template_Main_116,
  hints := [hint_Main_116_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_117_0 : HintTuple := {
  hintIndex := 729,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "23", value := Expr.constant "23" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[22][0]", value := Expr.add (Expr.airValue 52) (Expr.constant "0") },
    { name := "Main.last_reg_value[22][1]", value := Expr.add (Expr.airValue 53) (Expr.constant "0") },
  ]
}

def constraint_Main_117 : Expr := Expr.sub (Expr.mul (Expr.airValue 171) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 53) (Expr.challenge 2 0)) (Expr.airValue 52)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "23")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_117 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 171) hint_Main_117_0)
def link_Main_117 : ValidatedLink := {
  air := "Main",
  constraintIndex := 117,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 171,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_117,
  template := template_Main_117,
  hints := [hint_Main_117_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_118_0 : HintTuple := {
  hintIndex := 731,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[23]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 93)) (Expr.constant "1") },
  ]
}

def constraint_Main_118 : Expr := Expr.add (Expr.mul (Expr.airValue 172) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 93)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_118 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 172) hint_Main_118_0)
def link_Main_118 : ValidatedLink := {
  air := "Main",
  constraintIndex := 118,
  shape := .direct,
  accumulator := Expr.airValue 172,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_118,
  template := template_Main_118,
  hints := [hint_Main_118_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_119_0 : HintTuple := {
  hintIndex := 732,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "24", value := Expr.constant "24" },
    { name := "Main.last_reg_mem_step[23]", value := Expr.add (Expr.airValue 93) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[23][0]", value := Expr.add (Expr.airValue 54) (Expr.constant "0") },
    { name := "Main.last_reg_value[23][1]", value := Expr.add (Expr.airValue 55) (Expr.constant "0") },
  ]
}

def constraint_Main_119 : Expr := Expr.sub (Expr.mul (Expr.airValue 173) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 55) (Expr.challenge 2 0)) (Expr.airValue 54)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 93)) (Expr.challenge 2 0)) (Expr.constant "24")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_119 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 173) hint_Main_119_0)
def link_Main_119 : ValidatedLink := {
  air := "Main",
  constraintIndex := 119,
  shape := .direct,
  accumulator := Expr.airValue 173,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_119,
  template := template_Main_119,
  hints := [hint_Main_119_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_120_0 : HintTuple := {
  hintIndex := 733,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "24", value := Expr.constant "24" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[23][0]", value := Expr.add (Expr.airValue 54) (Expr.constant "0") },
    { name := "Main.last_reg_value[23][1]", value := Expr.add (Expr.airValue 55) (Expr.constant "0") },
  ]
}

def constraint_Main_120 : Expr := Expr.sub (Expr.mul (Expr.airValue 174) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 55) (Expr.challenge 2 0)) (Expr.airValue 54)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "24")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_120 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 174) hint_Main_120_0)
def link_Main_120 : ValidatedLink := {
  air := "Main",
  constraintIndex := 120,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 174,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_120,
  template := template_Main_120,
  hints := [hint_Main_120_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_121_0 : HintTuple := {
  hintIndex := 735,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[24]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 94)) (Expr.constant "1") },
  ]
}

def constraint_Main_121 : Expr := Expr.add (Expr.mul (Expr.airValue 175) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 94)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_121 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 175) hint_Main_121_0)
def link_Main_121 : ValidatedLink := {
  air := "Main",
  constraintIndex := 121,
  shape := .direct,
  accumulator := Expr.airValue 175,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_121,
  template := template_Main_121,
  hints := [hint_Main_121_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_122_0 : HintTuple := {
  hintIndex := 736,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "25", value := Expr.constant "25" },
    { name := "Main.last_reg_mem_step[24]", value := Expr.add (Expr.airValue 94) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[24][0]", value := Expr.add (Expr.airValue 56) (Expr.constant "0") },
    { name := "Main.last_reg_value[24][1]", value := Expr.add (Expr.airValue 57) (Expr.constant "0") },
  ]
}

def constraint_Main_122 : Expr := Expr.sub (Expr.mul (Expr.airValue 176) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 57) (Expr.challenge 2 0)) (Expr.airValue 56)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 94)) (Expr.challenge 2 0)) (Expr.constant "25")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_122 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 176) hint_Main_122_0)
def link_Main_122 : ValidatedLink := {
  air := "Main",
  constraintIndex := 122,
  shape := .direct,
  accumulator := Expr.airValue 176,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_122,
  template := template_Main_122,
  hints := [hint_Main_122_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_123_0 : HintTuple := {
  hintIndex := 737,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "25", value := Expr.constant "25" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[24][0]", value := Expr.add (Expr.airValue 56) (Expr.constant "0") },
    { name := "Main.last_reg_value[24][1]", value := Expr.add (Expr.airValue 57) (Expr.constant "0") },
  ]
}

def constraint_Main_123 : Expr := Expr.sub (Expr.mul (Expr.airValue 177) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 57) (Expr.challenge 2 0)) (Expr.airValue 56)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "25")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_123 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 177) hint_Main_123_0)
def link_Main_123 : ValidatedLink := {
  air := "Main",
  constraintIndex := 123,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 177,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_123,
  template := template_Main_123,
  hints := [hint_Main_123_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_124_0 : HintTuple := {
  hintIndex := 739,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[25]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 95)) (Expr.constant "1") },
  ]
}

def constraint_Main_124 : Expr := Expr.add (Expr.mul (Expr.airValue 178) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 95)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_124 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 178) hint_Main_124_0)
def link_Main_124 : ValidatedLink := {
  air := "Main",
  constraintIndex := 124,
  shape := .direct,
  accumulator := Expr.airValue 178,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_124,
  template := template_Main_124,
  hints := [hint_Main_124_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_125_0 : HintTuple := {
  hintIndex := 740,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "26", value := Expr.constant "26" },
    { name := "Main.last_reg_mem_step[25]", value := Expr.add (Expr.airValue 95) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[25][0]", value := Expr.add (Expr.airValue 58) (Expr.constant "0") },
    { name := "Main.last_reg_value[25][1]", value := Expr.add (Expr.airValue 59) (Expr.constant "0") },
  ]
}

def constraint_Main_125 : Expr := Expr.sub (Expr.mul (Expr.airValue 179) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 59) (Expr.challenge 2 0)) (Expr.airValue 58)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 95)) (Expr.challenge 2 0)) (Expr.constant "26")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_125 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 179) hint_Main_125_0)
def link_Main_125 : ValidatedLink := {
  air := "Main",
  constraintIndex := 125,
  shape := .direct,
  accumulator := Expr.airValue 179,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_125,
  template := template_Main_125,
  hints := [hint_Main_125_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_126_0 : HintTuple := {
  hintIndex := 741,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "26", value := Expr.constant "26" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[25][0]", value := Expr.add (Expr.airValue 58) (Expr.constant "0") },
    { name := "Main.last_reg_value[25][1]", value := Expr.add (Expr.airValue 59) (Expr.constant "0") },
  ]
}

def constraint_Main_126 : Expr := Expr.sub (Expr.mul (Expr.airValue 180) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 59) (Expr.challenge 2 0)) (Expr.airValue 58)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "26")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_126 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 180) hint_Main_126_0)
def link_Main_126 : ValidatedLink := {
  air := "Main",
  constraintIndex := 126,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 180,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_126,
  template := template_Main_126,
  hints := [hint_Main_126_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_127_0 : HintTuple := {
  hintIndex := 743,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[26]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 96)) (Expr.constant "1") },
  ]
}

def constraint_Main_127 : Expr := Expr.add (Expr.mul (Expr.airValue 181) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 96)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_127 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 181) hint_Main_127_0)
def link_Main_127 : ValidatedLink := {
  air := "Main",
  constraintIndex := 127,
  shape := .direct,
  accumulator := Expr.airValue 181,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_127,
  template := template_Main_127,
  hints := [hint_Main_127_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_128_0 : HintTuple := {
  hintIndex := 744,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "27", value := Expr.constant "27" },
    { name := "Main.last_reg_mem_step[26]", value := Expr.add (Expr.airValue 96) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[26][0]", value := Expr.add (Expr.airValue 60) (Expr.constant "0") },
    { name := "Main.last_reg_value[26][1]", value := Expr.add (Expr.airValue 61) (Expr.constant "0") },
  ]
}

def constraint_Main_128 : Expr := Expr.sub (Expr.mul (Expr.airValue 182) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 61) (Expr.challenge 2 0)) (Expr.airValue 60)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 96)) (Expr.challenge 2 0)) (Expr.constant "27")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_128 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 182) hint_Main_128_0)
def link_Main_128 : ValidatedLink := {
  air := "Main",
  constraintIndex := 128,
  shape := .direct,
  accumulator := Expr.airValue 182,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_128,
  template := template_Main_128,
  hints := [hint_Main_128_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_129_0 : HintTuple := {
  hintIndex := 745,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "27", value := Expr.constant "27" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[26][0]", value := Expr.add (Expr.airValue 60) (Expr.constant "0") },
    { name := "Main.last_reg_value[26][1]", value := Expr.add (Expr.airValue 61) (Expr.constant "0") },
  ]
}

def constraint_Main_129 : Expr := Expr.sub (Expr.mul (Expr.airValue 183) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 61) (Expr.challenge 2 0)) (Expr.airValue 60)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "27")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_129 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 183) hint_Main_129_0)
def link_Main_129 : ValidatedLink := {
  air := "Main",
  constraintIndex := 129,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 183,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_129,
  template := template_Main_129,
  hints := [hint_Main_129_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_130_0 : HintTuple := {
  hintIndex := 747,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[27]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 97)) (Expr.constant "1") },
  ]
}

def constraint_Main_130 : Expr := Expr.add (Expr.mul (Expr.airValue 184) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 97)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_130 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 184) hint_Main_130_0)
def link_Main_130 : ValidatedLink := {
  air := "Main",
  constraintIndex := 130,
  shape := .direct,
  accumulator := Expr.airValue 184,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_130,
  template := template_Main_130,
  hints := [hint_Main_130_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_131_0 : HintTuple := {
  hintIndex := 748,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "28", value := Expr.constant "28" },
    { name := "Main.last_reg_mem_step[27]", value := Expr.add (Expr.airValue 97) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[27][0]", value := Expr.add (Expr.airValue 62) (Expr.constant "0") },
    { name := "Main.last_reg_value[27][1]", value := Expr.add (Expr.airValue 63) (Expr.constant "0") },
  ]
}

def constraint_Main_131 : Expr := Expr.sub (Expr.mul (Expr.airValue 185) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 63) (Expr.challenge 2 0)) (Expr.airValue 62)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 97)) (Expr.challenge 2 0)) (Expr.constant "28")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_131 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 185) hint_Main_131_0)
def link_Main_131 : ValidatedLink := {
  air := "Main",
  constraintIndex := 131,
  shape := .direct,
  accumulator := Expr.airValue 185,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_131,
  template := template_Main_131,
  hints := [hint_Main_131_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_132_0 : HintTuple := {
  hintIndex := 749,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "28", value := Expr.constant "28" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[27][0]", value := Expr.add (Expr.airValue 62) (Expr.constant "0") },
    { name := "Main.last_reg_value[27][1]", value := Expr.add (Expr.airValue 63) (Expr.constant "0") },
  ]
}

def constraint_Main_132 : Expr := Expr.sub (Expr.mul (Expr.airValue 186) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 63) (Expr.challenge 2 0)) (Expr.airValue 62)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "28")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_132 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 186) hint_Main_132_0)
def link_Main_132 : ValidatedLink := {
  air := "Main",
  constraintIndex := 132,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 186,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_132,
  template := template_Main_132,
  hints := [hint_Main_132_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_133_0 : HintTuple := {
  hintIndex := 751,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[28]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 98)) (Expr.constant "1") },
  ]
}

def constraint_Main_133 : Expr := Expr.add (Expr.mul (Expr.airValue 187) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 98)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_133 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 187) hint_Main_133_0)
def link_Main_133 : ValidatedLink := {
  air := "Main",
  constraintIndex := 133,
  shape := .direct,
  accumulator := Expr.airValue 187,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_133,
  template := template_Main_133,
  hints := [hint_Main_133_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_134_0 : HintTuple := {
  hintIndex := 752,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "29", value := Expr.constant "29" },
    { name := "Main.last_reg_mem_step[28]", value := Expr.add (Expr.airValue 98) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[28][0]", value := Expr.add (Expr.airValue 64) (Expr.constant "0") },
    { name := "Main.last_reg_value[28][1]", value := Expr.add (Expr.airValue 65) (Expr.constant "0") },
  ]
}

def constraint_Main_134 : Expr := Expr.sub (Expr.mul (Expr.airValue 188) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 65) (Expr.challenge 2 0)) (Expr.airValue 64)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 98)) (Expr.challenge 2 0)) (Expr.constant "29")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_134 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 188) hint_Main_134_0)
def link_Main_134 : ValidatedLink := {
  air := "Main",
  constraintIndex := 134,
  shape := .direct,
  accumulator := Expr.airValue 188,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_134,
  template := template_Main_134,
  hints := [hint_Main_134_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_135_0 : HintTuple := {
  hintIndex := 753,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "29", value := Expr.constant "29" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[28][0]", value := Expr.add (Expr.airValue 64) (Expr.constant "0") },
    { name := "Main.last_reg_value[28][1]", value := Expr.add (Expr.airValue 65) (Expr.constant "0") },
  ]
}

def constraint_Main_135 : Expr := Expr.sub (Expr.mul (Expr.airValue 189) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 65) (Expr.challenge 2 0)) (Expr.airValue 64)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "29")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_135 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 189) hint_Main_135_0)
def link_Main_135 : ValidatedLink := {
  air := "Main",
  constraintIndex := 135,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 189,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_135,
  template := template_Main_135,
  hints := [hint_Main_135_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_136_0 : HintTuple := {
  hintIndex := 755,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[29]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 99)) (Expr.constant "1") },
  ]
}

def constraint_Main_136 : Expr := Expr.add (Expr.mul (Expr.airValue 190) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 99)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_136 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 190) hint_Main_136_0)
def link_Main_136 : ValidatedLink := {
  air := "Main",
  constraintIndex := 136,
  shape := .direct,
  accumulator := Expr.airValue 190,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_136,
  template := template_Main_136,
  hints := [hint_Main_136_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_137_0 : HintTuple := {
  hintIndex := 756,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "30", value := Expr.constant "30" },
    { name := "Main.last_reg_mem_step[29]", value := Expr.add (Expr.airValue 99) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[29][0]", value := Expr.add (Expr.airValue 66) (Expr.constant "0") },
    { name := "Main.last_reg_value[29][1]", value := Expr.add (Expr.airValue 67) (Expr.constant "0") },
  ]
}

def constraint_Main_137 : Expr := Expr.sub (Expr.mul (Expr.airValue 191) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 67) (Expr.challenge 2 0)) (Expr.airValue 66)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 99)) (Expr.challenge 2 0)) (Expr.constant "30")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_137 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 191) hint_Main_137_0)
def link_Main_137 : ValidatedLink := {
  air := "Main",
  constraintIndex := 137,
  shape := .direct,
  accumulator := Expr.airValue 191,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_137,
  template := template_Main_137,
  hints := [hint_Main_137_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_138_0 : HintTuple := {
  hintIndex := 757,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "30", value := Expr.constant "30" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[29][0]", value := Expr.add (Expr.airValue 66) (Expr.constant "0") },
    { name := "Main.last_reg_value[29][1]", value := Expr.add (Expr.airValue 67) (Expr.constant "0") },
  ]
}

def constraint_Main_138 : Expr := Expr.sub (Expr.mul (Expr.airValue 192) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 67) (Expr.challenge 2 0)) (Expr.airValue 66)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "30")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_138 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 192) hint_Main_138_0)
def link_Main_138 : ValidatedLink := {
  air := "Main",
  constraintIndex := 138,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 192,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_138,
  template := template_Main_138,
  hints := [hint_Main_138_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_139_0 : HintTuple := {
  hintIndex := 759,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "(last_segment_reg_mem_step - Main.last_reg_mem_step[30]) - 1", value := Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 100)) (Expr.constant "1") },
  ]
}

def constraint_Main_139 : Expr := Expr.add (Expr.mul (Expr.airValue 193) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.airValue 100)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_139 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 193) hint_Main_139_0)
def link_Main_139 : ValidatedLink := {
  air := "Main",
  constraintIndex := 139,
  shape := .direct,
  accumulator := Expr.airValue 193,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_139,
  template := template_Main_139,
  hints := [hint_Main_139_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_140_0 : HintTuple := {
  hintIndex := 760,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "31", value := Expr.constant "31" },
    { name := "Main.last_reg_mem_step[30]", value := Expr.add (Expr.airValue 100) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[30][0]", value := Expr.add (Expr.airValue 68) (Expr.constant "0") },
    { name := "Main.last_reg_value[30][1]", value := Expr.add (Expr.airValue 69) (Expr.constant "0") },
  ]
}

def constraint_Main_140 : Expr := Expr.sub (Expr.mul (Expr.airValue 194) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 69) (Expr.challenge 2 0)) (Expr.airValue 68)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.airValue 100)) (Expr.challenge 2 0)) (Expr.constant "31")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_140 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 194) hint_Main_140_0)
def link_Main_140 : ValidatedLink := {
  air := "Main",
  constraintIndex := 140,
  shape := .direct,
  accumulator := Expr.airValue 194,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_140,
  template := template_Main_140,
  hints := [hint_Main_140_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_141_0 : HintTuple := {
  hintIndex := 761,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 0),
  slots := [
    { name := "3", value := Expr.constant "3" },
    { name := "31", value := Expr.constant "31" },
    { name := "last_segment_reg_mem_step", value := Expr.add (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1")) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "Main.last_reg_value[30][0]", value := Expr.add (Expr.airValue 68) (Expr.constant "0") },
    { name := "Main.last_reg_value[30][1]", value := Expr.add (Expr.airValue 69) (Expr.constant "0") },
  ]
}

def constraint_Main_141 : Expr := Expr.sub (Expr.mul (Expr.airValue 195) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 69) (Expr.challenge 2 0)) (Expr.airValue 68)) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.sub (Expr.add (Expr.add (Expr.constant "1") (Expr.mul (Expr.constant "4") (Expr.sub (Expr.mul (Expr.add (Expr.airValue 1) (Expr.constant "1")) (Expr.constant "4194304")) (Expr.constant "1")))) (Expr.constant "4")) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "31")) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.sub (Expr.constant "1") (Expr.airValue 0)))
def template_Main_141 : Expr := normalise (directAssumesNegFormTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 195) hint_Main_141_0)
def link_Main_141 : ValidatedLink := {
  air := "Main",
  constraintIndex := 141,
  shape := .directAssumesNegForm,
  accumulator := Expr.airValue 195,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_141,
  template := template_Main_141,
  hints := [hint_Main_141_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Main_142_0 : HintTuple := {
  hintIndex := 766,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "106",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "Main.main_segment", value := Expr.add (Expr.airValue 1) (Expr.constant "0") },
  ]
}

def constraint_Main_142 : Expr := Expr.add (Expr.mul (Expr.airValue 196) (Expr.add (Expr.add (Expr.mul (Expr.airValue 1) (Expr.challenge 2 0)) (Expr.constant "106")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Main_142 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 196) hint_Main_142_0)
def link_Main_142 : ValidatedLink := {
  air := "Main",
  constraintIndex := 142,
  shape := .direct,
  accumulator := Expr.airValue 196,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Main_142,
  template := template_Main_142,
  hints := [hint_Main_142_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_Main_143 : Expr := Expr.mul (Expr.fixed 2 (1)) (Expr.sub (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.airValue 101) (Expr.airValue 102)) (Expr.airValue 103)) (Expr.airValue 104)) (Expr.airValue 105)) (Expr.airValue 106)) (Expr.airValue 107)) (Expr.airValue 108)) (Expr.airValue 109)) (Expr.airValue 110)) (Expr.airValue 111)) (Expr.airValue 112)) (Expr.airValue 113)) (Expr.airValue 114)) (Expr.airValue 115)) (Expr.airValue 116)) (Expr.airValue 117)) (Expr.airValue 118)) (Expr.airValue 119)) (Expr.airValue 120)) (Expr.airValue 121)) (Expr.airValue 122)) (Expr.airValue 123)) (Expr.airValue 124)) (Expr.airValue 125)) (Expr.airValue 126)) (Expr.airValue 127)) (Expr.airValue 128)) (Expr.airValue 129)) (Expr.airValue 130)) (Expr.airValue 131)) (Expr.airValue 132)) (Expr.airValue 133)) (Expr.airValue 134)) (Expr.airValue 135)) (Expr.airValue 136)) (Expr.airValue 137)) (Expr.airValue 138)) (Expr.airValue 139)) (Expr.airValue 140)) (Expr.airValue 141)) (Expr.airValue 142)) (Expr.airValue 143)) (Expr.airValue 144)) (Expr.airValue 145)) (Expr.airValue 146)) (Expr.airValue 147)) (Expr.airValue 148)) (Expr.airValue 149)) (Expr.airValue 150)) (Expr.airValue 151)) (Expr.airValue 152)) (Expr.airValue 153)) (Expr.airValue 154)) (Expr.airValue 155)) (Expr.airValue 156)) (Expr.airValue 157)) (Expr.airValue 158)) (Expr.airValue 159)) (Expr.airValue 160)) (Expr.airValue 161)) (Expr.airValue 162)) (Expr.airValue 163)) (Expr.airValue 164)) (Expr.airValue 165)) (Expr.airValue 166)) (Expr.airValue 167)) (Expr.airValue 168)) (Expr.airValue 169)) (Expr.airValue 170)) (Expr.airValue 171)) (Expr.airValue 172)) (Expr.airValue 173)) (Expr.airValue 174)) (Expr.airValue 175)) (Expr.airValue 176)) (Expr.airValue 177)) (Expr.airValue 178)) (Expr.airValue 179)) (Expr.airValue 180)) (Expr.airValue 181)) (Expr.airValue 182)) (Expr.airValue 183)) (Expr.airValue 184)) (Expr.airValue 185)) (Expr.airValue 186)) (Expr.airValue 187)) (Expr.airValue 188)) (Expr.airValue 189)) (Expr.airValue 190)) (Expr.airValue 191)) (Expr.airValue 192)) (Expr.airValue 193)) (Expr.airValue 194)) (Expr.airValue 195)) (Expr.airValue 196)))
def template_Main_143 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 2 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [Expr.airValue 101, Expr.airValue 102, Expr.airValue 103, Expr.airValue 104, Expr.airValue 105, Expr.airValue 106, Expr.airValue 107, Expr.airValue 108, Expr.airValue 109, Expr.airValue 110, Expr.airValue 111, Expr.airValue 112, Expr.airValue 113, Expr.airValue 114, Expr.airValue 115, Expr.airValue 116, Expr.airValue 117, Expr.airValue 118, Expr.airValue 119, Expr.airValue 120, Expr.airValue 121, Expr.airValue 122, Expr.airValue 123, Expr.airValue 124, Expr.airValue 125, Expr.airValue 126, Expr.airValue 127, Expr.airValue 128, Expr.airValue 129, Expr.airValue 130, Expr.airValue 131, Expr.airValue 132, Expr.airValue 133, Expr.airValue 134, Expr.airValue 135, Expr.airValue 136, Expr.airValue 137, Expr.airValue 138, Expr.airValue 139, Expr.airValue 140, Expr.airValue 141, Expr.airValue 142, Expr.airValue 143, Expr.airValue 144, Expr.airValue 145, Expr.airValue 146, Expr.airValue 147, Expr.airValue 148, Expr.airValue 149, Expr.airValue 150, Expr.airValue 151, Expr.airValue 152, Expr.airValue 153, Expr.airValue 154, Expr.airValue 155, Expr.airValue 156, Expr.airValue 157, Expr.airValue 158, Expr.airValue 159, Expr.airValue 160, Expr.airValue 161, Expr.airValue 162, Expr.airValue 163, Expr.airValue 164, Expr.airValue 165, Expr.airValue 166, Expr.airValue 167, Expr.airValue 168, Expr.airValue 169, Expr.airValue 170, Expr.airValue 171, Expr.airValue 172, Expr.airValue 173, Expr.airValue 174, Expr.airValue 175, Expr.airValue 176, Expr.airValue 177, Expr.airValue 178, Expr.airValue 179, Expr.airValue 180, Expr.airValue 181, Expr.airValue 182, Expr.airValue 183, Expr.airValue 184, Expr.airValue 185, Expr.airValue 186, Expr.airValue 187, Expr.airValue 188, Expr.airValue 189, Expr.airValue 190, Expr.airValue 191, Expr.airValue 192, Expr.airValue 193, Expr.airValue 194, Expr.airValue 195, Expr.airValue 196])
def link_Main_143 : ValidatedFinalRow := {
  air := "Main",
  constraintIndex := 143,
  shape := .gsumFinalRow,
  selector := Expr.fixed 2 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [Expr.airValue 101, Expr.airValue 102, Expr.airValue 103, Expr.airValue 104, Expr.airValue 105, Expr.airValue 106, Expr.airValue 107, Expr.airValue 108, Expr.airValue 109, Expr.airValue 110, Expr.airValue 111, Expr.airValue 112, Expr.airValue 113, Expr.airValue 114, Expr.airValue 115, Expr.airValue 116, Expr.airValue 117, Expr.airValue 118, Expr.airValue 119, Expr.airValue 120, Expr.airValue 121, Expr.airValue 122, Expr.airValue 123, Expr.airValue 124, Expr.airValue 125, Expr.airValue 126, Expr.airValue 127, Expr.airValue 128, Expr.airValue 129, Expr.airValue 130, Expr.airValue 131, Expr.airValue 132, Expr.airValue 133, Expr.airValue 134, Expr.airValue 135, Expr.airValue 136, Expr.airValue 137, Expr.airValue 138, Expr.airValue 139, Expr.airValue 140, Expr.airValue 141, Expr.airValue 142, Expr.airValue 143, Expr.airValue 144, Expr.airValue 145, Expr.airValue 146, Expr.airValue 147, Expr.airValue 148, Expr.airValue 149, Expr.airValue 150, Expr.airValue 151, Expr.airValue 152, Expr.airValue 153, Expr.airValue 154, Expr.airValue 155, Expr.airValue 156, Expr.airValue 157, Expr.airValue 158, Expr.airValue 159, Expr.airValue 160, Expr.airValue 161, Expr.airValue 162, Expr.airValue 163, Expr.airValue 164, Expr.airValue 165, Expr.airValue 166, Expr.airValue 167, Expr.airValue 168, Expr.airValue 169, Expr.airValue 170, Expr.airValue 171, Expr.airValue 172, Expr.airValue 173, Expr.airValue 174, Expr.airValue 175, Expr.airValue 176, Expr.airValue 177, Expr.airValue 178, Expr.airValue 179, Expr.airValue 180, Expr.airValue 181, Expr.airValue 182, Expr.airValue 183, Expr.airValue 184, Expr.airValue 185, Expr.airValue 186, Expr.airValue 187, Expr.airValue 188, Expr.airValue 189, Expr.airValue 190, Expr.airValue 191, Expr.airValue 192, Expr.airValue 193, Expr.airValue 194, Expr.airValue 195, Expr.airValue 196],
  constraint := constraint_Main_143,
  template := template_Main_143,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def links_Main_reload : List ValidatedLink := [
  link_Main_50,
  link_Main_53,
  link_Main_56,
  link_Main_59,
  link_Main_62,
  link_Main_65,
  link_Main_68,
  link_Main_71,
  link_Main_74,
  link_Main_77,
  link_Main_80,
  link_Main_83,
  link_Main_86,
  link_Main_89,
  link_Main_92,
  link_Main_95,
  link_Main_98,
  link_Main_101,
  link_Main_104,
  link_Main_107,
  link_Main_110,
  link_Main_113,
  link_Main_116,
  link_Main_119,
  link_Main_122,
  link_Main_125,
  link_Main_128,
  link_Main_131,
  link_Main_134,
  link_Main_137,
  link_Main_140,
]

def link_Main_reload (index : Fin 31) : ValidatedLink :=
  links_Main_reload.get (Fin.cast (by rfl) index)

def links_Main_reloadRange : List ValidatedLink := [
  link_Main_49,
  link_Main_52,
  link_Main_55,
  link_Main_58,
  link_Main_61,
  link_Main_64,
  link_Main_67,
  link_Main_70,
  link_Main_73,
  link_Main_76,
  link_Main_79,
  link_Main_82,
  link_Main_85,
  link_Main_88,
  link_Main_91,
  link_Main_94,
  link_Main_97,
  link_Main_100,
  link_Main_103,
  link_Main_106,
  link_Main_109,
  link_Main_112,
  link_Main_115,
  link_Main_118,
  link_Main_121,
  link_Main_124,
  link_Main_127,
  link_Main_130,
  link_Main_133,
  link_Main_136,
  link_Main_139,
]

def link_Main_reloadRange (index : Fin 31) : ValidatedLink :=
  links_Main_reloadRange.get (Fin.cast (by rfl) index)

def constraintOnly_Mem_0 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 0,
  constraint := Expr.mul (Expr.airValue 1) (Expr.sub (Expr.constant "1") (Expr.airValue 1)),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:103 Mem.is_first_segment*(1-Mem.is_first_segment)"
}

def constraintOnly_Mem_1 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 1,
  constraint := Expr.mul (Expr.airValue 2) (Expr.sub (Expr.constant "1") (Expr.airValue 2)),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:104 Mem.is_last_segment*(1-Mem.is_last_segment)"
}

def constraintOnly_Mem_2 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 2,
  constraint := Expr.mul (Expr.airValue 1) (Expr.airValue 0),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:107 Mem.is_first_segment*Mem.segment_id"
}

def constraintOnly_Mem_9 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 9,
  constraint := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.witness 1 6 (0)) (Expr.airValue 7)),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:215 Mem.SEGMENT_L1'*(value[0]-Mem.segment_last_value[0])"
}

def constraintOnly_Mem_10 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 10,
  constraint := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.witness 1 7 (0)) (Expr.airValue 8)),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:215 Mem.SEGMENT_L1'*(value[1]-Mem.segment_last_value[1])"
}

def constraintOnly_Mem_11 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 11,
  constraint := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.witness 1 0 (0)) (Expr.airValue 10)),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:220 Mem.SEGMENT_L1'*(addr-Mem.segment_last_addr)"
}

def constraintOnly_Mem_12 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 12,
  constraint := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 1 (0)))) (Expr.witness 1 1 (0))) (Expr.airValue 9)),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:226 Mem.SEGMENT_L1'*(((sel_dual*(step_dual-step))+step)-Mem.segment_last_step)"
}

def constraintOnly_Mem_13 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 13,
  constraint := Expr.sub (Expr.sub (Expr.airValue 6) (Expr.constant "335544320")) (Expr.add (Expr.airValue 11) (Expr.mul (Expr.constant "65536") (Expr.airValue 12))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:265 (Mem.previous_segment_addr-335544320)-(Mem.distance_base[0]+(65536*Mem.distance_base[1]))"
}

def constraintOnly_Mem_14 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 14,
  constraint := Expr.sub (Expr.sub (Expr.constant "402653183") (Expr.airValue 10)) (Expr.add (Expr.airValue 13) (Expr.mul (Expr.constant "65536") (Expr.airValue 14))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:283 (402653183-Mem.segment_last_addr)-(Mem.distance_end[0]+(65536*Mem.distance_end[1]))"
}

def constraintOnly_Mem_15 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 15,
  constraint := Expr.sub (Expr.witness 1 9 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 5) (Expr.add (Expr.mul (Expr.witness 1 5 (-1)) (Expr.sub (Expr.witness 1 4 (-1)) (Expr.witness 1 1 (-1)))) (Expr.witness 1 1 (-1))))) (Expr.add (Expr.mul (Expr.witness 1 5 (-1)) (Expr.sub (Expr.witness 1 4 (-1)) (Expr.witness 1 1 (-1)))) (Expr.witness 1 1 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:367 previous_step-((Mem.SEGMENT_L1*(Mem.previous_segment_step-(previous_row_step)))+(previous_row_step))"
}

def constraintOnly_Mem_16 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 16,
  constraint := Expr.sub (Expr.add (Expr.add (Expr.witness 1 10 (0)) (Expr.mul (Expr.constant "4194304") (Expr.witness 1 11 (0)))) (Expr.constant "1")) (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.sub (Expr.sub (Expr.witness 1 0 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 6) (Expr.witness 1 0 (-1)))) (Expr.witness 1 0 (-1)))) (Expr.add (Expr.sub (Expr.witness 1 1 (0)) (Expr.witness 1 9 (0))) (Expr.sub (Expr.constant "1") (Expr.witness 1 8 (0)))))) (Expr.add (Expr.sub (Expr.witness 1 1 (0)) (Expr.witness 1 9 (0))) (Expr.sub (Expr.constant "1") (Expr.witness 1 8 (0))))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:375 ((l_increment+(4194304*h_increment))+1)-((addr_changes*((delta_addr)-(delta_step)))+(delta_step))"
}

def constraintOnly_Mem_17 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 17,
  constraint := Expr.mul (Expr.mul (Expr.airValue 1) (Expr.fixed 0 (0))) (Expr.sub (Expr.constant "1") (Expr.witness 1 3 (0))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:377 (Mem.is_first_segment*Mem.SEGMENT_L1)*(1-addr_changes)"
}

def constraintOnly_Mem_19 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 19,
  constraint := Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 3 (0))) (Expr.sub (Expr.witness 1 0 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 6) (Expr.witness 1 0 (-1)))) (Expr.witness 1 0 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:403 (1-addr_changes)*(addr-(previous_addr))"
}

def constraintOnly_Mem_20 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 20,
  constraint := Expr.mul (Expr.witness 1 12 (0)) (Expr.sub (Expr.witness 1 6 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 3) (Expr.witness 1 6 (-1)))) (Expr.witness 1 6 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:423 read_same_addr*(value[0]-(previous_value))"
}

def constraintOnly_Mem_22 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 22,
  constraint := Expr.mul (Expr.witness 1 12 (0)) (Expr.sub (Expr.witness 1 7 (0)) (Expr.add (Expr.mul (Expr.fixed 0 (0)) (Expr.sub (Expr.airValue 4) (Expr.witness 1 7 (-1)))) (Expr.witness 1 7 (-1)))),
  reason := "AIR-value relation is not a standard-sum lookup template; separate model correspondence required; source: mem/pil/mem.pil:423 read_same_addr*(value[1]-(previous_value))"
}

def constraintOnly_Mem_33 : ConstraintOnly := {
  air := "Mem",
  constraintIndex := 33,
  constraint := Expr.mul (Expr.fixed 1 (1)) (Expr.sub (Expr.sub (Expr.airValue 0) (Expr.witness 2 0 (0))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.airValue 15) (Expr.airValue 16)) (Expr.airValue 17)) (Expr.airValue 18)) (Expr.airValue 19)) (Expr.airValue 20))),
  reason := "unrecognized standard-sum shape; no remaining hint matches an audited route; source: std_sum.pil:696 __L1__'*((Zisk.gsum_result-gsum)-(((((Mem.im_direct[0]+Mem.im_direct[1])+Mem.im_direct[2])+Mem.im_direct[3])+Mem.im_direct[4])+Mem.im_direct[5]))"
}

def hint_Mem_24_0 : HintTuple := {
  hintIndex := 897,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "h_increment", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
  ]
}

def hint_Mem_24_1 : HintTuple := {
  hintIndex := 900,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0"),
  slots := [
    { name := "(step_dual - step) - wr", value := Expr.sub (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 1 (0))) (Expr.witness 1 8 (0)) },
  ]
}

def constraint_Mem_24 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 11 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 1 (0))) (Expr.witness 1 8 (0))) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 1 (0))) (Expr.witness 1 8 (0))) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.mul (Expr.sub (Expr.constant "0") (Expr.witness 1 5 (0))) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 11 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))))
def template_Mem_24 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_Mem_24_0 hint_Mem_24_1)
def link_Mem_24 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 24,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_24,
  template := template_Mem_24,
  hints := [hint_Mem_24_0, hint_Mem_24_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_25_0 : HintTuple := {
  hintIndex := 901,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0"),
  slots := [
    { name := "mem_op", value := Expr.add (Expr.add (Expr.witness 1 8 (0)) (Expr.constant "1")) (Expr.constant "0") },
    { name := "addr * 8", value := Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8") },
    { name := "step", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "value[0]", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
    { name := "value[1]", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
  ]
}

def hint_Mem_25_1 : HintTuple := {
  hintIndex := 902,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0"),
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "addr * 8", value := Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8") },
    { name := "step_dual", value := Expr.add (Expr.witness 1 4 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "value[0]", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
    { name := "value[1]", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
  ]
}

def constraint_Mem_25 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 8 (0)) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.witness 1 2 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.mul (Expr.witness 1 5 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 8 (0)) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))))
def template_Mem_25 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_Mem_25_0 hint_Mem_25_1)
def link_Mem_25 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 25,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_25,
  template := template_Mem_25,
  hints := [hint_Mem_25_0, hint_Mem_25_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_26_0 : HintTuple := {
  hintIndex := 895,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "104",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "l_increment", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
  ]
}

def constraint_Mem_26 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 1 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.challenge 2 0)) (Expr.constant "104")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Mem_26 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 1 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0)))) hint_Mem_26_0)
def link_Mem_26 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 26,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 1 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_26,
  template := template_Mem_26,
  hints := [hint_Mem_26_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_27_0 : HintTuple := {
  hintIndex := 881,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "11",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "2684354560", value := Expr.constant "2684354560" },
    { name := "Mem.segment_id", value := Expr.add (Expr.airValue 0) (Expr.constant "0") },
    { name := "Mem.previous_segment_addr", value := Expr.add (Expr.airValue 6) (Expr.constant "0") },
    { name := "Mem.previous_segment_step", value := Expr.add (Expr.airValue 5) (Expr.constant "0") },
    { name := "Mem.previous_segment_value[0]", value := Expr.add (Expr.airValue 3) (Expr.constant "0") },
    { name := "Mem.previous_segment_value[1]", value := Expr.add (Expr.airValue 4) (Expr.constant "0") },
  ]
}

def constraint_Mem_27 : Expr := Expr.add (Expr.mul (Expr.airValue 15) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 4) (Expr.challenge 2 0)) (Expr.airValue 3)) (Expr.challenge 2 0)) (Expr.airValue 5)) (Expr.challenge 2 0)) (Expr.airValue 6)) (Expr.challenge 2 0)) (Expr.airValue 0)) (Expr.challenge 2 0)) (Expr.constant "2684354560")) (Expr.challenge 2 0)) (Expr.constant "11")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Mem_27 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 15) hint_Mem_27_0)
def link_Mem_27 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 27,
  shape := .direct,
  accumulator := Expr.airValue 15,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_27,
  template := template_Mem_27,
  hints := [hint_Mem_27_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_28_0 : HintTuple := {
  hintIndex := 882,
  piop := "Direct",
  proves := true,
  busId := Expr.constant "11",
  multiplicity := Expr.sub (Expr.constant "1") (Expr.airValue 2),
  slots := [
    { name := "2684354560", value := Expr.constant "2684354560" },
    { name := "Mem.segment_id + 1", value := Expr.add (Expr.airValue 0) (Expr.constant "1") },
    { name := "Mem.segment_last_addr", value := Expr.add (Expr.airValue 10) (Expr.constant "0") },
    { name := "Mem.segment_last_step", value := Expr.add (Expr.airValue 9) (Expr.constant "0") },
    { name := "Mem.segment_last_value[0]", value := Expr.add (Expr.airValue 7) (Expr.constant "0") },
    { name := "Mem.segment_last_value[1]", value := Expr.add (Expr.airValue 8) (Expr.constant "0") },
  ]
}

def constraint_Mem_28 : Expr := Expr.sub (Expr.mul (Expr.airValue 16) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.airValue 8) (Expr.challenge 2 0)) (Expr.airValue 7)) (Expr.challenge 2 0)) (Expr.airValue 9)) (Expr.challenge 2 0)) (Expr.airValue 10)) (Expr.challenge 2 0)) (Expr.add (Expr.airValue 0) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "2684354560")) (Expr.challenge 2 0)) (Expr.constant "11")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "1") (Expr.airValue 2))
def template_Mem_28 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 16) hint_Mem_28_0)
def link_Mem_28 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 28,
  shape := .direct,
  accumulator := Expr.airValue 16,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_28,
  template := template_Mem_28,
  hints := [hint_Mem_28_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_29_0 : HintTuple := {
  hintIndex := 884,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "Mem.distance_base[0]", value := Expr.add (Expr.airValue 11) (Expr.constant "0") },
  ]
}

def constraint_Mem_29 : Expr := Expr.add (Expr.mul (Expr.airValue 17) (Expr.add (Expr.add (Expr.mul (Expr.airValue 11) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Mem_29 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 17) hint_Mem_29_0)
def link_Mem_29 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 29,
  shape := .direct,
  accumulator := Expr.airValue 17,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_29,
  template := template_Mem_29,
  hints := [hint_Mem_29_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_30_0 : HintTuple := {
  hintIndex := 886,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "Mem.distance_base[1]", value := Expr.add (Expr.airValue 12) (Expr.constant "0") },
  ]
}

def constraint_Mem_30 : Expr := Expr.add (Expr.mul (Expr.airValue 18) (Expr.add (Expr.add (Expr.mul (Expr.airValue 12) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Mem_30 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 18) hint_Mem_30_0)
def link_Mem_30 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 30,
  shape := .direct,
  accumulator := Expr.airValue 18,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_30,
  template := template_Mem_30,
  hints := [hint_Mem_30_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_31_0 : HintTuple := {
  hintIndex := 888,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "Mem.distance_end[0]", value := Expr.add (Expr.airValue 13) (Expr.constant "0") },
  ]
}

def constraint_Mem_31 : Expr := Expr.add (Expr.mul (Expr.airValue 19) (Expr.add (Expr.add (Expr.mul (Expr.airValue 13) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Mem_31 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 19) hint_Mem_31_0)
def link_Mem_31 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 31,
  shape := .direct,
  accumulator := Expr.airValue 19,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_31,
  template := template_Mem_31,
  hints := [hint_Mem_31_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Mem_32_0 : HintTuple := {
  hintIndex := 890,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "Mem.distance_end[1]", value := Expr.add (Expr.airValue 14) (Expr.constant "0") },
  ]
}

def constraint_Mem_32 : Expr := Expr.add (Expr.mul (Expr.airValue 20) (Expr.add (Expr.add (Expr.mul (Expr.airValue 14) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Mem_32 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 20) hint_Mem_32_0)
def link_Mem_32 : ValidatedLink := {
  air := "Mem",
  constraintIndex := 32,
  shape := .direct,
  accumulator := Expr.airValue 20,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Mem_32,
  template := template_Mem_32,
  hints := [hint_Mem_32_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlign_33_0 : HintTuple := {
  hintIndex := 984,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[1]", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlign_33_1 : HintTuple := {
  hintIndex := 986,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[2]", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlign_33 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 9 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 9 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))))
def template_MemAlign_33 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_MemAlign_33_0 hint_MemAlign_33_1)
def link_MemAlign_33 : ValidatedLink := {
  air := "MemAlign",
  constraintIndex := 33,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlign_33,
  template := template_MemAlign_33,
  hints := [hint_MemAlign_33_0, hint_MemAlign_33_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlign_34_0 : HintTuple := {
  hintIndex := 988,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[3]", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlign_34_1 : HintTuple := {
  hintIndex := 990,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[4]", value := Expr.add (Expr.witness 1 12 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlign_34 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 11 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 12 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 12 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 11 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))))
def template_MemAlign_34 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_MemAlign_34_0 hint_MemAlign_34_1)
def link_MemAlign_34 : ValidatedLink := {
  air := "MemAlign",
  constraintIndex := 34,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlign_34,
  template := template_MemAlign_34,
  hints := [hint_MemAlign_34_0, hint_MemAlign_34_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlign_35_0 : HintTuple := {
  hintIndex := 992,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[5]", value := Expr.add (Expr.witness 1 13 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlign_35_1 : HintTuple := {
  hintIndex := 994,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[6]", value := Expr.add (Expr.witness 1 14 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlign_35 : Expr := Expr.sub (Expr.mul (Expr.witness 2 3 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 13 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 14 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 14 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 13 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))))
def template_MemAlign_35 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 3 (0)) hint_MemAlign_35_0 hint_MemAlign_35_1)
def link_MemAlign_35 : ValidatedLink := {
  air := "MemAlign",
  constraintIndex := 35,
  shape := .cluster2,
  accumulator := Expr.witness 2 3 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlign_35,
  template := template_MemAlign_35,
  hints := [hint_MemAlign_35_0, hint_MemAlign_35_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlign_36_0 : HintTuple := {
  hintIndex := 996,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[7]", value := Expr.add (Expr.witness 1 15 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlign_36_1 : HintTuple := {
  hintIndex := 998,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "133",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "pc", value := Expr.add (Expr.witness 1 4 (0)) (Expr.constant "0") },
    { name := "pc' - pc", value := Expr.sub (Expr.witness 1 4 (1)) (Expr.witness 1 4 (0)) },
    { name := "delta_addr", value := Expr.add (Expr.witness 1 25 (0)) (Expr.constant "0") },
    { name := "offset", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
    { name := "width", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "sel[0] + sel[1] * 2 + sel[2] * 4 + sel[3] * 8 + sel[4] * 16 + sel[5] * 32 + sel[6] * 64 + sel[7] * 128 + wr * 256 + reset * 512 + sel_up_to_down * 1024 + sel_down_to_up * 2048", value := Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 16 (0)) (Expr.mul (Expr.witness 1 17 (0)) (Expr.constant "2"))) (Expr.mul (Expr.witness 1 18 (0)) (Expr.constant "4"))) (Expr.mul (Expr.witness 1 19 (0)) (Expr.constant "8"))) (Expr.mul (Expr.witness 1 20 (0)) (Expr.constant "16"))) (Expr.mul (Expr.witness 1 21 (0)) (Expr.constant "32"))) (Expr.mul (Expr.witness 1 22 (0)) (Expr.constant "64"))) (Expr.mul (Expr.witness 1 23 (0)) (Expr.constant "128"))) (Expr.add (Expr.add (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.constant "256")) (Expr.mul (Expr.witness 1 5 (0)) (Expr.constant "512"))) (Expr.mul (Expr.witness 1 6 (0)) (Expr.constant "1024"))) (Expr.mul (Expr.witness 1 7 (0)) (Expr.constant "2048"))) },
  ]
}

def constraint_MemAlign_36 : Expr := Expr.sub (Expr.mul (Expr.witness 2 4 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 15 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 16 (0)) (Expr.mul (Expr.witness 1 17 (0)) (Expr.constant "2"))) (Expr.mul (Expr.witness 1 18 (0)) (Expr.constant "4"))) (Expr.mul (Expr.witness 1 19 (0)) (Expr.constant "8"))) (Expr.mul (Expr.witness 1 20 (0)) (Expr.constant "16"))) (Expr.mul (Expr.witness 1 21 (0)) (Expr.constant "32"))) (Expr.mul (Expr.witness 1 22 (0)) (Expr.constant "64"))) (Expr.mul (Expr.witness 1 23 (0)) (Expr.constant "128"))) (Expr.add (Expr.add (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.constant "256")) (Expr.mul (Expr.witness 1 5 (0)) (Expr.constant "512"))) (Expr.mul (Expr.witness 1 6 (0)) (Expr.constant "1024"))) (Expr.mul (Expr.witness 1 7 (0)) (Expr.constant "2048")))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.witness 1 25 (0))) (Expr.challenge 2 0)) (Expr.sub (Expr.witness 1 4 (1)) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.constant "133")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 16 (0)) (Expr.mul (Expr.witness 1 17 (0)) (Expr.constant "2"))) (Expr.mul (Expr.witness 1 18 (0)) (Expr.constant "4"))) (Expr.mul (Expr.witness 1 19 (0)) (Expr.constant "8"))) (Expr.mul (Expr.witness 1 20 (0)) (Expr.constant "16"))) (Expr.mul (Expr.witness 1 21 (0)) (Expr.constant "32"))) (Expr.mul (Expr.witness 1 22 (0)) (Expr.constant "64"))) (Expr.mul (Expr.witness 1 23 (0)) (Expr.constant "128"))) (Expr.add (Expr.add (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.constant "256")) (Expr.mul (Expr.witness 1 5 (0)) (Expr.constant "512"))) (Expr.mul (Expr.witness 1 6 (0)) (Expr.constant "1024"))) (Expr.mul (Expr.witness 1 7 (0)) (Expr.constant "2048")))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.witness 1 25 (0))) (Expr.challenge 2 0)) (Expr.sub (Expr.witness 1 4 (1)) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.constant "133")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 15 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))))
def template_MemAlign_36 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 4 (0)) hint_MemAlign_36_0 hint_MemAlign_36_1)
def link_MemAlign_36 : ValidatedLink := {
  air := "MemAlign",
  constraintIndex := 36,
  shape := .cluster2,
  accumulator := Expr.witness 2 4 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlign_36,
  template := template_MemAlign_36,
  hints := [hint_MemAlign_36_0, hint_MemAlign_36_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlign_37_0 : HintTuple := {
  hintIndex := 1001,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.sub (Expr.witness 1 26 (0)) (Expr.add (Expr.witness 1 6 (0)) (Expr.witness 1 7 (0))),
  slots := [
    { name := "wr + 1", value := Expr.add (Expr.witness 1 3 (0)) (Expr.constant "1") },
    { name := "addr * 8 + offset", value := Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8")) (Expr.witness 1 1 (0)) },
    { name := "step", value := Expr.add (Expr.witness 1 24 (0)) (Expr.constant "0") },
    { name := "width", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "value[0]", value := Expr.add (Expr.witness 1 27 (0)) (Expr.constant "0") },
    { name := "value[1]", value := Expr.add (Expr.witness 1 28 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlign_37 : Expr := Expr.sub (Expr.mul (Expr.witness 2 5 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 28 (0)) (Expr.challenge 2 0)) (Expr.witness 1 27 (0))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "8")) (Expr.witness 1 1 (0)))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 3 (0)) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.witness 1 26 (0)) (Expr.add (Expr.witness 1 6 (0)) (Expr.witness 1 7 (0))))
def template_MemAlign_37 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 5 (0)) hint_MemAlign_37_0)
def link_MemAlign_37 : ValidatedLink := {
  air := "MemAlign",
  constraintIndex := 37,
  shape := .direct,
  accumulator := Expr.witness 2 5 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlign_37,
  template := template_MemAlign_37,
  hints := [hint_MemAlign_37_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlign_38_0 : HintTuple := {
  hintIndex := 982,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "reg[0]", value := Expr.add (Expr.witness 1 8 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlign_38 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 1 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_MemAlign_38 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 1 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0)))) hint_MemAlign_38_0)
def link_MemAlign_38 : ValidatedLink := {
  air := "MemAlign",
  constraintIndex := 38,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 1 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlign_38,
  template := template_MemAlign_38,
  hints := [hint_MemAlign_38_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_MemAlign_39 : Expr := Expr.mul (Expr.fixed 1 (1)) (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0)))
def template_MemAlign_39 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 1 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [])
def link_MemAlign_39 : ValidatedFinalRow := {
  air := "MemAlign",
  constraintIndex := 39,
  shape := .gsumFinalRow,
  selector := Expr.fixed 1 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [],
  constraint := constraint_MemAlign_39,
  template := template_MemAlign_39,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignByte_9_0 : HintTuple := {
  hintIndex := 1025,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.witness 1 12 (0)) (Expr.constant "0"),
  slots := [
    { name := "2", value := Expr.constant "2" },
    { name := "mem_addr", value := Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.constant "0") },
    { name := "step + 1", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "1") },
    { name := "8", value := Expr.constant "8" },
    { name := "mem_write_values[0]", value := Expr.add (Expr.witness 1 13 (0)) (Expr.constant "0") },
    { name := "mem_write_values[1]", value := Expr.add (Expr.witness 1 14 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlignByte_9_1 : HintTuple := {
  hintIndex := 1027,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "mem_op", value := Expr.add (Expr.add (Expr.constant "1") (Expr.witness 1 12 (0))) (Expr.constant "0") },
    { name := "main_addr", value := Expr.add (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0)))) (Expr.constant "0") },
    { name := "step", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
    { name := "1", value := Expr.constant "1" },
    { name := "bus_byte", value := Expr.add (Expr.witness 1 15 (0)) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignByte_9 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 14 (0)) (Expr.challenge 2 0)) (Expr.witness 1 13 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 11 (0)) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 15 (0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.constant "1") (Expr.witness 1 12 (0)))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.sub (Expr.constant "0") (Expr.witness 1 12 (0))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 15 (0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.constant "1") (Expr.witness 1 12 (0)))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 14 (0)) (Expr.challenge 2 0)) (Expr.witness 1 13 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 11 (0)) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)))
def template_MemAlignByte_9 : Expr := normalise (cluster2ZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_MemAlignByte_9_0 hint_MemAlignByte_9_1)
def link_MemAlignByte_9 : ValidatedLink := {
  air := "MemAlignByte",
  constraintIndex := 9,
  shape := .cluster2ZeroTail,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignByte_9,
  template := template_MemAlignByte_9,
  hints := [hint_MemAlignByte_9_0, hint_MemAlignByte_9_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignByte_10_0 : HintTuple := {
  hintIndex := 1029,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "value_16b", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlignByte_10_1 : HintTuple := {
  hintIndex := 1030,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "88",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "byte_value", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "value_8b", value := Expr.add (Expr.witness 1 8 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlignByte_10 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.constant "88")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.constant "88")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))))
def template_MemAlignByte_10 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_MemAlignByte_10_0 hint_MemAlignByte_10_1)
def link_MemAlignByte_10 : ValidatedLink := {
  air := "MemAlignByte",
  constraintIndex := 10,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignByte_10,
  template := template_MemAlignByte_10,
  hints := [hint_MemAlignByte_10_0, hint_MemAlignByte_10_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignByte_11_0 : HintTuple := {
  hintIndex := 1022,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "mem_addr", value := Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.constant "0") },
    { name := "step", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "sel_high_4b * (direct_value - composed_value) + composed_value", value := Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 3 (0)) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)) },
    { name := "sel_high_4b * (composed_value - direct_value) + direct_value", value := Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 3 (0)))) (Expr.witness 1 3 (0)) },
  ]
}

def constraint_MemAlignByte_11 : Expr := Expr.add (Expr.mul (Expr.witness 2 3 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 3 (0)))) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 3 (0)) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_MemAlignByte_11 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 3 (0)) hint_MemAlignByte_11_0)
def link_MemAlignByte_11 : ValidatedLink := {
  air := "MemAlignByte",
  constraintIndex := 11,
  shape := .direct,
  accumulator := Expr.witness 2 3 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignByte_11,
  template := template_MemAlignByte_11,
  hints := [hint_MemAlignByte_11_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignByte_12_0 : HintTuple := {
  hintIndex := 1016,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "written_byte_value", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlignByte_12 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_MemAlignByte_12 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0)))) hint_MemAlignByte_12_0)
def link_MemAlignByte_12 : ValidatedLink := {
  air := "MemAlignByte",
  constraintIndex := 12,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignByte_12,
  template := template_MemAlignByte_12,
  hints := [hint_MemAlignByte_12_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignByte_13_0 : HintTuple := {
  hintIndex := 1031,
  piop := "Direct",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "8", value := Expr.constant "8" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignByte_13 : Expr := Expr.sub (Expr.mul (Expr.airValue 1) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.mul (Expr.constant "8") (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.airValue 0)
def template_MemAlignByte_13 : Expr := normalise (directZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 1) hint_MemAlignByte_13_0)
def link_MemAlignByte_13 : ValidatedLink := {
  air := "MemAlignByte",
  constraintIndex := 13,
  shape := .directZeroTail,
  accumulator := Expr.airValue 1,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignByte_13,
  template := template_MemAlignByte_13,
  hints := [hint_MemAlignByte_13_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignByte_14_0 : HintTuple := {
  hintIndex := 1032,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignByte_14 : Expr := Expr.sub (Expr.mul (Expr.airValue 2) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.challenge 2 0) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.airValue 0))
def template_MemAlignByte_14 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 2) hint_MemAlignByte_14_0)
def link_MemAlignByte_14 : ValidatedLink := {
  air := "MemAlignByte",
  constraintIndex := 14,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.airValue 2,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignByte_14,
  template := template_MemAlignByte_14,
  hints := [hint_MemAlignByte_14_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_MemAlignByte_15 : Expr := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0))) (Expr.add (Expr.airValue 1) (Expr.airValue 2)))
def template_MemAlignByte_15 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 0 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [Expr.airValue 1, Expr.airValue 2])
def link_MemAlignByte_15 : ValidatedFinalRow := {
  air := "MemAlignByte",
  constraintIndex := 15,
  shape := .gsumFinalRow,
  selector := Expr.fixed 0 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [Expr.airValue 1, Expr.airValue 2],
  constraint := constraint_MemAlignByte_15,
  template := template_MemAlignByte_15,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignReadByte_4_0 : HintTuple := {
  hintIndex := 1052,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "value_16b", value := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlignReadByte_4_1 : HintTuple := {
  hintIndex := 1053,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "88",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "byte_value", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
    { name := "value_8b", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlignReadByte_4 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.witness 1 7 (0))) (Expr.challenge 2 0)) (Expr.constant "88")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.witness 1 7 (0))) (Expr.challenge 2 0)) (Expr.constant "88")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))))
def template_MemAlignReadByte_4 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_MemAlignReadByte_4_0 hint_MemAlignReadByte_4_1)
def link_MemAlignReadByte_4 : ValidatedLink := {
  air := "MemAlignReadByte",
  constraintIndex := 4,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignReadByte_4,
  template := template_MemAlignReadByte_4,
  hints := [hint_MemAlignReadByte_4_0, hint_MemAlignReadByte_4_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignReadByte_5_0 : HintTuple := {
  hintIndex := 1049,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "mem_addr", value := Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "8")) (Expr.constant "0") },
    { name := "step", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "sel_high_4b * (direct_value - composed_value) + composed_value", value := Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 3 (0)) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)) },
    { name := "sel_high_4b * (composed_value - direct_value) + direct_value", value := Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 3 (0)))) (Expr.witness 1 3 (0)) },
  ]
}

def constraint_MemAlignReadByte_5 : Expr := Expr.add (Expr.mul (Expr.witness 2 2 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 3 (0)))) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 3 (0)) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_MemAlignReadByte_5 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_MemAlignReadByte_5_0)
def link_MemAlignReadByte_5 : ValidatedLink := {
  air := "MemAlignReadByte",
  constraintIndex := 5,
  shape := .direct,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignReadByte_5,
  template := template_MemAlignReadByte_5,
  hints := [hint_MemAlignReadByte_5_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignReadByte_6_0 : HintTuple := {
  hintIndex := 1050,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "main_addr", value := Expr.add (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0)))) (Expr.constant "0") },
    { name := "step", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "1", value := Expr.constant "1" },
    { name := "byte_value", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignReadByte_6 : Expr := Expr.sub (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0))))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_MemAlignReadByte_6 : Expr := normalise (directZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0)))) hint_MemAlignReadByte_6_0)
def link_MemAlignReadByte_6 : ValidatedLink := {
  air := "MemAlignReadByte",
  constraintIndex := 6,
  shape := .directZeroTail,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignReadByte_6,
  template := template_MemAlignReadByte_6,
  hints := [hint_MemAlignReadByte_6_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignReadByte_7_0 : HintTuple := {
  hintIndex := 1054,
  piop := "Direct",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "8", value := Expr.constant "8" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignReadByte_7 : Expr := Expr.sub (Expr.mul (Expr.airValue 1) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.mul (Expr.constant "8") (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.airValue 0)
def template_MemAlignReadByte_7 : Expr := normalise (directZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 1) hint_MemAlignReadByte_7_0)
def link_MemAlignReadByte_7 : ValidatedLink := {
  air := "MemAlignReadByte",
  constraintIndex := 7,
  shape := .directZeroTail,
  accumulator := Expr.airValue 1,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignReadByte_7,
  template := template_MemAlignReadByte_7,
  hints := [hint_MemAlignReadByte_7_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignReadByte_8_0 : HintTuple := {
  hintIndex := 1055,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignReadByte_8 : Expr := Expr.sub (Expr.mul (Expr.airValue 2) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.challenge 2 0) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.airValue 0))
def template_MemAlignReadByte_8 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 2) hint_MemAlignReadByte_8_0)
def link_MemAlignReadByte_8 : ValidatedLink := {
  air := "MemAlignReadByte",
  constraintIndex := 8,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.airValue 2,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignReadByte_8,
  template := template_MemAlignReadByte_8,
  hints := [hint_MemAlignReadByte_8_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_MemAlignReadByte_9 : Expr := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0))) (Expr.add (Expr.airValue 1) (Expr.airValue 2)))
def template_MemAlignReadByte_9 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 0 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [Expr.airValue 1, Expr.airValue 2])
def link_MemAlignReadByte_9 : ValidatedFinalRow := {
  air := "MemAlignReadByte",
  constraintIndex := 9,
  shape := .gsumFinalRow,
  selector := Expr.fixed 0 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [Expr.airValue 1, Expr.airValue 2],
  constraint := constraint_MemAlignReadByte_9,
  template := template_MemAlignReadByte_9,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignWriteByte_7_0 : HintTuple := {
  hintIndex := 1077,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "2", value := Expr.constant "2" },
    { name := "mem_addr", value := Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.constant "0") },
    { name := "step + 1", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "1") },
    { name := "8", value := Expr.constant "8" },
    { name := "mem_write_values[0]", value := Expr.add (Expr.witness 1 12 (0)) (Expr.constant "0") },
    { name := "mem_write_values[1]", value := Expr.add (Expr.witness 1 13 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlignWriteByte_7_1 : HintTuple := {
  hintIndex := 1078,
  piop := "Permutation",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "2", value := Expr.constant "2" },
    { name := "main_addr", value := Expr.add (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0)))) (Expr.constant "0") },
    { name := "step", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
    { name := "1", value := Expr.constant "1" },
    { name := "written_byte_value", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignWriteByte_7 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 13 (0)) (Expr.challenge 2 0)) (Expr.witness 1 12 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 11 (0)) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0))))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.constant "4")) (Expr.mul (Expr.witness 1 1 (0)) (Expr.constant "2"))) (Expr.witness 1 2 (0))))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 13 (0)) (Expr.challenge 2 0)) (Expr.witness 1 12 (0))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 11 (0)) (Expr.constant "1"))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1)))
def template_MemAlignWriteByte_7 : Expr := normalise (cluster2ZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_MemAlignWriteByte_7_0 hint_MemAlignWriteByte_7_1)
def link_MemAlignWriteByte_7 : ValidatedLink := {
  air := "MemAlignWriteByte",
  constraintIndex := 7,
  shape := .cluster2ZeroTail,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignWriteByte_7,
  template := template_MemAlignWriteByte_7,
  hints := [hint_MemAlignWriteByte_7_0, hint_MemAlignWriteByte_7_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignWriteByte_8_0 : HintTuple := {
  hintIndex := 1080,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "value_16b", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
  ]
}

def hint_MemAlignWriteByte_8_1 : HintTuple := {
  hintIndex := 1081,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "88",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "byte_value", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "value_8b", value := Expr.add (Expr.witness 1 8 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlignWriteByte_8 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.constant "88")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.constant "88")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))))
def template_MemAlignWriteByte_8 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_MemAlignWriteByte_8_0 hint_MemAlignWriteByte_8_1)
def link_MemAlignWriteByte_8 : ValidatedLink := {
  air := "MemAlignWriteByte",
  constraintIndex := 8,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignWriteByte_8,
  template := template_MemAlignWriteByte_8,
  hints := [hint_MemAlignWriteByte_8_0, hint_MemAlignWriteByte_8_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignWriteByte_9_0 : HintTuple := {
  hintIndex := 1075,
  piop := "Permutation",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "mem_addr", value := Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8")) (Expr.constant "0") },
    { name := "step", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
    { name := "8", value := Expr.constant "8" },
    { name := "sel_high_4b * (direct_value - composed_value) + composed_value", value := Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 3 (0)) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)) },
    { name := "sel_high_4b * (composed_value - direct_value) + direct_value", value := Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 3 (0)))) (Expr.witness 1 3 (0)) },
  ]
}

def constraint_MemAlignWriteByte_9 : Expr := Expr.add (Expr.mul (Expr.witness 2 3 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 4 (0)) (Expr.witness 1 3 (0)))) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.sub (Expr.witness 1 3 (0)) (Expr.witness 1 4 (0)))) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.constant "8")) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "8"))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_MemAlignWriteByte_9 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 3 (0)) hint_MemAlignWriteByte_9_0)
def link_MemAlignWriteByte_9 : ValidatedLink := {
  air := "MemAlignWriteByte",
  constraintIndex := 9,
  shape := .direct,
  accumulator := Expr.witness 2 3 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignWriteByte_9,
  template := template_MemAlignWriteByte_9,
  hints := [hint_MemAlignWriteByte_9_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignWriteByte_10_0 : HintTuple := {
  hintIndex := 1069,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "107",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "written_byte_value", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
  ]
}

def constraint_MemAlignWriteByte_10 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "107")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_MemAlignWriteByte_10 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0)))) hint_MemAlignWriteByte_10_0)
def link_MemAlignWriteByte_10 : ValidatedLink := {
  air := "MemAlignWriteByte",
  constraintIndex := 10,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignWriteByte_10,
  template := template_MemAlignWriteByte_10,
  hints := [hint_MemAlignWriteByte_10_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignWriteByte_11_0 : HintTuple := {
  hintIndex := 1082,
  piop := "Direct",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "8", value := Expr.constant "8" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignWriteByte_11 : Expr := Expr.sub (Expr.mul (Expr.airValue 1) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.mul (Expr.constant "8") (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.airValue 0)
def template_MemAlignWriteByte_11 : Expr := normalise (directZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 1) hint_MemAlignWriteByte_11_0)
def link_MemAlignWriteByte_11 : ValidatedLink := {
  air := "MemAlignWriteByte",
  constraintIndex := 11,
  shape := .directZeroTail,
  accumulator := Expr.airValue 1,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignWriteByte_11,
  template := template_MemAlignWriteByte_11,
  hints := [hint_MemAlignWriteByte_11_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignWriteByte_12_0 : HintTuple := {
  hintIndex := 1083,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "2", value := Expr.constant "2" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignWriteByte_12 : Expr := Expr.sub (Expr.mul (Expr.airValue 2) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.challenge 2 0) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.airValue 0))
def template_MemAlignWriteByte_12 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 2) hint_MemAlignWriteByte_12_0)
def link_MemAlignWriteByte_12 : ValidatedLink := {
  air := "MemAlignWriteByte",
  constraintIndex := 12,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.airValue 2,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignWriteByte_12,
  template := template_MemAlignWriteByte_12,
  hints := [hint_MemAlignWriteByte_12_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_MemAlignWriteByte_13_0 : HintTuple := {
  hintIndex := 1084,
  piop := "Direct",
  proves := true,
  busId := Expr.constant "10",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "2", value := Expr.constant "2" },
    { name := "0", value := Expr.constant "0" },
    { name := "1", value := Expr.constant "1" },
    { name := "8", value := Expr.constant "8" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_MemAlignWriteByte_13 : Expr := Expr.sub (Expr.mul (Expr.airValue 3) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.constant "8") (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 1))) (Expr.airValue 0)
def template_MemAlignWriteByte_13 : Expr := normalise (directZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 3) hint_MemAlignWriteByte_13_0)
def link_MemAlignWriteByte_13 : ValidatedLink := {
  air := "MemAlignWriteByte",
  constraintIndex := 13,
  shape := .directZeroTail,
  accumulator := Expr.airValue 3,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_MemAlignWriteByte_13,
  template := template_MemAlignWriteByte_13,
  hints := [hint_MemAlignWriteByte_13_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_MemAlignWriteByte_14 : Expr := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0))) (Expr.add (Expr.add (Expr.airValue 1) (Expr.airValue 2)) (Expr.airValue 3)))
def template_MemAlignWriteByte_14 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 0 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [Expr.airValue 1, Expr.airValue 2, Expr.airValue 3])
def link_MemAlignWriteByte_14 : ValidatedFinalRow := {
  air := "MemAlignWriteByte",
  constraintIndex := 14,
  shape := .gsumFinalRow,
  selector := Expr.fixed 0 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [Expr.airValue 1, Expr.airValue 2, Expr.airValue 3],
  constraint := constraint_MemAlignWriteByte_14,
  template := template_MemAlignWriteByte_14,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_49_0 : HintTuple := {
  hintIndex := 1119,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "100", value := Expr.constant "100" },
    { name := "carry[1]", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_49_1 : HintTuple := {
  hintIndex := 1120,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "100", value := Expr.constant "100" },
    { name := "carry[2]", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_49 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 1 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 2 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 2 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 1 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_49 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_Arith_49_0 hint_Arith_49_1)
def link_Arith_49 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 49,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_49,
  template := template_Arith_49,
  hints := [hint_Arith_49_0, hint_Arith_49_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_50_0 : HintTuple := {
  hintIndex := 1121,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "100", value := Expr.constant "100" },
    { name := "carry[3]", value := Expr.add (Expr.witness 1 3 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_50_1 : HintTuple := {
  hintIndex := 1122,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "100", value := Expr.constant "100" },
    { name := "carry[4]", value := Expr.add (Expr.witness 1 4 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_50 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 4 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 4 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 3 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_50 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_Arith_50_0 hint_Arith_50_1)
def link_Arith_50 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 50,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_50,
  template := template_Arith_50,
  hints := [hint_Arith_50_0, hint_Arith_50_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_51_0 : HintTuple := {
  hintIndex := 1123,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "100", value := Expr.constant "100" },
    { name := "carry[5]", value := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_51_1 : HintTuple := {
  hintIndex := 1124,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "100", value := Expr.constant "100" },
    { name := "carry[6]", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_51 : Expr := Expr.sub (Expr.mul (Expr.witness 2 3 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_51 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 3 (0)) hint_Arith_51_0 hint_Arith_51_1)
def link_Arith_51 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 51,
  shape := .cluster2,
  accumulator := Expr.witness 2 3 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_51,
  template := template_Arith_51,
  hints := [hint_Arith_51_0, hint_Arith_51_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_52_0 : HintTuple := {
  hintIndex := 1127,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "331",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 39 (0)) (Expr.constant "0") },
    { name := "m32 + 2 * div + 4 * na + 8 * nb + 16 * np + 32 * nr + 64 * sext + 128 * div_by_zero + 256 * div_overflow + 512 * main_mul + 1024 * main_div + 2048 * signed", value := Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 28 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 29 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 24 (0)))) (Expr.mul (Expr.constant "16") (Expr.witness 1 26 (0)))) (Expr.mul (Expr.constant "32") (Expr.witness 1 25 (0)))) (Expr.mul (Expr.constant "64") (Expr.witness 1 27 (0)))) (Expr.mul (Expr.constant "128") (Expr.witness 1 36 (0)))) (Expr.mul (Expr.constant "256") (Expr.witness 1 37 (0)))) (Expr.mul (Expr.constant "512") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "1024") (Expr.witness 1 33 (0)))) (Expr.mul (Expr.constant "2048") (Expr.witness 1 35 (0))) },
    { name := "range_ab", value := Expr.add (Expr.witness 1 42 (0)) (Expr.constant "0") },
    { name := "range_cd", value := Expr.add (Expr.witness 1 43 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_52_1 : HintTuple := {
  hintIndex := 1128,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_a1", value := Expr.add (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "26")) (Expr.constant "0") },
    { name := "a[1]", value := Expr.add (Expr.witness 1 8 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_52 : Expr := Expr.sub (Expr.mul (Expr.witness 2 4 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 43 (0)) (Expr.challenge 2 0)) (Expr.witness 1 42 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 28 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 29 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 24 (0)))) (Expr.mul (Expr.constant "16") (Expr.witness 1 26 (0)))) (Expr.mul (Expr.constant "32") (Expr.witness 1 25 (0)))) (Expr.mul (Expr.constant "64") (Expr.witness 1 27 (0)))) (Expr.mul (Expr.constant "128") (Expr.witness 1 36 (0)))) (Expr.mul (Expr.constant "256") (Expr.witness 1 37 (0)))) (Expr.mul (Expr.constant "512") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "1024") (Expr.witness 1 33 (0)))) (Expr.mul (Expr.constant "2048") (Expr.witness 1 35 (0))))) (Expr.challenge 2 0)) (Expr.witness 1 39 (0))) (Expr.challenge 2 0)) (Expr.constant "331")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "26"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 8 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "26"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 43 (0)) (Expr.challenge 2 0)) (Expr.witness 1 42 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 28 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 29 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 24 (0)))) (Expr.mul (Expr.constant "16") (Expr.witness 1 26 (0)))) (Expr.mul (Expr.constant "32") (Expr.witness 1 25 (0)))) (Expr.mul (Expr.constant "64") (Expr.witness 1 27 (0)))) (Expr.mul (Expr.constant "128") (Expr.witness 1 36 (0)))) (Expr.mul (Expr.constant "256") (Expr.witness 1 37 (0)))) (Expr.mul (Expr.constant "512") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "1024") (Expr.witness 1 33 (0)))) (Expr.mul (Expr.constant "2048") (Expr.witness 1 35 (0))))) (Expr.challenge 2 0)) (Expr.witness 1 39 (0))) (Expr.challenge 2 0)) (Expr.constant "331")) (Expr.challenge 2 1))))
def template_Arith_52 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 4 (0)) hint_Arith_52_0 hint_Arith_52_1)
def link_Arith_52 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 52,
  shape := .cluster2,
  accumulator := Expr.witness 2 4 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_52,
  template := template_Arith_52,
  hints := [hint_Arith_52_0, hint_Arith_52_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_53_0 : HintTuple := {
  hintIndex := 1129,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_b1", value := Expr.add (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "9")) (Expr.constant "0") },
    { name := "b[1]", value := Expr.add (Expr.witness 1 12 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_53_1 : HintTuple := {
  hintIndex := 1130,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_c1", value := Expr.add (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "26")) (Expr.constant "0") },
    { name := "c[1]", value := Expr.add (Expr.witness 1 16 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_53 : Expr := Expr.sub (Expr.mul (Expr.witness 2 5 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 12 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "9"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 16 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "26"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 16 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "26"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 12 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "9"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_53 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 5 (0)) hint_Arith_53_0 hint_Arith_53_1)
def link_Arith_53 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 53,
  shape := .cluster2,
  accumulator := Expr.witness 2 5 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_53,
  template := template_Arith_53,
  hints := [hint_Arith_53_0, hint_Arith_53_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_54_0 : HintTuple := {
  hintIndex := 1131,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_d1", value := Expr.add (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "9")) (Expr.constant "0") },
    { name := "d[1]", value := Expr.add (Expr.witness 1 20 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_54_1 : HintTuple := {
  hintIndex := 1132,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_ab", value := Expr.add (Expr.witness 1 42 (0)) (Expr.constant "0") },
    { name := "a[3]", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_54 : Expr := Expr.sub (Expr.mul (Expr.witness 2 6 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 20 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "9"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.challenge 2 0)) (Expr.witness 1 42 (0))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 10 (0)) (Expr.challenge 2 0)) (Expr.witness 1 42 (0))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 20 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "9"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_54 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 6 (0)) hint_Arith_54_0 hint_Arith_54_1)
def link_Arith_54 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 54,
  shape := .cluster2,
  accumulator := Expr.witness 2 6 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_54,
  template := template_Arith_54,
  hints := [hint_Arith_54_0, hint_Arith_54_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_55_0 : HintTuple := {
  hintIndex := 1133,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_b3", value := Expr.add (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "17")) (Expr.constant "0") },
    { name := "b[3]", value := Expr.add (Expr.witness 1 14 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_55_1 : HintTuple := {
  hintIndex := 1134,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_cd", value := Expr.add (Expr.witness 1 43 (0)) (Expr.constant "0") },
    { name := "c[3]", value := Expr.add (Expr.witness 1 18 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_55 : Expr := Expr.sub (Expr.mul (Expr.witness 2 7 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 14 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "17"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 18 (0)) (Expr.challenge 2 0)) (Expr.witness 1 43 (0))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 18 (0)) (Expr.challenge 2 0)) (Expr.witness 1 43 (0))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 14 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 42 (0)) (Expr.constant "17"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_55 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 7 (0)) hint_Arith_55_0 hint_Arith_55_1)
def link_Arith_55 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 55,
  shape := .cluster2,
  accumulator := Expr.witness 2 7 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_55,
  template := template_Arith_55,
  hints := [hint_Arith_55_0, hint_Arith_55_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_56_0 : HintTuple := {
  hintIndex := 1135,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "range_d3", value := Expr.add (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "17")) (Expr.constant "0") },
    { name := "d[3]", value := Expr.add (Expr.witness 1 22 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_56_1 : HintTuple := {
  hintIndex := 1136,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "a[0]", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_56 : Expr := Expr.sub (Expr.mul (Expr.witness 2 8 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 22 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "17"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 22 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 43 (0)) (Expr.constant "17"))) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_56 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 8 (0)) hint_Arith_56_0 hint_Arith_56_1)
def link_Arith_56 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 56,
  shape := .cluster2,
  accumulator := Expr.witness 2 8 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_56,
  template := template_Arith_56,
  hints := [hint_Arith_56_0, hint_Arith_56_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_57_0 : HintTuple := {
  hintIndex := 1137,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "b[0]", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_57_1 : HintTuple := {
  hintIndex := 1138,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "c[0]", value := Expr.add (Expr.witness 1 15 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_57 : Expr := Expr.sub (Expr.mul (Expr.witness 2 9 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 11 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 15 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 15 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 11 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_57 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 9 (0)) hint_Arith_57_0 hint_Arith_57_1)
def link_Arith_57 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 57,
  shape := .cluster2,
  accumulator := Expr.witness 2 9 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_57,
  template := template_Arith_57,
  hints := [hint_Arith_57_0, hint_Arith_57_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_58_0 : HintTuple := {
  hintIndex := 1139,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "d[0]", value := Expr.add (Expr.witness 1 19 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_58_1 : HintTuple := {
  hintIndex := 1140,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "a[2]", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_58 : Expr := Expr.sub (Expr.mul (Expr.witness 2 10 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 19 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 9 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 9 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 19 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_58 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 10 (0)) hint_Arith_58_0 hint_Arith_58_1)
def link_Arith_58 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 58,
  shape := .cluster2,
  accumulator := Expr.witness 2 10 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_58,
  template := template_Arith_58,
  hints := [hint_Arith_58_0, hint_Arith_58_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_59_0 : HintTuple := {
  hintIndex := 1141,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "b[2]", value := Expr.add (Expr.witness 1 13 (0)) (Expr.constant "0") },
  ]
}

def hint_Arith_59_1 : HintTuple := {
  hintIndex := 1142,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "c[2]", value := Expr.add (Expr.witness 1 17 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_59 : Expr := Expr.sub (Expr.mul (Expr.witness 2 11 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 13 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 17 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 17 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 13 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))))
def template_Arith_59 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 11 (0)) hint_Arith_59_0 hint_Arith_59_1)
def link_Arith_59 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 59,
  shape := .cluster2,
  accumulator := Expr.witness 2 11 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_59,
  template := template_Arith_59,
  hints := [hint_Arith_59_0, hint_Arith_59_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_60_0 : HintTuple := {
  hintIndex := 1143,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "d[2]", value := Expr.add (Expr.witness 1 21 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_60 : Expr := Expr.add (Expr.mul (Expr.witness 2 12 (0)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.witness 1 21 (0)) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Arith_60 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 12 (0)) hint_Arith_60_0)
def link_Arith_60 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 60,
  shape := .direct,
  accumulator := Expr.witness 2 12 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_60,
  template := template_Arith_60,
  hints := [hint_Arith_60_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_61_0 : HintTuple := {
  hintIndex := 1116,
  piop := "Lookup",
  proves := true,
  busId := Expr.constant "5000",
  multiplicity := Expr.add (Expr.witness 1 41 (0)) (Expr.constant "0"),
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 39 (0)) (Expr.constant "0") },
    { name := "bus_a0", value := Expr.add (Expr.add (Expr.mul (Expr.witness 1 29 (0)) (Expr.add (Expr.witness 1 15 (0)) (Expr.mul (Expr.witness 1 16 (0)) (Expr.constant "65536")))) (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 29 (0))) (Expr.add (Expr.witness 1 7 (0)) (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "65536"))))) (Expr.constant "0") },
    { name := "bus_a1", value := Expr.add (Expr.add (Expr.mul (Expr.witness 1 29 (0)) (Expr.add (Expr.witness 1 17 (0)) (Expr.mul (Expr.witness 1 18 (0)) (Expr.constant "65536")))) (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 29 (0))) (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "65536"))))) (Expr.constant "0") },
    { name := "bus_b0", value := Expr.add (Expr.add (Expr.witness 1 11 (0)) (Expr.mul (Expr.witness 1 12 (0)) (Expr.constant "65536"))) (Expr.constant "0") },
    { name := "bus_b1", value := Expr.add (Expr.add (Expr.witness 1 13 (0)) (Expr.mul (Expr.witness 1 14 (0)) (Expr.constant "65536"))) (Expr.constant "0") },
    { name := "bus_res0", value := Expr.add (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.constant "1") (Expr.witness 1 34 (0))) (Expr.witness 1 33 (0))) (Expr.add (Expr.witness 1 19 (0)) (Expr.mul (Expr.witness 1 20 (0)) (Expr.constant "65536")))) (Expr.mul (Expr.witness 1 34 (0)) (Expr.add (Expr.witness 1 15 (0)) (Expr.mul (Expr.witness 1 16 (0)) (Expr.constant "65536"))))) (Expr.mul (Expr.witness 1 33 (0)) (Expr.add (Expr.witness 1 7 (0)) (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "65536"))))) (Expr.constant "0") },
    { name := "bus_res1", value := Expr.add (Expr.witness 1 40 (0)) (Expr.constant "0") },
    { name := "div_by_zero", value := Expr.add (Expr.witness 1 36 (0)) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_Arith_61 : Expr := Expr.sub (Expr.mul (Expr.witness 2 13 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 36 (0)) (Expr.challenge 2 0)) (Expr.witness 1 40 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.constant "1") (Expr.witness 1 34 (0))) (Expr.witness 1 33 (0))) (Expr.add (Expr.witness 1 19 (0)) (Expr.mul (Expr.witness 1 20 (0)) (Expr.constant "65536")))) (Expr.mul (Expr.witness 1 34 (0)) (Expr.add (Expr.witness 1 15 (0)) (Expr.mul (Expr.witness 1 16 (0)) (Expr.constant "65536"))))) (Expr.mul (Expr.witness 1 33 (0)) (Expr.add (Expr.witness 1 7 (0)) (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "65536")))))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 13 (0)) (Expr.mul (Expr.witness 1 14 (0)) (Expr.constant "65536")))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 11 (0)) (Expr.mul (Expr.witness 1 12 (0)) (Expr.constant "65536")))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 29 (0)) (Expr.add (Expr.witness 1 17 (0)) (Expr.mul (Expr.witness 1 18 (0)) (Expr.constant "65536")))) (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 29 (0))) (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.witness 1 10 (0)) (Expr.constant "65536")))))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 29 (0)) (Expr.add (Expr.witness 1 15 (0)) (Expr.mul (Expr.witness 1 16 (0)) (Expr.constant "65536")))) (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 29 (0))) (Expr.add (Expr.witness 1 7 (0)) (Expr.mul (Expr.witness 1 8 (0)) (Expr.constant "65536")))))) (Expr.challenge 2 0)) (Expr.witness 1 39 (0))) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.witness 1 41 (0))
def template_Arith_61 : Expr := normalise (directZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 13 (0)) hint_Arith_61_0)
def link_Arith_61 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 61,
  shape := .directZeroTail,
  accumulator := Expr.witness 2 13 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_61,
  template := template_Arith_61,
  hints := [hint_Arith_61_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_62_0 : HintTuple := {
  hintIndex := 1117,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "5000",
  multiplicity := Expr.mul (Expr.witness 1 29 (0)) (Expr.sub (Expr.constant "1") (Expr.witness 1 36 (0))),
  slots := [
    { name := "(1 - nr) * (1 - nb) * 6 + nr * (1 - nb) * 80 + (1 - nr) * nb * 81 + nr * nb * 8", value := Expr.add (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 25 (0))) (Expr.sub (Expr.constant "1") (Expr.witness 1 24 (0)))) (Expr.constant "6")) (Expr.mul (Expr.mul (Expr.witness 1 25 (0)) (Expr.sub (Expr.constant "1") (Expr.witness 1 24 (0)))) (Expr.constant "80"))) (Expr.mul (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 25 (0))) (Expr.witness 1 24 (0))) (Expr.constant "81"))) (Expr.mul (Expr.mul (Expr.witness 1 25 (0)) (Expr.witness 1 24 (0))) (Expr.constant "8")) },
    { name := "d[0] + 65536 * d[1]", value := Expr.add (Expr.witness 1 19 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 20 (0))) },
    { name := "d[2] + 65536 * d[3] + m32 * nr * 4294967295", value := Expr.add (Expr.add (Expr.witness 1 21 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 22 (0)))) (Expr.mul (Expr.mul (Expr.witness 1 28 (0)) (Expr.witness 1 25 (0))) (Expr.constant "4294967295")) },
    { name := "b[0] + 65536 * b[1]", value := Expr.add (Expr.witness 1 11 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 12 (0))) },
    { name := "b[2] + 65536 * b[3] + m32 * nb * 4294967295", value := Expr.add (Expr.add (Expr.witness 1 13 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 14 (0)))) (Expr.mul (Expr.mul (Expr.witness 1 28 (0)) (Expr.witness 1 24 (0))) (Expr.constant "4294967295")) },
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "1", value := Expr.constant "1" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_Arith_62 : Expr := Expr.sub (Expr.mul (Expr.witness 2 14 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.challenge 2 0) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.witness 1 13 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 14 (0)))) (Expr.mul (Expr.mul (Expr.witness 1 28 (0)) (Expr.witness 1 24 (0))) (Expr.constant "4294967295")))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 11 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 12 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.witness 1 21 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 22 (0)))) (Expr.mul (Expr.mul (Expr.witness 1 28 (0)) (Expr.witness 1 25 (0))) (Expr.constant "4294967295")))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 19 (0)) (Expr.mul (Expr.constant "65536") (Expr.witness 1 20 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 25 (0))) (Expr.sub (Expr.constant "1") (Expr.witness 1 24 (0)))) (Expr.constant "6")) (Expr.mul (Expr.mul (Expr.witness 1 25 (0)) (Expr.sub (Expr.constant "1") (Expr.witness 1 24 (0)))) (Expr.constant "80"))) (Expr.mul (Expr.mul (Expr.sub (Expr.constant "1") (Expr.witness 1 25 (0))) (Expr.witness 1 24 (0))) (Expr.constant "81"))) (Expr.mul (Expr.mul (Expr.witness 1 25 (0)) (Expr.witness 1 24 (0))) (Expr.constant "8")))) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.mul (Expr.witness 1 29 (0)) (Expr.sub (Expr.constant "1") (Expr.witness 1 36 (0)))))
def template_Arith_62 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 14 (0)) hint_Arith_62_0)
def link_Arith_62 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 62,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.witness 2 14 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_62,
  template := template_Arith_62,
  hints := [hint_Arith_62_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Arith_63_0 : HintTuple := {
  hintIndex := 1118,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "330",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "100", value := Expr.constant "100" },
    { name := "carry[0]", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
  ]
}

def constraint_Arith_63 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))) (Expr.witness 2 6 (0))) (Expr.witness 2 7 (0))) (Expr.witness 2 8 (0))) (Expr.witness 2 9 (0))) (Expr.witness 2 10 (0))) (Expr.witness 2 11 (0))) (Expr.witness 2 12 (0))) (Expr.witness 2 13 (0))) (Expr.witness 2 14 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 0 (0)) (Expr.challenge 2 0)) (Expr.constant "100")) (Expr.challenge 2 0)) (Expr.constant "330")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Arith_63 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))) (Expr.witness 2 6 (0))) (Expr.witness 2 7 (0))) (Expr.witness 2 8 (0))) (Expr.witness 2 9 (0))) (Expr.witness 2 10 (0))) (Expr.witness 2 11 (0))) (Expr.witness 2 12 (0))) (Expr.witness 2 13 (0))) (Expr.witness 2 14 (0)))) hint_Arith_63_0)
def link_Arith_63 : ValidatedLink := {
  air := "Arith",
  constraintIndex := 63,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))) (Expr.witness 2 6 (0))) (Expr.witness 2 7 (0))) (Expr.witness 2 8 (0))) (Expr.witness 2 9 (0))) (Expr.witness 2 10 (0))) (Expr.witness 2 11 (0))) (Expr.witness 2 12 (0))) (Expr.witness 2 13 (0))) (Expr.witness 2 14 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Arith_63,
  template := template_Arith_63,
  hints := [hint_Arith_63_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_Arith_64 : Expr := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0)))
def template_Arith_64 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 0 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [])
def link_Arith_64 : ValidatedFinalRow := {
  air := "Arith",
  constraintIndex := 64,
  shape := .gsumFinalRow,
  selector := Expr.fixed 0 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [],
  constraint := constraint_Arith_64,
  template := template_Arith_64,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Binary_7_0 : HintTuple := {
  hintIndex := 1171,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "b_op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "free_in_a[1]", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "free_in_b[1]", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
    { name := "carry[0]", value := Expr.add (Expr.witness 1 25 (0)) (Expr.constant "0") },
    { name := "free_in_c[1]", value := Expr.add (Expr.witness 1 18 (0)) (Expr.constant "0") },
    { name := "carry[1] + 2 * result_is_a + 4 * use_first_byte", value := Expr.add (Expr.add (Expr.witness 1 26 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0))) },
  ]
}

def hint_Binary_7_1 : HintTuple := {
  hintIndex := 1172,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "b_op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "free_in_a[2]", value := Expr.add (Expr.witness 1 3 (0)) (Expr.constant "0") },
    { name := "free_in_b[2]", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
    { name := "carry[1]", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
    { name := "free_in_c[2]", value := Expr.add (Expr.witness 1 19 (0)) (Expr.constant "0") },
    { name := "carry[2] + 2 * result_is_a + 4 * use_first_byte", value := Expr.add (Expr.add (Expr.witness 1 27 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0))) },
  ]
}

def constraint_Binary_7 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.witness 1 26 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 18 (0))) (Expr.challenge 2 0)) (Expr.witness 1 25 (0))) (Expr.challenge 2 0)) (Expr.witness 1 10 (0))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.witness 1 27 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 19 (0))) (Expr.challenge 2 0)) (Expr.witness 1 26 (0))) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.witness 1 27 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 19 (0))) (Expr.challenge 2 0)) (Expr.witness 1 26 (0))) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.witness 1 26 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 18 (0))) (Expr.challenge 2 0)) (Expr.witness 1 25 (0))) (Expr.challenge 2 0)) (Expr.witness 1 10 (0))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1))))
def template_Binary_7 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_Binary_7_0 hint_Binary_7_1)
def link_Binary_7 : ValidatedLink := {
  air := "Binary",
  constraintIndex := 7,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Binary_7,
  template := template_Binary_7,
  hints := [hint_Binary_7_0, hint_Binary_7_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Binary_8_0 : HintTuple := {
  hintIndex := 1173,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "mode32", value := Expr.add (Expr.witness 1 33 (0)) (Expr.constant "0") },
    { name := "b_op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "free_in_a[3]", value := Expr.add (Expr.witness 1 4 (0)) (Expr.constant "0") },
    { name := "free_in_b[3]", value := Expr.add (Expr.witness 1 12 (0)) (Expr.constant "0") },
    { name := "carry[2]", value := Expr.add (Expr.witness 1 27 (0)) (Expr.constant "0") },
    { name := "free_in_c[3]", value := Expr.add (Expr.witness 1 20 (0)) (Expr.constant "0") },
    { name := "carry[3] + 2 * result_is_a + 4 * use_first_byte + 8 * mode32_and_c_is_signed", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 28 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0))) },
  ]
}

def hint_Binary_8_1 : HintTuple := {
  hintIndex := 1174,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "b_op_or_sext", value := Expr.add (Expr.witness 1 37 (0)) (Expr.constant "0") },
    { name := "free_in_a[4]", value := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0") },
    { name := "free_in_b[4]", value := Expr.add (Expr.witness 1 13 (0)) (Expr.constant "0") },
    { name := "carry[3]", value := Expr.add (Expr.witness 1 28 (0)) (Expr.constant "0") },
    { name := "free_in_c[4]", value := Expr.add (Expr.witness 1 21 (0)) (Expr.constant "0") },
    { name := "carry[4] + 2 * result_is_a + 4 * use_first_byte + 8 * mode32_and_c_is_signed", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 29 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0))) },
  ]
}

def constraint_Binary_8 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 28 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 20 (0))) (Expr.challenge 2 0)) (Expr.witness 1 27 (0))) (Expr.challenge 2 0)) (Expr.witness 1 12 (0))) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.witness 1 33 (0))) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 29 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 21 (0))) (Expr.challenge 2 0)) (Expr.witness 1 28 (0))) (Expr.challenge 2 0)) (Expr.witness 1 13 (0))) (Expr.challenge 2 0)) (Expr.witness 1 5 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 29 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 21 (0))) (Expr.challenge 2 0)) (Expr.witness 1 28 (0))) (Expr.challenge 2 0)) (Expr.witness 1 13 (0))) (Expr.challenge 2 0)) (Expr.witness 1 5 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 28 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 20 (0))) (Expr.challenge 2 0)) (Expr.witness 1 27 (0))) (Expr.challenge 2 0)) (Expr.witness 1 12 (0))) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.witness 1 33 (0))) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1))))
def template_Binary_8 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_Binary_8_0 hint_Binary_8_1)
def link_Binary_8 : ValidatedLink := {
  air := "Binary",
  constraintIndex := 8,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Binary_8,
  template := template_Binary_8,
  hints := [hint_Binary_8_0, hint_Binary_8_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Binary_9_0 : HintTuple := {
  hintIndex := 1175,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "b_op_or_sext", value := Expr.add (Expr.witness 1 37 (0)) (Expr.constant "0") },
    { name := "free_in_a[5]", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
    { name := "free_in_b[5]", value := Expr.add (Expr.witness 1 14 (0)) (Expr.constant "0") },
    { name := "carry[4]", value := Expr.add (Expr.witness 1 29 (0)) (Expr.constant "0") },
    { name := "free_in_c[5]", value := Expr.add (Expr.witness 1 22 (0)) (Expr.constant "0") },
    { name := "carry[5] + 2 * result_is_a + 4 * use_first_byte + 8 * mode32_and_c_is_signed", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 30 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0))) },
  ]
}

def hint_Binary_9_1 : HintTuple := {
  hintIndex := 1176,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "0", value := Expr.constant "0" },
    { name := "b_op_or_sext", value := Expr.add (Expr.witness 1 37 (0)) (Expr.constant "0") },
    { name := "free_in_a[6]", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
    { name := "free_in_b[6]", value := Expr.add (Expr.witness 1 15 (0)) (Expr.constant "0") },
    { name := "carry[5]", value := Expr.add (Expr.witness 1 30 (0)) (Expr.constant "0") },
    { name := "free_in_c[6]", value := Expr.add (Expr.witness 1 23 (0)) (Expr.constant "0") },
    { name := "carry[6] + 2 * result_is_a + 4 * use_first_byte + 8 * mode32_and_c_is_signed", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 31 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0))) },
  ]
}

def constraint_Binary_9 : Expr := Expr.sub (Expr.mul (Expr.witness 2 3 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 30 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 22 (0))) (Expr.challenge 2 0)) (Expr.witness 1 29 (0))) (Expr.challenge 2 0)) (Expr.witness 1 14 (0))) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 31 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 23 (0))) (Expr.challenge 2 0)) (Expr.witness 1 30 (0))) (Expr.challenge 2 0)) (Expr.witness 1 15 (0))) (Expr.challenge 2 0)) (Expr.witness 1 7 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 31 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 23 (0))) (Expr.challenge 2 0)) (Expr.witness 1 30 (0))) (Expr.challenge 2 0)) (Expr.witness 1 15 (0))) (Expr.challenge 2 0)) (Expr.witness 1 7 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 30 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 38 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 22 (0))) (Expr.challenge 2 0)) (Expr.witness 1 29 (0))) (Expr.challenge 2 0)) (Expr.witness 1 14 (0))) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1))))
def template_Binary_9 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 3 (0)) hint_Binary_9_0 hint_Binary_9_1)
def link_Binary_9 : ValidatedLink := {
  air := "Binary",
  constraintIndex := 9,
  shape := .cluster2,
  accumulator := Expr.witness 2 3 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Binary_9,
  template := template_Binary_9,
  hints := [hint_Binary_9_0, hint_Binary_9_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Binary_10_0 : HintTuple := {
  hintIndex := 1177,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "mode64", value := Expr.add (Expr.sub (Expr.constant "1") (Expr.witness 1 33 (0))) (Expr.constant "0") },
    { name := "b_op_or_sext", value := Expr.add (Expr.witness 1 37 (0)) (Expr.constant "0") },
    { name := "free_in_a[7]", value := Expr.add (Expr.witness 1 8 (0)) (Expr.constant "0") },
    { name := "free_in_b[7]", value := Expr.add (Expr.witness 1 16 (0)) (Expr.constant "0") },
    { name := "carry[6]", value := Expr.add (Expr.witness 1 31 (0)) (Expr.constant "0") },
    { name := "free_in_c[7]", value := Expr.add (Expr.witness 1 24 (0)) (Expr.constant "0") },
    { name := "carry[7] + 2 * result_is_a + 4 * use_first_byte + 8 * c_is_signed", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 32 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 36 (0))) },
  ]
}

def hint_Binary_10_1 : HintTuple := {
  hintIndex := 1178,
  piop := "Lookup",
  proves := true,
  busId := Expr.constant "5000",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "b_op + 16 * mode32", value := Expr.add (Expr.witness 1 0 (0)) (Expr.mul (Expr.constant "16") (Expr.witness 1 33 (0))) },
    { name := "free_in_a[0] + 256 * free_in_a[1] + 65536 * free_in_a[2] + 16777216 * free_in_a[3]", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0))) },
    { name := "free_in_a[4] + 256 * free_in_a[5] + 65536 * free_in_a[6] + 16777216 * free_in_a[7]", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0))) },
    { name := "free_in_b[0] + 256 * free_in_b[1] + 65536 * free_in_b[2] + 16777216 * free_in_b[3]", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 10 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 11 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 12 (0))) },
    { name := "free_in_b[4] + 256 * free_in_b[5] + 65536 * free_in_b[6] + 16777216 * free_in_b[7]", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 13 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 14 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 15 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 16 (0))) },
    { name := "free_in_c[0] + 256 * free_in_c[1] + 65536 * free_in_c[2] + 16777216 * free_in_c[3] + carry[7]", value := Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 17 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 18 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 19 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 20 (0)))) (Expr.witness 1 32 (0)) },
    { name := "free_in_c[4] + 256 * free_in_c[5] + 65536 * free_in_c[6] + 16777216 * free_in_c[7]", value := Expr.add (Expr.add (Expr.add (Expr.witness 1 21 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 22 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 24 (0))) },
    { name := "carry[7]", value := Expr.add (Expr.witness 1 32 (0)) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_Binary_10 : Expr := Expr.sub (Expr.mul (Expr.witness 2 4 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 32 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 36 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.witness 1 31 (0))) (Expr.challenge 2 0)) (Expr.witness 1 16 (0))) (Expr.challenge 2 0)) (Expr.witness 1 8 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.sub (Expr.constant "1") (Expr.witness 1 33 (0)))) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 32 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 21 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 22 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 24 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 17 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 18 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 19 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 20 (0)))) (Expr.witness 1 32 (0)))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 13 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 14 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 15 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 16 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 10 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 11 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 12 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 0 (0)) (Expr.mul (Expr.constant "16") (Expr.witness 1 33 (0))))) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 32 (0)) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 21 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 22 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 23 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 24 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 17 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 18 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 19 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 20 (0)))) (Expr.witness 1 32 (0)))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 13 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 14 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 15 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 16 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 10 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 11 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 12 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0))))) (Expr.challenge 2 0)) (Expr.add (Expr.witness 1 0 (0)) (Expr.mul (Expr.constant "16") (Expr.witness 1 33 (0))))) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.witness 1 32 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.mul (Expr.constant "8") (Expr.witness 1 36 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.witness 1 31 (0))) (Expr.challenge 2 0)) (Expr.witness 1 16 (0))) (Expr.challenge 2 0)) (Expr.witness 1 8 (0))) (Expr.challenge 2 0)) (Expr.witness 1 37 (0))) (Expr.challenge 2 0)) (Expr.sub (Expr.constant "1") (Expr.witness 1 33 (0)))) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1)))
def template_Binary_10 : Expr := normalise (cluster2ZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 4 (0)) hint_Binary_10_0 hint_Binary_10_1)
def link_Binary_10 : ValidatedLink := {
  air := "Binary",
  constraintIndex := 10,
  shape := .cluster2ZeroTail,
  accumulator := Expr.witness 2 4 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Binary_10,
  template := template_Binary_10,
  hints := [hint_Binary_10_0, hint_Binary_10_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Binary_11_0 : HintTuple := {
  hintIndex := 1170,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "125",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "2 * use_first_byte", value := Expr.mul (Expr.constant "2") (Expr.witness 1 35 (0)) },
    { name := "b_op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "free_in_a[0]", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
    { name := "free_in_b[0]", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
    { name := "free_in_c[0]", value := Expr.add (Expr.witness 1 17 (0)) (Expr.constant "0") },
    { name := "carry[0] + 2 * result_is_a + 4 * use_first_byte", value := Expr.add (Expr.add (Expr.witness 1 25 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0))) },
  ]
}

def constraint_Binary_11 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.witness 1 25 (0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 34 (0)))) (Expr.mul (Expr.constant "4") (Expr.witness 1 35 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 17 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.mul (Expr.constant "2") (Expr.witness 1 35 (0)))) (Expr.challenge 2 0)) (Expr.constant "125")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_Binary_11 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0)))) hint_Binary_11_0)
def link_Binary_11 : ValidatedLink := {
  air := "Binary",
  constraintIndex := 11,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Binary_11,
  template := template_Binary_11,
  hints := [hint_Binary_11_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_Binary_12_0 : HintTuple := {
  hintIndex := 1179,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "5000",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "10", value := Expr.constant "10" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_Binary_12 : Expr := Expr.sub (Expr.mul (Expr.airValue 1) (Expr.add (Expr.add (Expr.mul (Expr.constant "10") (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.airValue 0))
def template_Binary_12 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 1) hint_Binary_12_0)
def link_Binary_12 : ValidatedLink := {
  air := "Binary",
  constraintIndex := 12,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.airValue 1,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_Binary_12,
  template := template_Binary_12,
  hints := [hint_Binary_12_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_Binary_13 : Expr := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0))) (Expr.airValue 1))
def template_Binary_13 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 0 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [Expr.airValue 1])
def link_Binary_13 : ValidatedFinalRow := {
  air := "Binary",
  constraintIndex := 13,
  shape := .gsumFinalRow,
  selector := Expr.fixed 0 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [Expr.airValue 1],
  constraint := constraint_Binary_13,
  template := template_Binary_13,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryAdd_4_0 : HintTuple := {
  hintIndex := 1193,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "c_chunks[1]", value := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0") },
  ]
}

def hint_BinaryAdd_4_1 : HintTuple := {
  hintIndex := 1195,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "c_chunks[2]", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
  ]
}

def constraint_BinaryAdd_4 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 6 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))))
def template_BinaryAdd_4 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_BinaryAdd_4_0 hint_BinaryAdd_4_1)
def link_BinaryAdd_4 : ValidatedLink := {
  air := "BinaryAdd",
  constraintIndex := 4,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryAdd_4,
  template := template_BinaryAdd_4,
  hints := [hint_BinaryAdd_4_0, hint_BinaryAdd_4_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryAdd_5_0 : HintTuple := {
  hintIndex := 1197,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "c_chunks[3]", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
  ]
}

def hint_BinaryAdd_5_1 : HintTuple := {
  hintIndex := 1198,
  piop := "Lookup",
  proves := true,
  busId := Expr.constant "5000",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "10", value := Expr.constant "10" },
    { name := "a[0]", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "a[1]", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
    { name := "b[0]", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "b[1]", value := Expr.add (Expr.witness 1 3 (0)) (Expr.constant "0") },
    { name := "c_chunks[1] * 65536 + c_chunks[0]", value := Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.constant "65536")) (Expr.witness 1 4 (0)) },
    { name := "c_chunks[3] * 65536 + c_chunks[2]", value := Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.constant "65536")) (Expr.witness 1 6 (0)) },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_BinaryAdd_5 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.constant "65536")) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.constant "65536")) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.constant "65536")) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 5 (0)) (Expr.constant "65536")) (Expr.witness 1 4 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "10")) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 7 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1)))
def template_BinaryAdd_5 : Expr := normalise (cluster2ZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_BinaryAdd_5_0 hint_BinaryAdd_5_1)
def link_BinaryAdd_5 : ValidatedLink := {
  air := "BinaryAdd",
  constraintIndex := 5,
  shape := .cluster2ZeroTail,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryAdd_5,
  template := template_BinaryAdd_5,
  hints := [hint_BinaryAdd_5_0, hint_BinaryAdd_5_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryAdd_6_0 : HintTuple := {
  hintIndex := 1191,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "103",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "c_chunks[0]", value := Expr.add (Expr.witness 1 4 (0)) (Expr.constant "0") },
  ]
}

def constraint_BinaryAdd_6 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 4 (0)) (Expr.challenge 2 0)) (Expr.constant "103")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_BinaryAdd_6 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0)))) hint_BinaryAdd_6_0)
def link_BinaryAdd_6 : ValidatedLink := {
  air := "BinaryAdd",
  constraintIndex := 6,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryAdd_6,
  template := template_BinaryAdd_6,
  hints := [hint_BinaryAdd_6_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryAdd_7_0 : HintTuple := {
  hintIndex := 1199,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "5000",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "10", value := Expr.constant "10" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_BinaryAdd_7 : Expr := Expr.sub (Expr.mul (Expr.airValue 1) (Expr.add (Expr.add (Expr.mul (Expr.constant "10") (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.airValue 0))
def template_BinaryAdd_7 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 1) hint_BinaryAdd_7_0)
def link_BinaryAdd_7 : ValidatedLink := {
  air := "BinaryAdd",
  constraintIndex := 7,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.airValue 1,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryAdd_7,
  template := template_BinaryAdd_7,
  hints := [hint_BinaryAdd_7_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_BinaryAdd_8 : Expr := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0))) (Expr.airValue 1))
def template_BinaryAdd_8 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 0 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [Expr.airValue 1])
def link_BinaryAdd_8 : ValidatedFinalRow := {
  air := "BinaryAdd",
  constraintIndex := 8,
  shape := .gsumFinalRow,
  selector := Expr.fixed 0 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [Expr.airValue 1],
  constraint := constraint_BinaryAdd_8,
  template := template_BinaryAdd_8,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryExtension_0_0 : HintTuple := {
  hintIndex := 1210,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "1", value := Expr.constant "1" },
    { name := "free_in_a[1]", value := Expr.add (Expr.witness 1 2 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[1][0]", value := Expr.add (Expr.witness 1 12 (0)) (Expr.constant "0") },
    { name := "free_in_c[1][1]", value := Expr.add (Expr.witness 1 13 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def hint_BinaryExtension_0_1 : HintTuple := {
  hintIndex := 1211,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "2", value := Expr.constant "2" },
    { name := "free_in_a[2]", value := Expr.add (Expr.witness 1 3 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[2][0]", value := Expr.add (Expr.witness 1 14 (0)) (Expr.constant "0") },
    { name := "free_in_c[2][1]", value := Expr.add (Expr.witness 1 15 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def constraint_BinaryExtension_0 : Expr := Expr.sub (Expr.mul (Expr.witness 2 1 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 13 (0))) (Expr.challenge 2 0)) (Expr.witness 1 12 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 15 (0))) (Expr.challenge 2 0)) (Expr.witness 1 14 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 15 (0))) (Expr.challenge 2 0)) (Expr.witness 1 14 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 3 (0))) (Expr.challenge 2 0)) (Expr.constant "2")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 13 (0))) (Expr.challenge 2 0)) (Expr.witness 1 12 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 2 (0))) (Expr.challenge 2 0)) (Expr.constant "1")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))))
def template_BinaryExtension_0 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 1 (0)) hint_BinaryExtension_0_0 hint_BinaryExtension_0_1)
def link_BinaryExtension_0 : ValidatedLink := {
  air := "BinaryExtension",
  constraintIndex := 0,
  shape := .cluster2,
  accumulator := Expr.witness 2 1 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryExtension_0,
  template := template_BinaryExtension_0,
  hints := [hint_BinaryExtension_0_0, hint_BinaryExtension_0_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryExtension_1_0 : HintTuple := {
  hintIndex := 1212,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "3", value := Expr.constant "3" },
    { name := "free_in_a[3]", value := Expr.add (Expr.witness 1 4 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[3][0]", value := Expr.add (Expr.witness 1 16 (0)) (Expr.constant "0") },
    { name := "free_in_c[3][1]", value := Expr.add (Expr.witness 1 17 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def hint_BinaryExtension_1_1 : HintTuple := {
  hintIndex := 1213,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "4", value := Expr.constant "4" },
    { name := "free_in_a[4]", value := Expr.add (Expr.witness 1 5 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[4][0]", value := Expr.add (Expr.witness 1 18 (0)) (Expr.constant "0") },
    { name := "free_in_c[4][1]", value := Expr.add (Expr.witness 1 19 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def constraint_BinaryExtension_1 : Expr := Expr.sub (Expr.mul (Expr.witness 2 2 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 17 (0))) (Expr.challenge 2 0)) (Expr.witness 1 16 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 19 (0))) (Expr.challenge 2 0)) (Expr.witness 1 18 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 5 (0))) (Expr.challenge 2 0)) (Expr.constant "4")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 19 (0))) (Expr.challenge 2 0)) (Expr.witness 1 18 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 5 (0))) (Expr.challenge 2 0)) (Expr.constant "4")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 17 (0))) (Expr.challenge 2 0)) (Expr.witness 1 16 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 4 (0))) (Expr.challenge 2 0)) (Expr.constant "3")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))))
def template_BinaryExtension_1 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 2 (0)) hint_BinaryExtension_1_0 hint_BinaryExtension_1_1)
def link_BinaryExtension_1 : ValidatedLink := {
  air := "BinaryExtension",
  constraintIndex := 1,
  shape := .cluster2,
  accumulator := Expr.witness 2 2 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryExtension_1,
  template := template_BinaryExtension_1,
  hints := [hint_BinaryExtension_1_0, hint_BinaryExtension_1_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryExtension_2_0 : HintTuple := {
  hintIndex := 1214,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "5", value := Expr.constant "5" },
    { name := "free_in_a[5]", value := Expr.add (Expr.witness 1 6 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[5][0]", value := Expr.add (Expr.witness 1 20 (0)) (Expr.constant "0") },
    { name := "free_in_c[5][1]", value := Expr.add (Expr.witness 1 21 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def hint_BinaryExtension_2_1 : HintTuple := {
  hintIndex := 1215,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "6", value := Expr.constant "6" },
    { name := "free_in_a[6]", value := Expr.add (Expr.witness 1 7 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[6][0]", value := Expr.add (Expr.witness 1 22 (0)) (Expr.constant "0") },
    { name := "free_in_c[6][1]", value := Expr.add (Expr.witness 1 23 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def constraint_BinaryExtension_2 : Expr := Expr.sub (Expr.mul (Expr.witness 2 3 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 21 (0))) (Expr.challenge 2 0)) (Expr.witness 1 20 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.constant "5")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 23 (0))) (Expr.challenge 2 0)) (Expr.witness 1 22 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 7 (0))) (Expr.challenge 2 0)) (Expr.constant "6")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 23 (0))) (Expr.challenge 2 0)) (Expr.witness 1 22 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 7 (0))) (Expr.challenge 2 0)) (Expr.constant "6")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))) (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 21 (0))) (Expr.challenge 2 0)) (Expr.witness 1 20 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 6 (0))) (Expr.challenge 2 0)) (Expr.constant "5")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))))
def template_BinaryExtension_2 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 3 (0)) hint_BinaryExtension_2_0 hint_BinaryExtension_2_1)
def link_BinaryExtension_2 : ValidatedLink := {
  air := "BinaryExtension",
  constraintIndex := 2,
  shape := .cluster2,
  accumulator := Expr.witness 2 3 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryExtension_2,
  template := template_BinaryExtension_2,
  hints := [hint_BinaryExtension_2_0, hint_BinaryExtension_2_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryExtension_3_0 : HintTuple := {
  hintIndex := 1216,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "7", value := Expr.constant "7" },
    { name := "free_in_a[7]", value := Expr.add (Expr.witness 1 8 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[7][0]", value := Expr.add (Expr.witness 1 24 (0)) (Expr.constant "0") },
    { name := "free_in_c[7][1]", value := Expr.add (Expr.witness 1 25 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def hint_BinaryExtension_3_1 : HintTuple := {
  hintIndex := 1219,
  piop := "Range Check",
  proves := false,
  busId := Expr.constant "102",
  multiplicity := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0"),
  slots := [
    { name := "b[0]", value := Expr.add (Expr.witness 1 27 (0)) (Expr.constant "0") },
  ]
}

def constraint_BinaryExtension_3 : Expr := Expr.sub (Expr.mul (Expr.witness 2 4 (0)) (Expr.mul (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 25 (0))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 8 (0))) (Expr.challenge 2 0)) (Expr.constant "7")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1)) (Expr.add (Expr.add (Expr.mul (Expr.witness 1 27 (0)) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1)))) (Expr.add (Expr.mul (Expr.constant "18446744069414584320") (Expr.add (Expr.add (Expr.mul (Expr.witness 1 27 (0)) (Expr.challenge 2 0)) (Expr.constant "102")) (Expr.challenge 2 1))) (Expr.mul (Expr.sub (Expr.constant "0") (Expr.witness 1 26 (0))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 25 (0))) (Expr.challenge 2 0)) (Expr.witness 1 24 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 8 (0))) (Expr.challenge 2 0)) (Expr.constant "7")) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))))
def template_BinaryExtension_3 : Expr := normalise (cluster2Template (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 4 (0)) hint_BinaryExtension_3_0 hint_BinaryExtension_3_1)
def link_BinaryExtension_3 : ValidatedLink := {
  air := "BinaryExtension",
  constraintIndex := 3,
  shape := .cluster2,
  accumulator := Expr.witness 2 4 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryExtension_3,
  template := template_BinaryExtension_3,
  hints := [hint_BinaryExtension_3_0, hint_BinaryExtension_3_1],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryExtension_4_0 : HintTuple := {
  hintIndex := 1220,
  piop := "Lookup",
  proves := true,
  busId := Expr.constant "5000",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "op_is_shift * ((free_in_a[0] + 256 * free_in_a[1] + 65536 * free_in_a[2] + 16777216 * free_in_a[3]) - b[0]) + b[0]", value := Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0)))) (Expr.witness 1 27 (0)))) (Expr.witness 1 27 (0)) },
    { name := "op_is_shift * ((free_in_a[4] + 256 * free_in_a[5] + 65536 * free_in_a[6] + 16777216 * free_in_a[7]) - b[1]) + b[1]", value := Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0)))) (Expr.witness 1 28 (0)))) (Expr.witness 1 28 (0)) },
    { name := "op_is_shift * ((free_in_b + 256 * b[0]) - (free_in_a[0] + 256 * free_in_a[1] + 65536 * free_in_a[2] + 16777216 * free_in_a[3])) + free_in_a[0] + 256 * free_in_a[1] + 65536 * free_in_a[2] + 16777216 * free_in_a[3]", value := Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 27 (0)))) (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0)))))) (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0)))) },
    { name := "op_is_shift * (b[1] - (free_in_a[4] + 256 * free_in_a[5] + 65536 * free_in_a[6] + 16777216 * free_in_a[7])) + free_in_a[4] + 256 * free_in_a[5] + 65536 * free_in_a[6] + 16777216 * free_in_a[7]", value := Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.witness 1 28 (0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0)))))) (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0)))) },
    { name := "free_in_c[0][0] + free_in_c[1][0] + free_in_c[2][0] + free_in_c[3][0] + free_in_c[4][0] + free_in_c[5][0] + free_in_c[6][0] + free_in_c[7][0]", value := Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 10 (0)) (Expr.witness 1 12 (0))) (Expr.witness 1 14 (0))) (Expr.witness 1 16 (0))) (Expr.witness 1 18 (0))) (Expr.witness 1 20 (0))) (Expr.witness 1 22 (0))) (Expr.witness 1 24 (0)) },
    { name := "free_in_c[0][1] + free_in_c[1][1] + free_in_c[2][1] + free_in_c[3][1] + free_in_c[4][1] + free_in_c[5][1] + free_in_c[6][1] + free_in_c[7][1]", value := Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 11 (0)) (Expr.witness 1 13 (0))) (Expr.witness 1 15 (0))) (Expr.witness 1 17 (0))) (Expr.witness 1 19 (0))) (Expr.witness 1 21 (0))) (Expr.witness 1 23 (0))) (Expr.witness 1 25 (0)) },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_BinaryExtension_4 : Expr := Expr.sub (Expr.mul (Expr.witness 2 5 (0)) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 11 (0)) (Expr.witness 1 13 (0))) (Expr.witness 1 15 (0))) (Expr.witness 1 17 (0))) (Expr.witness 1 19 (0))) (Expr.witness 1 21 (0))) (Expr.witness 1 23 (0))) (Expr.witness 1 25 (0))) (Expr.challenge 2 0)) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 1 10 (0)) (Expr.witness 1 12 (0))) (Expr.witness 1 14 (0))) (Expr.witness 1 16 (0))) (Expr.witness 1 18 (0))) (Expr.witness 1 20 (0))) (Expr.witness 1 22 (0))) (Expr.witness 1 24 (0)))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.witness 1 28 (0)) (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0)))))) (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0)))))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.add (Expr.witness 1 9 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 27 (0)))) (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0)))))) (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0)))))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.add (Expr.add (Expr.add (Expr.witness 1 5 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 6 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 7 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 8 (0)))) (Expr.witness 1 28 (0)))) (Expr.witness 1 28 (0)))) (Expr.challenge 2 0)) (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.sub (Expr.add (Expr.add (Expr.add (Expr.witness 1 1 (0)) (Expr.mul (Expr.constant "256") (Expr.witness 1 2 (0)))) (Expr.mul (Expr.constant "65536") (Expr.witness 1 3 (0)))) (Expr.mul (Expr.constant "16777216") (Expr.witness 1 4 (0)))) (Expr.witness 1 27 (0)))) (Expr.witness 1 27 (0)))) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_BinaryExtension_4 : Expr := normalise (directZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.witness 2 5 (0)) hint_BinaryExtension_4_0)
def link_BinaryExtension_4 : ValidatedLink := {
  air := "BinaryExtension",
  constraintIndex := 4,
  shape := .directZeroTail,
  accumulator := Expr.witness 2 5 (0),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryExtension_4,
  template := template_BinaryExtension_4,
  hints := [hint_BinaryExtension_4_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryExtension_5_0 : HintTuple := {
  hintIndex := 1209,
  piop := "Lookup",
  proves := false,
  busId := Expr.constant "124",
  multiplicity := Expr.constant "1",
  slots := [
    { name := "op", value := Expr.add (Expr.witness 1 0 (0)) (Expr.constant "0") },
    { name := "0", value := Expr.constant "0" },
    { name := "free_in_a[0]", value := Expr.add (Expr.witness 1 1 (0)) (Expr.constant "0") },
    { name := "free_in_b", value := Expr.add (Expr.witness 1 9 (0)) (Expr.constant "0") },
    { name := "free_in_c[0][0]", value := Expr.add (Expr.witness 1 10 (0)) (Expr.constant "0") },
    { name := "free_in_c[0][1]", value := Expr.add (Expr.witness 1 11 (0)) (Expr.constant "0") },
    { name := "op_is_shift", value := Expr.add (Expr.witness 1 26 (0)) (Expr.constant "0") },
  ]
}

def constraint_BinaryExtension_5 : Expr := Expr.add (Expr.mul (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0)))) (Expr.add (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.add (Expr.mul (Expr.witness 1 26 (0)) (Expr.challenge 2 0)) (Expr.witness 1 11 (0))) (Expr.challenge 2 0)) (Expr.witness 1 10 (0))) (Expr.challenge 2 0)) (Expr.witness 1 9 (0))) (Expr.challenge 2 0)) (Expr.witness 1 1 (0))) (Expr.challenge 2 0)) (Expr.challenge 2 0)) (Expr.witness 1 0 (0))) (Expr.challenge 2 0)) (Expr.constant "124")) (Expr.challenge 2 1))) (Expr.constant "1")
def template_BinaryExtension_5 : Expr := normalise (directTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0)))) hint_BinaryExtension_5_0)
def link_BinaryExtension_5 : ValidatedLink := {
  air := "BinaryExtension",
  constraintIndex := 5,
  shape := .direct,
  accumulator := Expr.sub (Expr.sub (Expr.witness 2 0 (0)) (Expr.mul (Expr.witness 2 0 (-1)) (Expr.sub (Expr.constant "1") (Expr.fixed 0 (0))))) (Expr.add (Expr.add (Expr.add (Expr.add (Expr.witness 2 1 (0)) (Expr.witness 2 2 (0))) (Expr.witness 2 3 (0))) (Expr.witness 2 4 (0))) (Expr.witness 2 5 (0))),
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryExtension_5,
  template := template_BinaryExtension_5,
  hints := [hint_BinaryExtension_5_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def hint_BinaryExtension_6_0 : HintTuple := {
  hintIndex := 1221,
  piop := "Direct",
  proves := false,
  busId := Expr.constant "5000",
  multiplicity := Expr.add (Expr.airValue 0) (Expr.constant "0"),
  slots := [
    { name := "39", value := Expr.constant "39" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
    { name := "0", value := Expr.constant "0" },
  ]
}

def constraint_BinaryExtension_6 : Expr := Expr.sub (Expr.mul (Expr.airValue 1) (Expr.add (Expr.add (Expr.mul (Expr.constant "39") (Expr.challenge 2 0)) (Expr.constant "5000")) (Expr.challenge 2 1))) (Expr.sub (Expr.constant "0") (Expr.airValue 0))
def template_BinaryExtension_6 : Expr := normalise (directAssumesNegFormZeroTailTemplate (Expr.challenge 2 0) (Expr.challenge 2 1) (Expr.airValue 1) hint_BinaryExtension_6_0)
def link_BinaryExtension_6 : ValidatedLink := {
  air := "BinaryExtension",
  constraintIndex := 6,
  shape := .directAssumesNegFormZeroTail,
  accumulator := Expr.airValue 1,
  alpha := Expr.challenge 2 0,
  gamma := Expr.challenge 2 1,
  constraint := constraint_BinaryExtension_6,
  template := template_BinaryExtension_6,
  hints := [hint_BinaryExtension_6_0],
  derivedTuples := [],
  templateFromShape := by rfl
  constraintEqualsTemplate := by rfl
}

def constraint_BinaryExtension_7 : Expr := Expr.mul (Expr.fixed 0 (1)) (Expr.sub (Expr.sub (Expr.airGroupValue 0) (Expr.witness 2 0 (0))) (Expr.airValue 1))
def template_BinaryExtension_7 : Expr := normalise (gsumFinalRowTemplate (Expr.fixed 0 (1)) (Expr.airGroupValue 0) (Expr.witness 2 0 (0)) [Expr.airValue 1])
def link_BinaryExtension_7 : ValidatedFinalRow := {
  air := "BinaryExtension",
  constraintIndex := 7,
  shape := .gsumFinalRow,
  selector := Expr.fixed 0 (1),
  groupValue := Expr.airGroupValue 0,
  gsum := Expr.witness 2 0 (0),
  directTerms := [Expr.airValue 1],
  constraint := constraint_BinaryExtension_7,
  template := template_BinaryExtension_7,
  hints := [],
  templateFromTerms := by rfl
  constraintEqualsTemplate := by rfl
}

def airStatuses : List AirStatus := [
  airStatus_Dma,
  airStatus_DmaMemCpy,
  airStatus_DmaInputCpy,
  airStatus_Dma64Aligned,
  airStatus_Dma64AlignedInputCpy,
  airStatus_Dma64AlignedMemSet,
  airStatus_Dma64AlignedMem,
  airStatus_Dma64AlignedMemCpy,
  airStatus_DmaUnaligned,
  airStatus_DmaPrePost,
  airStatus_DmaPrePostMemCpy,
  airStatus_DmaPrePostInputCpy,
  airStatus_Main,
  airStatus_Rom,
  airStatus_Mem,
  airStatus_RomData,
  airStatus_InputData,
  airStatus_MemAlign,
  airStatus_MemAlignByte,
  airStatus_MemAlignReadByte,
  airStatus_MemAlignWriteByte,
  airStatus_Arith,
  airStatus_Binary,
  airStatus_BinaryAdd,
  airStatus_BinaryExtension,
  airStatus_Add256,
  airStatus_ArithEq,
  airStatus_ArithEq384,
  airStatus_Keccakf,
  airStatus_Sha256f,
  airStatus_Poseidon2,
  airStatus_Blake2br,
  airStatus_SpecifiedRanges,
  airStatus_VirtualTable0,
  airStatus_VirtualTable1,
]

def unlinkedMixedConstraints : List ConstraintOnly := [
  constraintOnly_Main_0 ,
  constraintOnly_Main_3 ,
  constraintOnly_Main_4 ,
  constraintOnly_Main_9 ,
  constraintOnly_Main_10 ,
  constraintOnly_Main_19 ,
  constraintOnly_Main_20 ,
  constraintOnly_Main_21 ,
  constraintOnly_Main_38 ,
  constraintOnly_Mem_0 ,
  constraintOnly_Mem_1 ,
  constraintOnly_Mem_2 ,
  constraintOnly_Mem_9 ,
  constraintOnly_Mem_10 ,
  constraintOnly_Mem_11 ,
  constraintOnly_Mem_12 ,
  constraintOnly_Mem_13 ,
  constraintOnly_Mem_14 ,
  constraintOnly_Mem_15 ,
  constraintOnly_Mem_16 ,
  constraintOnly_Mem_17 ,
  constraintOnly_Mem_19 ,
  constraintOnly_Mem_20 ,
  constraintOnly_Mem_22 ,
  constraintOnly_Mem_33 ,
]

def validatedLinks : List ValidatedLink := [
  link_Main_39 ,
  link_Main_40 ,
  link_Main_41 ,
  link_Main_42 ,
  link_Main_43 ,
  link_Main_44 ,
  link_Main_45 ,
  link_Main_46 ,
  link_Main_47 ,
  link_Main_48 ,
  link_Main_49 ,
  link_Main_50 ,
  link_Main_51 ,
  link_Main_52 ,
  link_Main_53 ,
  link_Main_54 ,
  link_Main_55 ,
  link_Main_56 ,
  link_Main_57 ,
  link_Main_58 ,
  link_Main_59 ,
  link_Main_60 ,
  link_Main_61 ,
  link_Main_62 ,
  link_Main_63 ,
  link_Main_64 ,
  link_Main_65 ,
  link_Main_66 ,
  link_Main_67 ,
  link_Main_68 ,
  link_Main_69 ,
  link_Main_70 ,
  link_Main_71 ,
  link_Main_72 ,
  link_Main_73 ,
  link_Main_74 ,
  link_Main_75 ,
  link_Main_76 ,
  link_Main_77 ,
  link_Main_78 ,
  link_Main_79 ,
  link_Main_80 ,
  link_Main_81 ,
  link_Main_82 ,
  link_Main_83 ,
  link_Main_84 ,
  link_Main_85 ,
  link_Main_86 ,
  link_Main_87 ,
  link_Main_88 ,
  link_Main_89 ,
  link_Main_90 ,
  link_Main_91 ,
  link_Main_92 ,
  link_Main_93 ,
  link_Main_94 ,
  link_Main_95 ,
  link_Main_96 ,
  link_Main_97 ,
  link_Main_98 ,
  link_Main_99 ,
  link_Main_100 ,
  link_Main_101 ,
  link_Main_102 ,
  link_Main_103 ,
  link_Main_104 ,
  link_Main_105 ,
  link_Main_106 ,
  link_Main_107 ,
  link_Main_108 ,
  link_Main_109 ,
  link_Main_110 ,
  link_Main_111 ,
  link_Main_112 ,
  link_Main_113 ,
  link_Main_114 ,
  link_Main_115 ,
  link_Main_116 ,
  link_Main_117 ,
  link_Main_118 ,
  link_Main_119 ,
  link_Main_120 ,
  link_Main_121 ,
  link_Main_122 ,
  link_Main_123 ,
  link_Main_124 ,
  link_Main_125 ,
  link_Main_126 ,
  link_Main_127 ,
  link_Main_128 ,
  link_Main_129 ,
  link_Main_130 ,
  link_Main_131 ,
  link_Main_132 ,
  link_Main_133 ,
  link_Main_134 ,
  link_Main_135 ,
  link_Main_136 ,
  link_Main_137 ,
  link_Main_138 ,
  link_Main_139 ,
  link_Main_140 ,
  link_Main_141 ,
  link_Main_142 ,
  link_Mem_24 ,
  link_Mem_25 ,
  link_Mem_26 ,
  link_Mem_27 ,
  link_Mem_28 ,
  link_Mem_29 ,
  link_Mem_30 ,
  link_Mem_31 ,
  link_Mem_32 ,
  link_MemAlign_33 ,
  link_MemAlign_34 ,
  link_MemAlign_35 ,
  link_MemAlign_36 ,
  link_MemAlign_37 ,
  link_MemAlign_38 ,
  link_MemAlignByte_9 ,
  link_MemAlignByte_10 ,
  link_MemAlignByte_11 ,
  link_MemAlignByte_12 ,
  link_MemAlignByte_13 ,
  link_MemAlignByte_14 ,
  link_MemAlignReadByte_4 ,
  link_MemAlignReadByte_5 ,
  link_MemAlignReadByte_6 ,
  link_MemAlignReadByte_7 ,
  link_MemAlignReadByte_8 ,
  link_MemAlignWriteByte_7 ,
  link_MemAlignWriteByte_8 ,
  link_MemAlignWriteByte_9 ,
  link_MemAlignWriteByte_10 ,
  link_MemAlignWriteByte_11 ,
  link_MemAlignWriteByte_12 ,
  link_MemAlignWriteByte_13 ,
  link_Arith_49 ,
  link_Arith_50 ,
  link_Arith_51 ,
  link_Arith_52 ,
  link_Arith_53 ,
  link_Arith_54 ,
  link_Arith_55 ,
  link_Arith_56 ,
  link_Arith_57 ,
  link_Arith_58 ,
  link_Arith_59 ,
  link_Arith_60 ,
  link_Arith_61 ,
  link_Arith_62 ,
  link_Arith_63 ,
  link_Binary_7 ,
  link_Binary_8 ,
  link_Binary_9 ,
  link_Binary_10 ,
  link_Binary_11 ,
  link_Binary_12 ,
  link_BinaryAdd_4 ,
  link_BinaryAdd_5 ,
  link_BinaryAdd_6 ,
  link_BinaryAdd_7 ,
  link_BinaryExtension_0 ,
  link_BinaryExtension_1 ,
  link_BinaryExtension_2 ,
  link_BinaryExtension_3 ,
  link_BinaryExtension_4 ,
  link_BinaryExtension_5 ,
  link_BinaryExtension_6 ,
]

def validatedFinalRows : List ValidatedFinalRow := [
  link_Main_143 ,
  link_MemAlign_39 ,
  link_MemAlignByte_15 ,
  link_MemAlignReadByte_9 ,
  link_MemAlignWriteByte_14 ,
  link_Arith_64 ,
  link_Binary_13 ,
  link_BinaryAdd_8 ,
  link_BinaryExtension_7 ,
]

end Extraction.LookupWiring
