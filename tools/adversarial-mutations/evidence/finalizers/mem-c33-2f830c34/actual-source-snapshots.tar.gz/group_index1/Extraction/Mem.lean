import Mathlib

import Extraction.Circuit

set_option linter.all false

register_simp_attr Mem_air_simplification
register_simp_attr Mem_constraint_and_interaction_simplification

namespace Mem.extraction

-- airgroup: Zisk (id 0)  air: Mem (id 14)
-- witness column names:
--   stage 1 col 0: addr
--   stage 1 col 1: step
--   stage 1 col 2: sel
--   stage 1 col 3: addr_changes
--   stage 1 col 4: step_dual
--   stage 1 col 5: sel_dual
--   stage 1 col 6: value[0]
--   stage 1 col 7: value[1]
--   stage 1 col 8: wr
--   stage 1 col 9: previous_step
--   stage 1 col 10: l_increment
--   stage 1 col 11: h_increment
--   stage 1 col 12: read_same_addr
--   stage 2 col 0: gsum
--   stage 2 col 1: im_cluster
--   stage 2 col 2: im_cluster

-- air value names:
--   stage 1 air value 0: Mem.segment_id
--   stage 1 air value 1: Mem.is_first_segment
--   stage 1 air value 2: Mem.is_last_segment
--   stage 1 air value 3: Mem.previous_segment_value[0]
--   stage 1 air value 4: Mem.previous_segment_value[1]
--   stage 1 air value 5: Mem.previous_segment_step
--   stage 1 air value 6: Mem.previous_segment_addr
--   stage 1 air value 7: Mem.segment_last_value[0]
--   stage 1 air value 8: Mem.segment_last_value[1]
--   stage 1 air value 9: Mem.segment_last_step
--   stage 1 air value 10: Mem.segment_last_addr
--   stage 1 air value 11: Mem.distance_base[0]
--   stage 1 air value 12: Mem.distance_base[1]
--   stage 1 air value 13: Mem.distance_end[0]
--   stage 1 air value 14: Mem.distance_end[1]
--   stage 2 air value 15: Mem.im_direct[0]
--   stage 2 air value 16: Mem.im_direct[1]
--   stage 2 air value 17: Mem.im_direct[2]
--   stage 2 air value 18: Mem.im_direct[3]
--   stage 2 air value 19: Mem.im_direct[4]
--   stage 2 air value 20: Mem.im_direct[5]

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_0_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:103 Mem.is_first_segment*(1-Mem.is_first_segment)
    (((Extraction.Circuit.exposed c (index := 1)) * (1 - (Extraction.Circuit.exposed c (index := 1))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_1_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:104 Mem.is_last_segment*(1-Mem.is_last_segment)
    (((Extraction.Circuit.exposed c (index := 2)) * (1 - (Extraction.Circuit.exposed c (index := 2))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_2_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:107 Mem.is_first_segment*Mem.segment_id
    (((Extraction.Circuit.exposed c (index := 1)) * (Extraction.Circuit.exposed c (index := 0)))) = 0

  @[simp]
  def constraint_3_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:125 sel_dual*(1-sel_dual)
    (((Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_4_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:126 (1-sel)*sel_dual
    (((1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))) * (Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)))) = 0

  @[simp]
  def constraint_5_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:131 sel*(1-sel)
    (((Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_6_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:132 addr_changes*(1-addr_changes)
    (((Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_7_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:175 wr*(1-wr)
    (((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_8_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:178 wr*(1-sel)
    (((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_9_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:215 Mem.SEGMENT_L1'*(value[0]-Mem.segment_last_value[0])
    (((Extraction.Circuit.preprocessed c (column := 0) (row := row + 1) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0)) - (Extraction.Circuit.exposed c (index := 7))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_10_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:215 Mem.SEGMENT_L1'*(value[1]-Mem.segment_last_value[1])
    (((Extraction.Circuit.preprocessed c (column := 0) (row := row + 1) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) - (Extraction.Circuit.exposed c (index := 8))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_11_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:220 Mem.SEGMENT_L1'*(addr-Mem.segment_last_addr)
    (((Extraction.Circuit.preprocessed c (column := 0) (row := row + 1) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) - (Extraction.Circuit.exposed c (index := 10))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_12_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:226 Mem.SEGMENT_L1'*(((sel_dual*(step_dual-step))+step)-Mem.segment_last_step)
    (((Extraction.Circuit.preprocessed c (column := 0) (row := row + 1) (rotation := 0)) * ((((Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) - (Extraction.Circuit.exposed c (index := 9))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_13_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:265 (Mem.previous_segment_addr-335544320)-(Mem.distance_base[0]+(65536*Mem.distance_base[1]))
    ((((Extraction.Circuit.exposed c (index := 6)) - 335544320) - ((Extraction.Circuit.exposed c (index := 11)) + (65536 * (Extraction.Circuit.exposed c (index := 12)))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_14_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:283 (402653183-Mem.segment_last_addr)-(Mem.distance_end[0]+(65536*Mem.distance_end[1]))
    (((402653183 - (Extraction.Circuit.exposed c (index := 10))) - ((Extraction.Circuit.exposed c (index := 13)) + (65536 * (Extraction.Circuit.exposed c (index := 14)))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_15_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:367 previous_step-((Mem.SEGMENT_L1*(Mem.previous_segment_step-(previous_row_step)))+(previous_row_step))
    (((Extraction.Circuit.main c (id := 1) (column := 9) (row := row) (rotation := 0)) - (((Extraction.Circuit.preprocessed c (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.exposed c (index := 5)) - (((Extraction.Circuit.main c (id := 1) (column := 5) (row := row - 1) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 4) (row := row - 1) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row - 1) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 1) (row := row - 1) (rotation := 0))))) + (((Extraction.Circuit.main c (id := 1) (column := 5) (row := row - 1) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 4) (row := row - 1) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row - 1) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 1) (row := row - 1) (rotation := 0)))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_16_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:375 ((l_increment+(4194304*h_increment))+1)-((addr_changes*((delta_addr)-(delta_step)))+(delta_step))
    (((((Extraction.Circuit.main c (id := 1) (column := 10) (row := row) (rotation := 0)) + (4194304 * (Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0)))) + 1) - (((Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)) * (((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) - (((Extraction.Circuit.preprocessed c (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.exposed c (index := 6)) - (Extraction.Circuit.main c (id := 1) (column := 0) (row := row - 1) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 0) (row := row - 1) (rotation := 0)))) - (((Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 9) (row := row) (rotation := 0))) + (1 - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)))))) + (((Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 9) (row := row) (rotation := 0))) + (1 - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0))))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_17_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:377 (Mem.is_first_segment*Mem.SEGMENT_L1)*(1-addr_changes)
    ((((Extraction.Circuit.exposed c (index := 1)) * (Extraction.Circuit.preprocessed c (column := 0) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_18_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:390 read_same_addr-((1-addr_changes)*(1-wr))
    (((Extraction.Circuit.main c (id := 1) (column := 12) (row := row) (rotation := 0)) - ((1 - (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_19_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:403 (1-addr_changes)*(addr-(previous_addr))
    (((1 - (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0))) * ((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) - (((Extraction.Circuit.preprocessed c (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.exposed c (index := 6)) - (Extraction.Circuit.main c (id := 1) (column := 0) (row := row - 1) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 0) (row := row - 1) (rotation := 0)))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_20_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:423 read_same_addr*(value[0]-(previous_value))
    (((Extraction.Circuit.main c (id := 1) (column := 12) (row := row) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0)) - (((Extraction.Circuit.preprocessed c (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.exposed c (index := 3)) - (Extraction.Circuit.main c (id := 1) (column := 6) (row := row - 1) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 6) (row := row - 1) (rotation := 0)))))) = 0

  @[simp]
  def constraint_21_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:426 (addr_changes*(1-wr))*value[0]
    ((((Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)))) * (Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0)))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_22_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- mem/pil/mem.pil:423 read_same_addr*(value[1]-(previous_value))
    (((Extraction.Circuit.main c (id := 1) (column := 12) (row := row) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) - (((Extraction.Circuit.preprocessed c (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.exposed c (index := 4)) - (Extraction.Circuit.main c (id := 1) (column := 7) (row := row - 1) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 7) (row := row - 1) (rotation := 0)))))) = 0

  @[simp]
  def constraint_23_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem.pil:426 (addr_changes*(1-wr))*value[1]
    ((((Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)))) * (Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_24_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:590 (im_cluster*(((Zisk.gsum_e[5])+std_gamma)*((Zisk.gsum_e[6])+std_gamma)))-((-1*((Zisk.gsum_e[6])+std_gamma))+((Zisk.gsum_s[6])*((Zisk.gsum_e[5])+std_gamma)))
    ((((Extraction.Circuit.main c (id := 2) (column := 1) (row := row) (rotation := 0)) * (((((Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1))) * ((((((Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 102) + (Extraction.Circuit.challenge c (index := 1))))) - ((18446744069414584320 * ((((((Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) - (Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 102) + (Extraction.Circuit.challenge c (index := 1)))) + ((0 - (Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0))) * ((((Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1))))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_25_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:590 (im_cluster*(((Zisk.gsum_e[7])+std_gamma)*((Zisk.gsum_e[8])+std_gamma)))-((sel*((Zisk.gsum_e[8])+std_gamma))+(sel_dual*((Zisk.gsum_e[7])+std_gamma)))
    ((((Extraction.Circuit.main c (id := 2) (column := 2) (row := row) (rotation := 0)) * (((((((((((((((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 8) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * 8)) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) + 1)) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1))) * ((((((((((((((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 8) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * 8)) * (Extraction.Circuit.challenge c (index := 0))) + 1) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1))))) - (((Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)) * ((((((((((((((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 8) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * 8)) * (Extraction.Circuit.challenge c (index := 0))) + 1) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1)))) + ((Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)) * ((((((((((((((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 8) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * 8)) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) + 1)) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1))))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_26_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:599 (((gsum-('gsum*(1-__L1__)))-(im_cluster+im_cluster))*((Zisk.gsum_e[4])+std_gamma))+1
    ((((((Extraction.Circuit.main c (id := 2) (column := 0) (row := row) (rotation := 0)) - ((Extraction.Circuit.main c (id := 2) (column := 0) (row := row - 1) (rotation := 0)) * (1 - (Extraction.Circuit.preprocessed c (column := 1) (row := row) (rotation := 0))))) - ((Extraction.Circuit.main c (id := 2) (column := 1) (row := row) (rotation := 0)) + (Extraction.Circuit.main c (id := 2) (column := 2) (row := row) (rotation := 0)))) * ((((Extraction.Circuit.main c (id := 1) (column := 10) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 104) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_27_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (Mem.im_direct[0]*((Zisk.direct_gsum_e[0])+std_gamma))+1
    ((((Extraction.Circuit.exposed c (index := 15)) * ((((((((((((((Extraction.Circuit.exposed c (index := 4)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.exposed c (index := 3))) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.exposed c (index := 5))) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.exposed c (index := 6))) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.exposed c (index := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 2684354560) * (Extraction.Circuit.challenge c (index := 0))) + 11) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_28_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (Mem.im_direct[1]*((Zisk.direct_gsum_e[1])+std_gamma))-(Zisk.direct_gsum_s[1])
    ((((Extraction.Circuit.exposed c (index := 16)) * ((((((((((((((Extraction.Circuit.exposed c (index := 8)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.exposed c (index := 7))) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.exposed c (index := 9))) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.exposed c (index := 10))) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.exposed c (index := 0)) + 1)) * (Extraction.Circuit.challenge c (index := 0))) + 2684354560) * (Extraction.Circuit.challenge c (index := 0))) + 11) + (Extraction.Circuit.challenge c (index := 1)))) - (1 - (Extraction.Circuit.exposed c (index := 2))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_29_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (Mem.im_direct[2]*((Zisk.direct_gsum_e[2])+std_gamma))+1
    ((((Extraction.Circuit.exposed c (index := 17)) * ((((Extraction.Circuit.exposed c (index := 11)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_30_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (Mem.im_direct[3]*((Zisk.direct_gsum_e[3])+std_gamma))+1
    ((((Extraction.Circuit.exposed c (index := 18)) * ((((Extraction.Circuit.exposed c (index := 12)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_31_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (Mem.im_direct[4]*((Zisk.direct_gsum_e[4])+std_gamma))+1
    ((((Extraction.Circuit.exposed c (index := 19)) * ((((Extraction.Circuit.exposed c (index := 13)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_32_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (Mem.im_direct[5]*((Zisk.direct_gsum_e[5])+std_gamma))+1
    ((((Extraction.Circuit.exposed c (index := 20)) * ((((Extraction.Circuit.exposed c (index := 14)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_33_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:696 __L1__'*((Zisk.gsum_result-gsum)-(((((Mem.im_direct[0]+Mem.im_direct[1])+Mem.im_direct[2])+Mem.im_direct[3])+Mem.im_direct[4])+Mem.im_direct[5]))
    (((Extraction.Circuit.preprocessed c (column := 1) (row := row + 1) (rotation := 0)) * (((Extraction.Circuit.exposed c (index := 1)) - (Extraction.Circuit.main c (id := 2) (column := 0) (row := row) (rotation := 0))) - ((((((Extraction.Circuit.exposed c (index := 15)) + (Extraction.Circuit.exposed c (index := 16))) + (Extraction.Circuit.exposed c (index := 17))) + (Extraction.Circuit.exposed c (index := 18))) + (Extraction.Circuit.exposed c (index := 19))) + (Extraction.Circuit.exposed c (index := 20)))))) = 0

end Mem.extraction
