import asyncio
import fcntl
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path('/home/cody/zisk-fv-api-loads-approved')
OUT = Path(sys.argv[1])
OUT.mkdir(exist_ok=False)
TOOLCHAIN = Path('/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin')
fixture = ROOT / 'trust/consistency/global_theorem_instantiation_add.lean'
backend = [str(TOOLCHAIN / 'lean'), '--server', '-j1', '--tstack=400000', '-Dpp.unicode.fun=true']
injection = ('import functools; import lean_lsp_mcp.client_utils as cu; '
             'from leanclient.aio import AsyncLeanLSPClient; '
             'cu.AsyncLeanLSPClient=functools.partial(AsyncLeanLSPClient,server_command='
             + repr(backend) + ',request_timeout=1800.0); '
             'from lean_lsp_mcp.server import create_server; create_server().run()')
records = []

async def main():
    path = subprocess.check_output([str(TOOLCHAIN / 'lake'), 'env', 'printenv', 'LEAN_PATH'],
                                   cwd=ROOT, text=True).strip()
    environment = dict(os.environ, LEAN_PROJECT_PATH=str(ROOT), LEAN_PATH=path,
                       LEAN_LSP_MAX_OPEN_FILES='1', LEAN_NUM_THREADS='1',
                       LEAN_MCP_PREWARM_FILES='', LEAN_MCP_SCRATCH_SLOTS='1',
                       PYTHONDONTWRITEBYTECODE='1', LAKE=str(TOOLCHAIN / 'lake'))
    command = ['/usr/bin/bwrap', '--ro-bind', '/', '/', '--tmpfs', '/tmp',
               '--proc', '/proc', '--dev', '/dev', '--chdir', str(ROOT), '--',
               sys.executable, '-c', injection]
    parameters = StdioServerParameters(command=command[0], args=command[1:],
                                      env=environment, cwd=str(ROOT))
    records.append({'project': str(ROOT), 'backend': backend, 'LEAN_PATH': path,
                    'source': subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                    'versions': {name: importlib.metadata.version(name) for name in ['lean-lsp-mcp', 'leanclient', 'mcp']},
                    'fixture_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
                    'filesystem': 'Whole real source/cache filesystem read-only; scratch tmpfs; actual populated normal Lake project'})
    with open('/tmp/closure-417-lean-lsp.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with (OUT / 'server-stderr.log').open('w') as errors:
                async with stdio_client(parameters, errlog=errors) as streams:
                    async with ClientSession(*streams) as session:
                        initialized = await session.initialize()
                        records.append({'initialize': initialized.model_dump(mode='json')})
                        tools = await session.list_tools()
                        records.append({'schemas': {tool.name: tool.input_schema for tool in tools.tools}})
                        calls = [
                            ('lean_file_outline', {'file_path': str(fixture)}),
                            ('lean_hover_info', {'file_path': str(fixture), 'line': 74, 'column': 16}),
                            ('lean_hover_info', {'file_path': str(fixture), 'line': 210, 'column': 35}),
                            ('lean_goal', {'file_path': str(fixture), 'line': 103, 'timeout_s': 600}),
                            ('lean_diagnostic_messages', {'file_path': str(fixture), 'timeout_s': 600}),
                        ]
                        for name, arguments in calls:
                            response = await session.call_tool(name, arguments)
                            records.append({'tool': name, 'arguments': arguments,
                                            'response': response.model_dump(mode='json')})
                            (OUT / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
                            if response.is_error:
                                raise RuntimeError('Actual installed MCP backend failure: ' + str(response))
        except BaseException as error:
            records.append({'actual_exception': repr(error)})
            raise
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)
            (OUT / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
    print('ACTUAL MCP QUERY SESSION COMPLETE; inspect concrete types/goals/diagnostics (not a kernel pass)')

asyncio.run(main())
