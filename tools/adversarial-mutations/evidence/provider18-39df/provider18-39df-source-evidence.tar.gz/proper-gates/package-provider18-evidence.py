import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
PROPER = Path('/home/cody/zisk-fv-api-loads-approved')
OLD = Path('/tmp/closure415-main456-serial-tevt428i')
MODELS = Path('/tmp/closure415-d715-40fed-execution-yv2xx470')
READY = Path('/tmp/closure415-d715-model-control-ready-3vlv4964')
EXPECTED = '39df5795bedf37955b3ee0e17b82be55f47c25d1'
assert subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=PROPER, text=True).strip() == EXPECTED
assert (OUT / 'full.status').read_text().strip() == '0'
assert (OUT / 'remaining-required-gates-complete.status').read_text().strip() == '0'
unit = (OUT / 'required-unit.log').read_text()
assert 'Finished with result: success' in unit
assert 'Main processes terminated with: code=exited, status=0/SUCCESS' in unit
assert 'ALL CHECKS PASSED' in (OUT / 'full.log').read_text()

files = {}
def add(path, name):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    assert not any(part in {'.lake', 'owned-proof-objects', 'readonly-namespaces'} for part in Path(name).parts)
    assert path.suffix not in {'.olean', '.ilean', '.ir', '.o', '.bc', '.trace'}
    files[name] = path

for path in OUT.iterdir():
    if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.status', '.txt', '.sha256', '.sh', '.py'}:
        add(path, 'proper-gates/' + path.name)
for directory in ['add-fixture-mcp-before', 'add-fixture-mcp-after']:
    for name in ['results.json', 'server-stderr.log']:
        add(OUT / directory / name, 'proper-gates/' + directory + '/' + name)
for module in ['ZiskFv.Compliance.OpEnvelope', 'ZiskFv.Soundness', 'combined']:
    for name in ['summary.json', 'all-roots.jsonl', 'full-graph.jsonl']:
        add(OUT / 'root-raw' / module / name, 'proper-root/' + module + '/' + name)
record = json.loads((OLD / 'owner-cancelled-raw-and-exact-critical-scope.json').read_text())
add(OLD / 'owner-cancelled-raw-and-exact-critical-scope.json', 'critical40/actual-scope-and-cancellation.json')
for module in record['exact_changed_scope']['genuinely_changed_provider_critical_modules'] + record['exact_changed_scope']['comparison21_modules']:
    for name in ['summary.json', 'all-roots.jsonl', 'full-graph.jsonl']:
        add(OLD / 'raw' / module / name, 'critical40/' + module + '/' + name)
    add(PROPER / (module.replace('.', '/') + '.lean'), 'checked-source/' + module.replace('.', '/') + '.lean')
add(MODELS / 'final-three-case-composition-report.json', 'model-controls/final-three-case-composition-report.json')
for case, unit_dir in [('normal', 'normal-exactprofile-unit'), ('source125-as124', 'source125-as124-unit'), ('source124-as125', 'source124-as125-unit')]:
    case_dir = MODELS / 'cases-exactprofile' / case
    for path in case_dir.iterdir():
        if path.is_file() and not path.is_symlink() and path.suffix in {'.json', '.log', '.txt'}:
            add(path, 'model-controls/' + case + '/' + path.name)
    for path in (MODELS / unit_dir).iterdir():
        if path.is_file() and not path.is_symlink():
            add(path, 'model-controls/' + unit_dir + '/' + path.name)
    for path in (READY / 'fixtures' / case).rglob('*.lean'):
        add(path, 'model-controls/fixtures/' + case + '/' + str(path.relative_to(READY / 'fixtures' / case)))
for name in ['run-model-control.py', 'control-plan.json', 'ready-model-control-contract.json']:
    add(READY / name, 'model-controls/' + name)
for name in ['normal-first-setup-failure.json', 'normal-second-prefix-setup-failure.json', 'normal-third-profile-failure.json']:
    add(MODELS / name, 'preserved-non-kills/' + name)
add(PROPER / 'trust/consistency/global_theorem_instantiation_add.lean', 'checked-source/trust/consistency/global_theorem_instantiation_add.lean')
manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()} for name, path in sorted(files.items())}
manifest_path = OUT / 'provider18-evidence-manifest.json'
manifest_path.write_text(json.dumps({'tested_source': EXPECTED, 'files': manifest, 'scope': 'Source/log/provenance only; no compiled objects, IR, caches, borrowed namespaces or fabricated traces. Critical40 has no completed combined389 claim; proper Root has actual combined755.'}, indent=2) + '\n')
archive = OUT / 'provider18-39df-source-evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as bundle:
    for name, path in sorted(files.items()):
        bundle.add(path, arcname=name, recursive=False)
    bundle.add(manifest_path, arcname='evidence-manifest.json', recursive=False)
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(), 'members': len(files) + 1, 'manifest': str(manifest_path)}))
