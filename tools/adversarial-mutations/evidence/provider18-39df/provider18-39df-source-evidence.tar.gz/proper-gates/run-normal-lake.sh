#!/usr/bin/env bash
set -euo pipefail
out=/tmp/closure418-provider18-proper40fed.tagVA7
cd /home/cody/zisk-fv-api-loads-approved
expected=40feddddd4d49e4e364e57046b884178f6c1f042
[[ "$(/usr/bin/git rev-parse HEAD)" == "$expected" ]]
group=$(cut -d: -f3 /proc/self/cgroup)
control=/sys/fs/cgroup$group
[[ "$(cat "$control/memory.max")" == 34359738368 ]]
[[ "$(cat "$control/memory.swap.max")" == 0 ]]
[[ "$(cat "$control/pids.max")" == 128 ]]
[[ "$(cat "$control/cpu.max")" == '100000 100000' ]]
export PATH=/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin:/home/cody/.nix-profile/bin:/usr/local/bin:/usr/bin:/bin
export LEAN_NUM_THREADS=1 CARGO_BUILD_JOBS=1 NIX_BUILD_CORES=1
export NODE_OPTIONS=--max-old-space-size=16384
export NIX_CONFIG="${NIX_CONFIG-}
cores = 1
max-jobs = 1"
unset ZISK_FV_TEST_SKIP_AENEAS AENEAS_CHECK_LEAN
{
  printf 'SOURCE %s\nCGROUP %s\n' "$expected" "$group"
  printf 'Normal Lake default targets include ZiskFv, Extraction, and all21 supplemental Source415DomainComparison modules. No foreign CLI object copies or fabricated traces.\n'
  printf 'Raw389 extra preflight CANCELLED_REDUNDANT_PREFLIGHT; completed outputs preserved, not passed.\n'
  for key in memory.max memory.swap.max pids.max cpu.max; do printf '%s=' "$key"; cat "$control/$key"; done
  printf 'All local build descendants inherit the cgroup. Nix daemon/builders are not claimed bounded by this user cgroup; nested requests max-jobs1/cores1.\n'
} > "$out/provenance.txt"
start=$(date +%s)
set +e
/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin/lake build > "$out/lake.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$out/lake.status"
printf '%s\n' "$(( $(date +%s) - start ))" > "$out/lake.elapsed-seconds"
for key in memory.current memory.peak memory.events pids.current pids.peak pids.events cpu.stat; do
  [[ ! -f "$control/$key" ]] || cat "$control/$key" > "$out/lake-${key//./-}.txt"
done
[[ "$rc" == 0 ]]
printf '0\n' > "$out/normal-lake-complete.status"
printf 'NORMAL DEFAULT LAKE BUILD PASS source=%s elapsed=%ss\n' "$expected" "$(cat "$out/lake.elapsed-seconds")"
