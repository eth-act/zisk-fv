#!/usr/bin/env bash
set -euo pipefail
out=/tmp/closure418-provider18-proper40fed.tagVA7
cd /home/cody/zisk-fv-api-loads-approved
[[ "$(/usr/bin/git rev-parse HEAD)" == 40feddddd4d49e4e364e57046b884178f6c1f042 ]]
[[ "$(cat "$out/normal-lake-complete.status")" == 0 ]]
group=$(cut -d: -f3 /proc/self/cgroup)
control=/sys/fs/cgroup$group
[[ "$(cat "$control/memory.max")" == 34359738368 ]]
[[ "$(cat "$control/memory.swap.max")" == 0 ]]
[[ "$(cat "$control/pids.max")" == 128 ]]
[[ "$(cat "$control/cpu.max")" == '100000 100000' ]]
export PATH=/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin:/home/cody/.nix-profile/bin:/usr/local/bin:/usr/bin:/bin
export LEAN_NUM_THREADS=1
# Use actual normal Lake search paths and proof objects; the borrowed CLI
# provider workspace is never a fallback. The observer is the checked source
# previously used for the completed, unpruned 40-module critical scopes.
set +e
/usr/bin/bwrap --ro-bind / / --bind "$out" "$out" --proc /proc --dev /dev \
  --chdir /home/cody/zisk-fv-api-loads-approved -- \
  /home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin/lake env lean \
  -j1 --tstack=400000 -Dpp.unicode.fun=true -DElab.async=false --run \
  "$out/Current18RawObserver.lean" --batch "$out/root-and-op-envelope-targets.txt" \
  "$out/root-raw" > "$out/root-tcb.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$out/root-tcb-observer.status"
for key in memory.peak memory.events pids.peak pids.events cpu.stat; do
  [[ ! -f "$control/$key" ]] || cat "$control/$key" > "$out/root-tcb-${key//./-}.txt"
done
[[ "$rc" == 0 ]]
python3 "$out/check-root-and-op-envelope.py" > "$out/root-tcb-check.log" 2>&1
printf '0\n' > "$out/root-tcb-complete.status"
cat "$out/root-tcb-check.log"
