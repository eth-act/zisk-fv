#!/usr/bin/env bash
set -euo pipefail
out=/tmp/closure418-provider18-proper40fed.tagVA7
cd /home/cody/zisk-fv-api-loads-approved
group=$(cut -d: -f3 /proc/self/cgroup)
control=/sys/fs/cgroup$group
[[ "$(cat "$control/memory.max")" == 34359738368 ]]
[[ "$(cat "$control/memory.swap.max")" == 0 ]]
[[ "$(cat "$control/pids.max")" == 128 ]]
[[ "$(cat "$control/cpu.max")" == '100000 100000' ]]
export PATH=/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin:/home/cody/.nix-profile/bin:/usr/local/bin:/usr/bin:/bin
export LEAN_NUM_THREADS=1
sha256sum trust/consistency/global_theorem_instantiation_add.lean > "$out/add-fixture-kernel-source.sha256"
set +e
lake env lean trust/consistency/global_theorem_instantiation_add.lean > "$out/add-fixture-kernel.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$out/add-fixture-kernel.status"
for key in memory.peak memory.events pids.peak pids.events; do
  [[ ! -f "$control/$key" ]] || cat "$control/$key" > "$out/add-fixture-${key//./-}.txt"
done
[[ "$rc" == 0 ]]
if grep -Eq 'sorryAx|uses `sorry`' "$out/add-fixture-kernel.log"; then
  cat "$out/add-fixture-kernel.log"
  exit 1
fi
printf '0\n' > "$out/add-fixture-kernel-complete.status"
printf 'CONCRETE ADD FIXTURE KERNEL PASS; full row Spec and all8 StaticFacts retained\n'
