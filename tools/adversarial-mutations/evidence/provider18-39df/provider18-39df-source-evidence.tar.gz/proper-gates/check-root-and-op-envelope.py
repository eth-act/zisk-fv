#!/usr/bin/env python3
import json
from pathlib import Path

base = Path(__file__).resolve().parent
cap_record = json.loads((base / 'captured-old77-cap.json').read_text())
old77 = set(cap_record['names'])
assert len(old77) == 77
old75 = old77 - {'Lean.ofReduceBool', 'Lean.trustCompiler'}
assert len(old75) == 75
modules = (base / 'root-and-op-envelope-targets.txt').read_text().splitlines()
assert modules == ['ZiskFv.Compliance.OpEnvelope', 'ZiskFv.Soundness']
all_names = set()
all_axioms = set()
observations = []
root_soundness = None
for module in [*modules, 'combined']:
    directory = base / 'root-raw' / module
    summary = json.loads((directory / 'summary.json').read_text())
    roots = [json.loads(line) for line in (directory / 'all-roots.jsonl').read_text().splitlines()]
    names = [row['root'] for row in roots]
    assert len(names) == len(set(names)) == summary['root_count']
    assert sorted(names) == sorted(summary['roots'])
    assert summary['allowOpaque'] is True
    assert summary['cross_check'] == 'Union and EVERY individual root agree with the installed Lean.collectAxioms implementation'
    assert 'private/compiler' in summary['coverage'] and 'no namespace pruning' in summary['coverage']
    cap = old75 if module == 'ZiskFv.Compliance.OpEnvelope' else old77
    union = set()
    for row in roots:
        axioms = set(row['raw_axioms'])
        assert axioms <= cap, (module, row['root'], sorted(axioms - cap))
        paths = row['axiom_paths']
        assert {item['axiom'] for item in paths} == axioms
        for item in paths:
            assert item['path'][0] == row['root'] and item['path'][-1] == item['axiom']
        union |= axioms
        if row['root'] == 'ZiskFv.Compliance.root_soundness':
            assert axioms == old77, ('Root closure differs from captured exact old77', sorted(axioms ^ old77))
            root_soundness = row
    assert union == set(summary['raw_axiom_union'])
    if module != 'combined':
        assert not all_names.intersection(names)
        all_names.update(names)
        all_axioms |= union
    else:
        assert set(names) == all_names and union == all_axioms
    observations.append({'module': module, 'roots': len(names), 'axioms': sorted(union),
                         'nodes': summary['nodes'], 'opaque_nodes': summary['opaque_node_count'],
                         'allowOpaque': True, 'independent_collectAxioms_every_root_and_union': True})
assert root_soundness is not None
report = {'source': '40feddddd4d49e4e364e57046b884178f6c1f042',
          'scope': 'All actual defining/private/compiler/constructor/type+opaque-value roots in changed OpEnvelope and actual Soundness; no unchanged reverse-dependency quota',
          'policy': 'Captured old75 for OpEnvelope; exact captured old77 for root_soundness, old77 ceiling elsewhere; no allowlist growth',
          'observations': observations,
          'reuse': 'Earlier 40 completed genuinely changed provider/comparison scopes remain separate actual source7aa evidence, not an ALL389 pass or proper-Lake trace claim'}
(base / 'root-tcb-checked.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': 'PASS_APPLICABLE_ROOT_AND_CHANGED_OP_ENVELOPE_TCB',
                  'defining_roots': len(all_names), 'report': str(base / 'root-tcb-checked.json')}))
