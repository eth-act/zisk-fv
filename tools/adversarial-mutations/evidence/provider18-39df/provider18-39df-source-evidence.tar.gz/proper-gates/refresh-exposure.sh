#!/usr/bin/env bash
set -euo pipefail
out=/tmp/closure418-provider18-proper40fed.tagVA7
cd /home/cody/zisk-fv-api-loads-approved
group=$(cut -d: -f3 /proc/self/cgroup)
control=/sys/fs/cgroup$group
[[ "$(cat "$control/memory.max")" == 34359738368 ]]
[[ "$(cat "$control/memory.swap.max")" == 0 ]]
[[ "$(cat "$control/pids.max")" == 128 ]]
[[ "$(cat "$control/cpu.max")" == '100000 100000' ]]
export PATH=/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin:/home/cody/.nix-profile/bin:/usr/local/bin:/usr/bin:/bin
export LEAN_NUM_THREADS=1
set +e
python3 tools/mirror-roundtrip/exposure.py --write > "$out/exposure-refresh.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$out/exposure-refresh.status"
for key in memory.peak memory.events pids.peak pids.events; do
  [[ ! -f "$control/$key" ]] || cat "$control/$key" > "$out/exposure-${key//./-}.txt"
done
[[ "$rc" == 0 ]]
printf 'ACTUAL COMPILED EXPOSURE LEDGER REFRESH PASS (existing reporter, no source/text fallback)\n'
