#!/usr/bin/env bash
set -euo pipefail
out=/tmp/closure418-provider18-proper40fed.tagVA7
cd /home/cody/zisk-fv-api-loads-approved
expected=${1:?actual reviewed source HEAD required}
[[ "$(/usr/bin/git rev-parse HEAD)" == "$expected" ]]
[[ "$(cat "$out/normal-lake-complete.status")" == 0 ]]
[[ "$(cat "$out/root-tcb-complete.status")" == 0 ]]
group=$(cut -d: -f3 /proc/self/cgroup)
control=/sys/fs/cgroup$group
[[ "$(cat "$control/memory.max")" == 34359738368 ]]
[[ "$(cat "$control/memory.swap.max")" == 0 ]]
[[ "$(cat "$control/pids.max")" == 128 ]]
[[ "$(cat "$control/cpu.max")" == '100000 100000' ]]
export PATH=/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin:/home/cody/.nix-profile/bin:/nix/var/nix/profiles/default/bin:/home/cody/.cargo/bin:/usr/local/bin:/usr/bin:/bin
export LEAN_NUM_THREADS=1 CARGO_BUILD_JOBS=1 NIX_BUILD_CORES=1
export NODE_OPTIONS=--max-old-space-size=16384
export NIX_CONFIG="${NIX_CONFIG-}
cores = 1
max-jobs = 1"
unset ZISK_FV_TEST_SKIP_AENEAS AENEAS_CHECK_LEAN
printf 'SOURCE %s\nCGROUP %s\nNix daemon/builders outside this user cgroup are NOT claimed memory-bounded. Nested requests constrained to cores1/maxjobs1.\n' "$expected" "$group" > "$out/remaining-gates-provenance.txt"
run_phase() {
  local name=$1; shift
  local start rc
  start=$(date +%s)
  set +e
  "$@" > "$out/$name.log" 2>&1
  rc=$?
  set -e
  printf '%s\n' "$rc" > "$out/$name.status"
  printf '%s\n' "$(( $(date +%s) - start ))" > "$out/$name.elapsed-seconds"
  for key in memory.peak memory.events pids.peak pids.events cpu.stat; do
    [[ ! -f "$control/$key" ]] || cat "$control/$key" > "$out/$name-${key//./-}.txt"
  done
  [[ "$rc" == 0 ]]
  printf 'PASS phase=%s source=%s elapsed=%ss\n' "$name" "$expected" "$(cat "$out/$name.elapsed-seconds")"
}
case "${2:-v1}" in
  v1)
    run_phase v1 trust/scripts/check-all.sh
    run_phase v2 trust/scripts/check-all-semantic.sh
    ;;
  v2)
    [[ "$(cat "$out/v1.status")" == 0 ]]
    run_phase v2 trust/scripts/check-all-semantic.sh
    ;;
  full)
    [[ "$(cat "$out/v1.status")" == 0 ]]
    [[ "$(cat "$out/v2.status")" == 0 ]]
    printf 'Retaining actual standalone V1/V2 passes; complete Nix still executes every required phase.\n'
    ;;
  *) printf 'Expected starting phase v1, v2 or full\n' >&2; exit 2 ;;
esac
run_phase full nix run --cores 1 --max-jobs 1 .#test
printf '0\n' > "$out/remaining-required-gates-complete.status"
