#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

BASE = Path(__file__).resolve().parent
PLAN = json.loads((BASE / 'control-plan.json').read_text())

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()

def unit_success(log):
    text = log.read_text()
    return ('Finished with result: success' in text and
            'Main processes terminated with: code=exited, status=0/SUCCESS' in text)

def relative_module(relative):
    # Exclude every artifact suffix, including .ir/.bc and future sidecars.
    stem = relative.name.split('.', 1)[0]
    return '.'.join([*relative.parts[:-1], stem])

def mirror_namespace(source, destination, excluded, only_roots=None):
    destination.mkdir(parents=True, exist_ok=True)
    for directory, dirs, files in os.walk(source, followlinks=True):
        relative = Path(directory).relative_to(source)
        if only_roots is not None and not relative.parts:
            dirs[:] = [name for name in dirs if name in only_roots]
        if len(relative.parts) > 64:
            raise RuntimeError('Namespace symlink cycle or unexpected depth')
        target = destination / relative
        target.mkdir(exist_ok=True)
        for name in files:
            rel = relative / name
            if only_roots is not None and rel.parts[0].split('.', 1)[0] not in only_roots:
                continue
            if relative_module(rel) in excluded:
                continue
            origin = Path(directory) / name
            if origin.is_file():
                (target / name).symlink_to(origin.resolve())

def declaration_at(text, line):
    found = []
    for number, source_line in enumerate(text.splitlines(), 1):
        if number > line:
            break
        match = re.match(r'\s*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma|def|abbrev|instance)\s+([^\s(:{]+)', source_line)
        if match:
            found.append({'name': match.group(1), 'line': number})
    return found[-1] if found else None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', required=True, choices=['normal', *PLAN['model_edits']])
    parser.add_argument('--proper-root', type=Path, required=True)
    parser.add_argument('--proper-normal-unit-log', type=Path, required=True)
    parser.add_argument('--proper-normal-inner-status', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--fresh-control-unit-log', type=Path)
    args = parser.parse_args()
    args.output_root = args.output_root.resolve()
    if not args.output_root.is_relative_to('/tmp'):
        raise RuntimeError('All experiment outputs must be private /tmp artifacts')
    proper = args.proper_root.resolve()
    if not unit_success(args.proper_normal_unit_log) or args.proper_normal_inner_status.read_text().strip() != '0':
        raise RuntimeError('Proper current normal Lake and actual unit success are prerequisites')
    actual_head = subprocess.check_output(['/usr/bin/git', '-C', str(proper), 'rev-parse', 'HEAD'], text=True).strip()
    if actual_head != PLAN['expected_proper_source']:
        raise RuntimeError('Actual proper normal source head differs from reviewed control')
    group = Path('/proc/self/cgroup').read_text().strip().split(':', 2)[2]
    control = Path('/sys/fs/cgroup') / group.lstrip('/')
    expected_limits = {'memory.max': '34359738368', 'memory.swap.max': '0',
                       'pids.max': '128', 'cpu.max': '100000 100000'}
    if any((control / name).read_text().strip() != value for name, value in expected_limits.items()):
        raise RuntimeError('Fresh approved 32GiB/swap0/tasks128/CPU1 user unit required')
    if sha(Path(PLAN['compiler'])) != PLAN['compiler_sha256']:
        raise RuntimeError('Verified compiler binary changed')
    if args.case != 'normal':
        normal = json.loads((args.output_root / 'normal' / 'result.json').read_text())
        if normal['status'] != 'PASS_FRESH_NORMAL_COMPOSITION_CONTROL':
            raise RuntimeError('Fresh SAME actual composition control must pass first')
        if args.fresh_control_unit_log is None or not unit_success(args.fresh_control_unit_log):
            raise RuntimeError('Actual fresh-control unit Result/main EXITED0 required, not inner exit alone')
    case = args.output_root / args.case
    case.mkdir(parents=True, exist_ok=False)
    sources = BASE / 'fixtures' / args.case
    for module, expected in PLAN['source_sha256'].items():
        path = proper / (module.replace('.', '/') + '.lean')
        if sha(path) != expected:
            raise RuntimeError('Necessary normal source ancestor drift: ' + module)
    target_rel = Path(PLAN['actual_consumer_target'].replace('.', '/'))
    target_trace = proper / '.lake/build/lib/lean' / target_rel.with_suffix('.trace')
    trace = json.loads(target_trace.read_text())
    messages = [entry['message'] for entry in trace.get('log', []) if 'LEAN_PATH=' in entry.get('message', '')]
    if len(messages) != 1:
        raise RuntimeError('Actual proper consumer trace must provide one exact compiler search path')
    assignments = [token[len('LEAN_PATH='):] for token in shlex.split(messages[0])
                   if token.startswith('LEAN_PATH=')]
    if len(assignments) != 1 or not assignments[0]:
        raise RuntimeError('Actual compiler runtime path missing or ambiguous')
    original_path = assignments[0].split(':')
    if any(not name for name in original_path):
        raise RuntimeError('Implicit empty runtime path needs explicit provenance')
    options = next((entry[1] for entry in trace['inputs'] if entry[0] == 'options'), None)
    if not isinstance(options, list) or any(
            not isinstance(entry, list) or len(entry) != 2 or
            not isinstance(entry[0], str) or not entry[0].startswith('-D') or
            not isinstance(entry[1], str) for entry in options):
        raise RuntimeError('Actual proper compiler option/hash schema differs')
    option_args = [entry[0] for entry in options]
    lean_arg_profiles = [entry for entry in trace['inputs'] if entry[0].startswith('Module.leanArgs:')]
    if len(lean_arg_profiles) != 1 or '--tstack=400000' not in lean_arg_profiles[0][0]:
        raise RuntimeError('Actual proper compilation stack/options profile differs')
    ancestor_ci = {}
    for module in PLAN['source_sha256']:
        relative = Path(module.replace('.', '/'))
        obj = proper / '.lake/build/lib/lean' / relative.with_suffix('.olean')
        meta = proper / '.lake/build/lib/lean' / relative.with_suffix('.trace')
        facts = json.loads(meta.read_text())
        ancestor_ci[module] = {'olean_sha256': sha(obj), 'trace_sha256': sha(meta),
                               'depHash': facts['depHash']}
    namespace_status = []
    for name in original_path:
        origin = Path(name)
        if not origin.is_absolute():
            raise RuntimeError('Relative trace path needs actual compiler cwd provenance; do not guess')
        if origin.exists() and not origin.is_dir():
            raise RuntimeError('Compiler namespace is not a directory: ' + name)
        namespace_status.append({'trace_path': name, 'canonical': str(origin.resolve()),
                                 'state': 'directory' if origin.is_dir() else 'absent'})
    module_commands = {}
    module_setups = {}
    setup_provenance = {}
    for module in PLAN['minimal_order']:
        relative = Path(module.replace('.', '/'))
        normal_trace_path = proper / '.lake/build/lib/lean' / relative.with_suffix('.trace')
        normal_trace = json.loads(normal_trace_path.read_text())
        normal_message = next(entry['message'] for entry in normal_trace['log']
                              if 'LEAN_PATH=' in entry.get('message', ''))
        tokens = shlex.split(normal_message)
        command = tokens[tokens.index(PLAN['compiler']):]
        source_argument = str(proper / relative.with_suffix('.lean'))
        if command.count(source_argument) != 1:
            raise RuntimeError('Normal compiler source argument ambiguous: ' + module)
        if any(command.count(flag) != 1 for flag in ['-o', '-i', '-c', '--setup', '--json']):
            raise RuntimeError('Actual normal compiler argument layout differs: ' + module)
        setup_path = Path(command[command.index('--setup') + 1])
        setup = json.loads(setup_path.read_text())
        if setup['name'] != module or not isinstance(setup['importArts'], dict):
            raise RuntimeError('Actual normal setup module/import schema differs')
        module_commands[module] = command
        module_setups[module] = setup
        setup_provenance[module] = {'actual_argv': command,
                                    'trace_sha256': sha(normal_trace_path),
                                    'setup_path': str(setup_path),
                                    'setup_sha256': sha(setup_path)}
    baseline_profile = {'proper_source': actual_head, 'source_sha256': PLAN['source_sha256'],
                        'compiler_sha256': PLAN['compiler_sha256'], 'LEAN_PATH': original_path,
                        'options': options, 'leanArgs': lean_arg_profiles,
                        'necessary_proper_ancestor_ci': ancestor_ci,
                        'namespace_status': namespace_status,
                        'actual_module_setup_profiles': setup_provenance}
    if args.case != 'normal' and baseline_profile != normal['proper_profile']:
        raise RuntimeError('Proper source/compiler/options/dependency artifacts differ from fresh control')
    namespaces = []
    excluded = set(PLAN['exclude_everywhere'])
    owned = case / 'owned-proof-objects'
    owned.mkdir()
    # Lean resolves a top-level module prefix to its first namespace root.
    # Fresh ZiskFv outputs must therefore share that root with readonly,
    # unaffected ZiskFv leaves; separate fallback roots cannot fill its holes.
    mirror_namespace(proper / '.lake/build/lib/lean', owned, excluded,
                     only_roots={'ZiskFv'})
    for index, facts in enumerate(namespace_status):
        origin = Path(facts['trace_path'])
        destination = case / 'readonly-namespaces' / str(index)
        if facts['state'] == 'absent':
            # Lake records unused package paths too. An absent search entry
            # contributes no files, exactly like this explicit empty namespace.
            destination.mkdir(parents=True)
        else:
            mirror_namespace(origin, destination, excluded)
        namespaces.append(str(destination))
    environment = dict(os.environ, LEAN_PATH=':'.join([str(owned), *namespaces]),
                       LEAN_NUM_THREADS='1', TMPDIR='/tmp')
    results = []
    status = None
    for number, module in enumerate(PLAN['minimal_order']):
        relative = Path(module.replace('.', '/'))
        source = sources / relative.with_suffix('.lean')
        original = (proper / relative.with_suffix('.lean')).read_text()
        expected = original
        if args.case != 'normal' and module == PLAN['mutation_root']:
            mutation = PLAN['model_edits'][args.case]
            if original.count(mutation['old']) != 1:
                raise RuntimeError('Reviewed single source mutation is not unique')
            expected = original.replace(mutation['old'], mutation['new'], 1)
        if source.read_text() != expected:
            raise RuntimeError('Prepared source fixture is not the exact reviewed control/mutant')
        output = owned / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        if list(output.parent.glob(output.name + '.*')):
            raise RuntimeError('Affected output or sidecar unexpectedly exists')
        setup = dict(module_setups[module])
        setup['importArts'] = dict(setup['importArts'])
        rewritten_imports = {}
        for dependency, artifacts in setup['importArts'].items():
            if dependency not in excluded:
                continue
            if dependency not in PLAN['minimal_order'][:number]:
                raise RuntimeError('Affected setup import is not a fresh predecessor: ' + dependency)
            fresh_base = owned / Path(dependency.replace('.', '/'))
            original_stem = dependency.rsplit('.', 1)[-1]
            fresh_artifacts = []
            for artifact in artifacts:
                name = Path(artifact).name
                if not name.startswith(original_stem + '.'):
                    raise RuntimeError('Affected setup artifact stem differs: ' + artifact)
                fresh = fresh_base.parent / (fresh_base.name + name[len(original_stem):])
                if fresh.is_symlink() or not fresh.is_file():
                    raise RuntimeError('Fresh affected setup artifact absent: ' + str(fresh))
                fresh_artifacts.append(str(fresh))
            setup['importArts'][dependency] = fresh_artifacts
            rewritten_imports[dependency] = fresh_artifacts
        setup_path = case / 'actual-normal-setups' / (module + '.setup.json')
        setup_path.parent.mkdir(exist_ok=True)
        setup_path.write_text(json.dumps(setup, indent=2) + '\n')
        command = list(module_commands[module])
        command[command.index(str(proper / relative.with_suffix('.lean')))] = str(source)
        for flag, destination in [('-o', output.with_suffix('.olean')),
                                  ('-i', output.with_suffix('.ilean')),
                                  ('-c', output.with_suffix('.c')),
                                  ('--setup', setup_path)]:
            command[command.index(flag) + 1] = str(destination)
        sandbox = ['/usr/bin/bwrap', '--ro-bind', '/', '/', '--bind', str(case), str(case),
                   '--ro-bind', str(sources), str(sources), '--proc', '/proc', '--dev', '/dev',
                   '--chdir', str(sources), '--', *command]
        log = case / (module + '.log')
        with log.open('w') as stream:
            stream.write(json.dumps({'command': command, 'source_sha256': sha(source)}) + '\n')
            stream.flush()
            result = subprocess.run(sandbox, cwd=sources, env=environment, stdout=stream,
                                    stderr=subprocess.STDOUT)
        record = {'module': module, 'compiler_exit': result.returncode, 'log': str(log),
                  'source_sha256': sha(source), 'actual_replay_command': command,
                  'setup_sha256': sha(setup_path),
                  'affected_setup_imports_rewritten': rewritten_imports}
        results.append(record)
        if result.returncode:
            text = log.read_text()
            diagnostic_matches = list(re.finditer(r':(\d+):(\d+): error:([^\n]*)', text))
            diagnostics = [{'line': int(item.group(1)), 'column': int(item.group(2)),
                            'message': item.group(3).strip(),
                            'declaration': declaration_at(expected, int(item.group(1)))}
                           for item in diagnostic_matches]
            for line in text.splitlines():
                try:
                    diagnostic = json.loads(line)
                except ValueError:
                    continue
                if not isinstance(diagnostic, dict) or diagnostic.get('severity') != 'error':
                    continue
                position = diagnostic.get('pos', {})
                if not isinstance(position.get('line'), int):
                    continue
                message = diagnostic.get('data', diagnostic.get('message', ''))
                if not isinstance(message, str):
                    message = json.dumps(message)
                diagnostics.append({'line': position['line'],
                                    'column': position.get('column'),
                                    'message': message,
                                    'declaration': declaration_at(expected, position['line']),
                                    'actual_json_diagnostic': diagnostic})
            record['actual_diagnostics'] = diagnostics
            lowered = text.lower()
            setup_terms = ['object file', 'unknown module prefix', 'could not execute',
                           'permission denied', 'no such file or directory']
            resource_terms = ['heartbeat', 'deterministic timeout', 'timeout', 'time limit',
                              'maxrecdepth', 'maximum recursion', 'recursion depth',
                              'recursion limit', 'deep recursion', 'stack overflow',
                              'stack space', 'stack limit', 'stack exhausted',
                              'out of memory', 'memory limit', 'maximum memory',
                              'cannot allocate memory', 'failed to create thread',
                              'thread creation failed', 'too many threads', 'pthread',
                              'resource limit', 'resource temporarily unavailable',
                              'pids', 'task limit', 'too many processes',
                              'sigkill', 'sigterm']
            record['non_kill_failure_reasons'] = [
                term for term in [*setup_terms, *resource_terms] if term in lowered]
            if result.returncode < 0:
                record['non_kill_failure_reasons'].append(
                    'compiler terminated by signal ' + str(-result.returncode))
            if result.returncode >= 128:
                record['non_kill_failure_reasons'].append(
                    'signal-style compiler exit status ' + str(result.returncode))
            setup = bool(record['non_kill_failure_reasons'])
            typed_reject = any(item['declaration'] and any(word in item['message'].lower()
                               for word in ['unsolved goals', 'type mismatch', 'tactic', 'rfl'])
                               for item in diagnostics)
            status = ('FAILED_NORMAL_CONTROL' if args.case == 'normal' else
                      'SETUP_OR_RESOURCE_NOT_A_KILL' if setup or not typed_reject else
                      'REJECT_MODEL_PROVIDER_BOUNDARY')
            record['downstream_blocked_not_kills'] = PLAN['minimal_order'][number + 1:]
            break
    if status is None:
        status = ('PASS_FRESH_NORMAL_COMPOSITION_CONTROL' if args.case == 'normal' else
                  'SURVIVED_MODEL_PROVIDER_MUTATION')
    report = {'case': args.case, 'status': status, 'proper_profile': baseline_profile,
              'actual_cgroup': group, 'limits': expected_limits, 'results': results,
              'excluded_all_searchpath_affected_modules': PLAN['exclude_everywhere'],
              'claim': 'MODEL provider-roster sensitivity only; NOT upstream source/PIL kill, '
                       'native commitment identity, extra closure assumption or whole415 closure'}
    (case / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'case': args.case, 'status': status,
                      'report': str(case / 'result.json')}))
    return 0 if status in {'PASS_FRESH_NORMAL_COMPOSITION_CONTROL',
                          'REJECT_MODEL_PROVIDER_BOUNDARY'} else 1

if __name__ == '__main__':
    raise SystemExit(main())
