import ZiskFv.AirsClean.FullEnsemble.Balance.BinaryTableProviderMatch
import ZiskFv.AirsClean.FullEnsemble
import ZiskFv.AirsClean.ArithTableProjections
import ZiskFv.AirsClean.Binary.Bridge
import ZiskFv.AirsClean.BinaryAdd.Bridge
import ZiskFv.AirsClean.BinaryExtension.Bridge
import ZiskFv.AirsClean.Mem.Bridge
import ZiskFv.AirsClean.Mem.TraceSpec
import ZiskFv.AirsClean.FullEnsemble.Balance.Classification
import ZiskFv.AirsClean.FullEnsemble.Balance.CounterpartClassification
import ZiskFv.AirsClean.FullEnsemble.Balance.RowExtraction

namespace ZiskFv.AirsClean.FullEnsemble

open Goldilocks
open Air.Flat
open ZiskFv.Channels.OperationBus (OpBusChannel)
open ZiskFv.Channels.MemoryBus (MemBusChannel)
open ZiskFv.AirsClean.ZiskInstructionRom (Program)
open ZiskFv.AirsClean.BinaryExtension (shiftTableConsumerComponent)

/-! ## Full-ensemble operation-bus row bridges -/

/-- Resolve any active operation-bus consumer interaction to a concrete
    provider row carrying its full semantic facts.  The interaction need not come
    from Main; in particular, ArithMul's remainder-bound consumer uses this
    bridge. -/
theorem exists_op_provider_row_msg_eq_spec_of_active_interaction
    {length : ℕ} {program : Program length}
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {consumerInteraction : Interaction FGL}
    (h_consumer :
      consumerInteraction ∈ witness.interactionsWith OpBusChannel.toRaw)
    (h_active : consumerInteraction.mult = -1) :
    ∃ providerInteraction ∈ witness.interactionsWith OpBusChannel.toRaw,
      providerInteraction.msg = consumerInteraction.msg
        ∧ providerInteraction.mult ≠ -1
        ∧ providerInteraction.mult ≠ 0
        ∧ ∃ providerTable ∈ witness.allTables,
          providerInteraction ∈ providerTable.interactionsWith OpBusChannel.toRaw
            ∧
            ((∃ providerRow ∈ providerTable.table,
                providerTable.component.Spec (providerTable.environment providerRow)
                  ∧ providerTable.component = arithMulProviderComponent
                  ∧ providerInteraction =
                    ((OpBusChannel.pushed
                      (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                        arithMulProviderComponent.rowInputVar)).toRaw).eval
                      (providerTable.environment providerRow))
              ∨ (∃ providerRow ∈ providerTable.table,
                (ZiskFv.AirsClean.BinaryExtension.Spec
                    (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                      (providerTable.environment providerRow)) ∧
                  ZiskFv.AirsClean.BinaryExtension.StaticBinaryExtensionTableSpecFacts
                    (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                      (providerTable.environment providerRow)) ∧
                  ZiskFv.AirsClean.BinaryExtension.ShiftB0RangeSpecFact
                    (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                      (providerTable.environment providerRow)))
                  ∧ providerTable.component = shiftTableConsumerComponent
                  ∧ providerInteraction =
                    ((OpBusChannel.pushed
                      (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                        shiftTableConsumerComponent.rowInputVar)).toRaw).eval
                      (providerTable.environment providerRow))
              ∨ (∃ providerRow ∈ providerTable.table,
                (ZiskFv.AirsClean.Binary.Spec
                    (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                      (providerTable.environment providerRow)) ∧
                  ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
                    (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                      (providerTable.environment providerRow)))
                  ∧ providerTable.component =
                    ZiskFv.AirsClean.Binary.tableConsumerComponent
                  ∧ providerInteraction =
                    ((OpBusChannel.pushed
                      (ZiskFv.AirsClean.Binary.opBusMessageExpr
                        ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)).toRaw).eval
                      (providerTable.environment providerRow))
              ∨ (∃ providerRow ∈ providerTable.table,
                providerTable.component.Spec (providerTable.environment providerRow)
                  ∧ providerTable.component = ZiskFv.AirsClean.BinaryAdd.component
                  ∧ providerInteraction =
                    ((OpBusChannel.pushed
                      (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                        ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)).toRaw).eval
                      (providerTable.environment providerRow))) := by
  obtain ⟨providerInteraction, h_provider_witness, h_msg, h_nonpull, h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerComponent⟩ :=
    exists_matching_provider_op_component_of_active_main_interaction
      witness h_constraints h_balanced h_consumer h_active
  refine ⟨providerInteraction, h_provider_witness, h_msg, h_nonpull, h_nonzero,
    providerTable, h_providerTable, h_providerInteraction, ?_⟩
  have h_providerSpecs : providerTable.Spec :=
    h_specs providerTable h_providerTable
  rcases h_providerComponent with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · rcases exists_arithMul_row_eval_of_interaction_mem
        h_arithMul h_providerInteraction with
      ⟨providerRow, h_providerRow, h_providerEval⟩
      | ⟨providerRow, h_providerRow, h_providerEval⟩
    · left
      exact ⟨providerRow, h_providerRow,
        h_providerSpecs providerRow h_providerRow, h_arithMul, h_providerEval⟩
    · rw [h_providerEval] at h_nonpull h_nonzero
      have h_divBlock' :=
        arithMul_sharedDivBlockSpec_of_component_spec h_arithMul
          (h_providerSpecs providerRow h_providerRow)
      have h_row_eq :
          eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar =
            arithMulProviderComponent.rowInput
              (providerTable.environment providerRow) := by
        simpa only [Component.rowInput, Component.rowInputVar] using
          (eval_varFromOffset_valueFromOffset arithMulProviderComponent.Input 0
            (providerTable.environment providerRow))
      have h_divBlock :
          ZiskFv.AirsClean.ArithMul.SharedDivBlockSpec
            (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar) := by
        rw [h_row_eq]
        exact h_divBlock'
      have h_div_bool := h_divBlock.1.2.2.2.2.2.2.1
      have h_div_zero_bool := h_divBlock.1.2.2.2.2.1
      have h_div :
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div = 0
            ∨
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div = 1 := by
        rcases mul_eq_zero.mp h_div_bool with h | h
        · exact Or.inl h
        · exact Or.inr (sub_eq_zero.mp h).symm
      have h_div_zero :
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div_by_zero = 0
            ∨
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div_by_zero = 1 := by
        rcases mul_eq_zero.mp h_div_zero_bool with h | h
        · exact Or.inl h
        · exact Or.inr (sub_eq_zero.mp h).symm
      rw [ZiskFv.AirsClean.ArithMul.eval_remainderBoundInteraction_mult]
        at h_nonpull h_nonzero
      rcases h_div with h_div | h_div <;>
        rcases h_div_zero with h_div_zero | h_div_zero
      · exact False.elim (h_nonzero (by simp [h_div, h_div_zero]))
      · exact False.elim (h_nonzero (by simp [h_div, h_div_zero]))
      · exact False.elim (h_nonpull (by simp [h_div, h_div_zero]))
      · exact False.elim (h_nonzero (by simp [h_div, h_div_zero]))
  · obtain ⟨providerRow, h_providerRow, h_providerEval⟩ :=
      exists_staticBinaryExtension_row_eval_of_interaction_mem
        h_binExt h_providerInteraction
    right
    left
    exact ⟨providerRow, h_providerRow,
      (extension_table_full_spec_of_accepted witness h_constraints h_balanced
          h_providerTable h_binExt) providerRow h_providerRow, h_binExt, h_providerEval⟩
  · obtain ⟨providerRow, h_providerRow, h_providerEval⟩ :=
      exists_staticBinary_row_eval_of_interaction_mem
        h_binary h_providerInteraction
    right
    right
    left
    exact ⟨providerRow, h_providerRow,
      (binary_table_full_spec_of_accepted witness h_constraints h_balanced
          h_providerTable h_binary) providerRow h_providerRow, h_binary, h_providerEval⟩
  · obtain ⟨providerRow, h_providerRow, h_providerEval⟩ :=
      exists_binaryAdd_row_eval_of_interaction_mem
        h_binaryAdd h_providerInteraction
    right
    right
    right
    exact ⟨providerRow, h_providerRow,
      h_providerSpecs providerRow h_providerRow, h_binaryAdd, h_providerEval⟩

/-- Seal opcode refutation at an abstract row: concrete component projections
are only compared once, when the accepted facts and message equality enter. -/
private theorem extension_remainder_bound_contradiction
    (row : ZiskFv.AirsClean.BinaryExtension.BinaryExtensionRow FGL)
    (h_facts : ZiskFv.AirsClean.BinaryExtension.StaticBinaryExtensionTableSpecFacts row)
    (op : Nat)
    (h_op : op = 6 ∨ op = 80 ∨ op = 81 ∨ op = 8)
    (h_eq : op = row.flags.op.val) :
    False := by
  have h_ne :=
    ZiskFv.AirsClean.BinaryExtension.static_table_op_val_ne_arith_div_remainder_bound_of_spec_facts
      row h_facts
  rw [h_eq] at h_op
  rcases h_op with h | h | h | h
  · exact h_ne.1 h
  · exact h_ne.2.1 h
  · exact h_ne.2.2.1 h
  · exact h_ne.2.2.2 h

set_option maxHeartbeats 8000000 in
set_option maxRecDepth 4096 in
/-- A live comparison request used by ArithDiv's remainder-bound check is
    served by the actual Binary consumer table.  The other three provider families are
    excluded by their checked opcode ranges. -/
theorem exists_staticBinary_provider_of_active_remainder_bound_interaction
    {length : ℕ} {program : Program length}
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {consumerInteraction : Interaction FGL}
    (h_consumer :
      consumerInteraction ∈ witness.interactionsWith OpBusChannel.toRaw)
    (h_active : consumerInteraction.mult = -1)
    {consumerMsg : ZiskFv.Channels.OperationBus.OpBusMessage (Expression FGL)}
    {consumerMult : Expression FGL} {consumerEnv : Environment FGL}
    (h_consumerEval :
      consumerInteraction =
        ((OpBusChannel.emitted consumerMult consumerMsg).toRaw).eval consumerEnv)
    (h_op :
      (eval consumerEnv consumerMsg).op.val = 6
        ∨ (eval consumerEnv consumerMsg).op.val = 80
        ∨ (eval consumerEnv consumerMsg).op.val = 81
        ∨ (eval consumerEnv consumerMsg).op.val = 8) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        (ZiskFv.AirsClean.Binary.Spec
            (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
              (providerTable.environment providerRow)) ∧
          ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
            (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
              (providerTable.environment providerRow)))
          ∧ providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (eval consumerEnv consumerMsg) 1)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (eval (providerTable.environment providerRow)
                (ZiskFv.AirsClean.Binary.opBusMessageExpr
                  ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
  obtain ⟨providerInteraction, _, h_msg, _, _, providerTable, h_providerTable,
      _, h_provider⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_interaction
      witness h_constraints h_balanced h_specs h_consumer h_active
  rcases h_provider with h_arith | h_extension | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _, h_providerSpec, h_component, h_providerEval⟩ := h_arith
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval consumerEnv consumerMsg) 1)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_consumerEval]
      exact h_msg
    have h_full := arithMul_fullSpec_of_component_spec h_component h_providerSpec
    let env := providerTable.environment providerRow
    let row := eval env arithMulProviderComponent.rowInputVar
    have h_row_eq : row = arithMulProviderComponent.rowInput env := by
      dsimp [row]
      simpa only [Component.rowInput, Component.rowInputVar] using
        (eval_varFromOffset_valueFromOffset arithMulProviderComponent.Input 0 env)
    have h_full_row : ZiskFv.AirsClean.ArithMul.FullSpec row := by
      simpa [h_row_eq] using h_full
    have h_ge : 176 ≤ row.flags.op.val :=
      ZiskFv.AirsClean.ArithTableProjections.Mul.op_val_ge_176 row h_full_row.2.1
    have h_op_eq :
        (eval consumerEnv consumerMsg).op.val = row.flags.op.val := by
      have hm := h_match.2.1
      rw [ZiskFv.AirsClean.ArithMul.eval_primaryOpBusMessageExpr_toEntry_op] at hm
      exact congrArg Fin.val hm
    rw [h_op_eq] at h_op
    rcases h_op with h | h | h | h <;> omega
  · obtain ⟨providerRow, _, h_providerSpec, h_component, h_providerEval⟩ := h_extension
    let env := providerTable.environment providerRow
    have h_tableFacts := h_providerSpec.2.1
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval consumerEnv consumerMsg) 1)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval env (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
              shiftTableConsumerComponent.rowInputVar)) 1) := by
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_consumerEval]
      exact h_msg
    have h_op_eq :
        (eval consumerEnv consumerMsg).op.val =
          (shiftTableConsumerComponent.rowInput env).flags.op.val := by
      have hm := h_match.2.1
      change (eval consumerEnv consumerMsg).op =
        (eval env (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
          shiftTableConsumerComponent.rowInputVar)).op at hm
      simpa only [ZiskFv.AirsClean.BinaryExtension.eval_opBusMessageExpr,
        ZiskFv.AirsClean.BinaryExtension.opBusMessage,
        Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using congrArg Fin.val hm
    dsimp only [env] at h_op_eq
    exact False.elim
      (extension_remainder_bound_contradiction
        (shiftTableConsumerComponent.rowInput (providerTable.environment providerRow))
        h_tableFacts (eval consumerEnv consumerMsg).op.val h_op h_op_eq)
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_component,
        h_providerEval⟩ := h_binary
    refine ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_providerSpec, h_component, ?_⟩
    apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
    rw [← h_providerEval, ← h_consumerEval]
    exact h_msg
  · obtain ⟨providerRow, _, _, _, h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval consumerEnv consumerMsg) 1)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_consumerEval]
      exact h_msg
    have h_ten : (eval consumerEnv consumerMsg).op.val = 10 := by
      have hm := congrArg Fin.val h_match.2.1
      simpa [ZiskFv.Channels.OperationBus.OpBusMessage.eval_op] using hm
    rcases h_op with h | h | h | h <;> omega

/-- Spec-carrying full-ensemble operation-bus projection: an active
    unified-Main operation-bus interaction has a balanced same-message
    provider counterpart, and the Binary-family provider branches are
    resolved to actual consumer rows carrying core and all eight table facts
    derived from accepted constraints and finished-channel balance.
    The ArithMul provider branch is also resolved to a concrete row. -/
theorem exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
    {length : ℕ} {program : Program length}
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_active : mainInteraction.mult = -1) :
    ∃ mainRow ∈ mainTable.table,
      mainTable.component.Spec (mainTable.environment mainRow)
        ∧ mainInteraction =
          ((OpBusChannel.emitted
            (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                length program).rowInputVar.core.is_external_op)
            (ZiskFv.AirsClean.Main.opBusMessageExpr
              (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                length program).rowInputVar.core)).toRaw).eval
            (mainTable.environment mainRow)
        ∧ ∃ providerInteraction ∈ witness.interactionsWith OpBusChannel.toRaw,
          providerInteraction.msg = mainInteraction.msg
            ∧ providerInteraction.mult ≠ -1
            ∧ providerInteraction.mult ≠ 0
            ∧ ∃ providerTable ∈ witness.allTables,
              providerInteraction ∈ providerTable.interactionsWith OpBusChannel.toRaw
                ∧
                ((∃ providerRow ∈ providerTable.table,
                    providerTable.component.Spec (providerTable.environment providerRow)
                      ∧ providerTable.component = arithMulProviderComponent
                      ∧ providerInteraction =
                        ((OpBusChannel.pushed
                          (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                            arithMulProviderComponent.rowInputVar)).toRaw).eval
                          (providerTable.environment providerRow))
                  ∨ (∃ providerRow ∈ providerTable.table,
                    (ZiskFv.AirsClean.BinaryExtension.Spec
                        (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                          (providerTable.environment providerRow)) ∧
                      ZiskFv.AirsClean.BinaryExtension.StaticBinaryExtensionTableSpecFacts
                        (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                          (providerTable.environment providerRow)) ∧
                      ZiskFv.AirsClean.BinaryExtension.ShiftB0RangeSpecFact
                        (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                          (providerTable.environment providerRow)))
                      ∧ providerTable.component =
                        shiftTableConsumerComponent
                      ∧ providerInteraction =
                        ((OpBusChannel.pushed
                          (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                            shiftTableConsumerComponent.rowInputVar)).toRaw).eval
                          (providerTable.environment providerRow))
                  ∨ (∃ providerRow ∈ providerTable.table,
                    (ZiskFv.AirsClean.Binary.Spec
                        (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                          (providerTable.environment providerRow)) ∧
                      ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
                        (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                          (providerTable.environment providerRow)))
                      ∧ providerTable.component =
                        ZiskFv.AirsClean.Binary.tableConsumerComponent
                      ∧ providerInteraction =
                        ((OpBusChannel.pushed
                          (ZiskFv.AirsClean.Binary.opBusMessageExpr
                            ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)).toRaw).eval
                          (providerTable.environment providerRow))
                  ∨ (∃ providerRow ∈ providerTable.table,
                    providerTable.component.Spec (providerTable.environment providerRow)
                      ∧ providerTable.component = ZiskFv.AirsClean.BinaryAdd.component
                      ∧ providerInteraction =
                        ((OpBusChannel.pushed
                          (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                            ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)).toRaw).eval
                          (providerTable.environment providerRow))) := by
  have h_main_witness :
      mainInteraction ∈ witness.interactionsWith OpBusChannel.toRaw := by
    rw [EnsembleWitness.mem_interactionsWith]
    exact ⟨mainTable, h_mainTable, h_mainInteraction⟩
  obtain ⟨mainRow, h_mainRow, h_mainEval⟩ :=
    exists_main_op_row_eval_of_interaction_mem h_mainComponent h_mainInteraction
  obtain ⟨providerInteraction, h_provider_witness, h_msg, h_nonpull, h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerComponent⟩ :=
    exists_matching_provider_op_component_of_active_main_interaction
      witness h_constraints h_balanced h_main_witness h_active
  have h_mainSpec :
      mainTable.component.Spec (mainTable.environment mainRow) :=
    h_specs mainTable h_mainTable mainRow h_mainRow
  refine ⟨mainRow, h_mainRow, h_mainSpec, h_mainEval, providerInteraction,
    h_provider_witness, h_msg, h_nonpull, h_nonzero, providerTable,
    h_providerTable, h_providerInteraction, ?_⟩
  have h_providerSpecs : providerTable.Spec :=
    h_specs providerTable h_providerTable
  rcases h_providerComponent with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · rcases exists_arithMul_row_eval_of_interaction_mem
        h_arithMul h_providerInteraction with
      ⟨providerRow, h_providerRow, h_providerEval⟩
      | ⟨providerRow, h_providerRow, h_providerEval⟩
    · left
      exact ⟨providerRow, h_providerRow,
        h_providerSpecs providerRow h_providerRow, h_arithMul, h_providerEval⟩
    ·
      have h_divBlock' :=
        arithMul_sharedDivBlockSpec_of_component_spec h_arithMul
          (h_providerSpecs providerRow h_providerRow)
      have h_row_eq :
          eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar =
            arithMulProviderComponent.rowInput
              (providerTable.environment providerRow) := by
        simpa only [Component.rowInput, Component.rowInputVar] using
          (eval_varFromOffset_valueFromOffset arithMulProviderComponent.Input 0
            (providerTable.environment providerRow))
      have h_divBlock :
          ZiskFv.AirsClean.ArithMul.SharedDivBlockSpec
            (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar) := by
        rw [h_row_eq]
        exact h_divBlock'
      have h_div_bool := h_divBlock.1.2.2.2.2.2.2.1
      have h_div_zero_bool := h_divBlock.1.2.2.2.2.1
      have h_div :
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div = 0
            ∨
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div = 1 := by
        rcases mul_eq_zero.mp h_div_bool with h | h
        · exact Or.inl h
        · exact Or.inr (sub_eq_zero.mp h).symm
      have h_div_zero :
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div_by_zero = 0
            ∨
          (eval (providerTable.environment providerRow)
              arithMulProviderComponent.rowInputVar).flags.div_by_zero = 1 := by
        rcases mul_eq_zero.mp h_div_zero_bool with h | h
        · exact Or.inl h
        · exact Or.inr (sub_eq_zero.mp h).symm
      rw [h_providerEval] at h_nonpull h_nonzero
      rw [ZiskFv.AirsClean.ArithMul.eval_remainderBoundInteraction_mult]
        at h_nonpull h_nonzero
      rcases h_div with h_div | h_div <;>
        rcases h_div_zero with h_div_zero | h_div_zero
      · exact False.elim (h_nonzero (by simp [h_div, h_div_zero]))
      · exact False.elim (h_nonzero (by simp [h_div, h_div_zero]))
      · exact False.elim (h_nonpull (by simp [h_div, h_div_zero]))
      · exact False.elim (h_nonzero (by simp [h_div, h_div_zero]))
  · obtain ⟨providerRow, h_providerRow, h_providerEval⟩ :=
      exists_staticBinaryExtension_row_eval_of_interaction_mem
        h_binExt h_providerInteraction
    right
    left
    exact ⟨providerRow, h_providerRow,
      (extension_table_full_spec_of_accepted witness h_constraints h_balanced
          h_providerTable h_binExt) providerRow h_providerRow, h_binExt, h_providerEval⟩
  · obtain ⟨providerRow, h_providerRow, h_providerEval⟩ :=
      exists_staticBinary_row_eval_of_interaction_mem
        h_binary h_providerInteraction
    right
    right
    left
    exact ⟨providerRow, h_providerRow,
      (binary_table_full_spec_of_accepted witness h_constraints h_balanced
          h_providerTable h_binary) providerRow h_providerRow, h_binary, h_providerEval⟩
  · obtain ⟨providerRow, h_providerRow, h_providerEval⟩ :=
      exists_binaryAdd_row_eval_of_interaction_mem
        h_binaryAdd h_providerInteraction
    right
    right
    right
    exact ⟨providerRow, h_providerRow,
      h_providerSpecs providerRow h_providerRow, h_binaryAdd, h_providerEval⟩

/-- Legacy-entry view of the full-ensemble operation-bus bridge.

    Clean balance proves equality of raw operation-bus message arrays.  This
    adapter keeps the full-ensemble provider row/spec information while
    translating each provider branch into the `OperationBus.matches_entry`
    shape consumed by the existing opcode proofs. -/
theorem exists_op_provider_row_matches_entry_spec_of_active_main_table_interaction
    {length : ℕ} {program : Program length}
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_active : mainInteraction.mult = -1) :
    ∃ mainRow ∈ mainTable.table,
      mainTable.component.Spec (mainTable.environment mainRow)
        ∧ mainInteraction =
          ((OpBusChannel.emitted
            (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                length program).rowInputVar.core.is_external_op)
            (ZiskFv.AirsClean.Main.opBusMessageExpr
              (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                length program).rowInputVar.core)).toRaw).eval
            (mainTable.environment mainRow)
        ∧ ∃ providerInteraction ∈ witness.interactionsWith OpBusChannel.toRaw,
          providerInteraction.msg = mainInteraction.msg
            ∧ providerInteraction.mult ≠ -1
            ∧ providerInteraction.mult ≠ 0
            ∧ ∃ providerTable ∈ witness.allTables,
              providerInteraction ∈ providerTable.interactionsWith OpBusChannel.toRaw
                ∧
                ((∃ providerRow ∈ providerTable.table,
                    providerTable.component.Spec (providerTable.environment providerRow)
                      ∧ providerTable.component = arithMulProviderComponent
                      ∧ ZiskFv.Airs.OperationBus.matches_entry
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (mainTable.environment mainRow)
                            (ZiskFv.AirsClean.Main.opBusMessageExpr
                              (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                                length program).rowInputVar.core)) 1)
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (providerTable.environment providerRow)
                            (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                              arithMulProviderComponent.rowInputVar)) 1))
                  ∨ (∃ providerRow ∈ providerTable.table,
                    (ZiskFv.AirsClean.BinaryExtension.Spec
                        (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                          (providerTable.environment providerRow)) ∧
                      ZiskFv.AirsClean.BinaryExtension.StaticBinaryExtensionTableSpecFacts
                        (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                          (providerTable.environment providerRow)) ∧
                      ZiskFv.AirsClean.BinaryExtension.ShiftB0RangeSpecFact
                        (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                          (providerTable.environment providerRow)))
                      ∧ providerTable.component =
                        shiftTableConsumerComponent
                      ∧ ZiskFv.Airs.OperationBus.matches_entry
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (mainTable.environment mainRow)
                            (ZiskFv.AirsClean.Main.opBusMessageExpr
                              (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                                length program).rowInputVar.core)) 1)
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (providerTable.environment providerRow)
                            (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                              shiftTableConsumerComponent.rowInputVar)) 1))
                  ∨ (∃ providerRow ∈ providerTable.table,
                    (ZiskFv.AirsClean.Binary.Spec
                        (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                          (providerTable.environment providerRow)) ∧
                      ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
                        (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                          (providerTable.environment providerRow)))
                      ∧ providerTable.component =
                        ZiskFv.AirsClean.Binary.tableConsumerComponent
                      ∧ ZiskFv.Airs.OperationBus.matches_entry
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (mainTable.environment mainRow)
                            (ZiskFv.AirsClean.Main.opBusMessageExpr
                              (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                                length program).rowInputVar.core)) 1)
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (providerTable.environment providerRow)
                            (ZiskFv.AirsClean.Binary.opBusMessageExpr
                              ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1))
                  ∨ (∃ providerRow ∈ providerTable.table,
                    providerTable.component.Spec (providerTable.environment providerRow)
                      ∧ providerTable.component = ZiskFv.AirsClean.BinaryAdd.component
                      ∧ ZiskFv.Airs.OperationBus.matches_entry
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (mainTable.environment mainRow)
                            (ZiskFv.AirsClean.Main.opBusMessageExpr
                              (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
                                length program).rowInputVar.core)) 1)
                        (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                          (eval (providerTable.environment providerRow)
                            (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                              ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1))) := by
  obtain ⟨mainRow, h_mainRow, h_mainSpec, h_mainEval, providerInteraction,
      h_provider_witness, h_msg, h_nonpull, h_nonzero, providerTable,
      h_providerTable, h_providerInteraction, h_providerBranch⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  refine ⟨mainRow, h_mainRow, h_mainSpec, h_mainEval, providerInteraction,
    h_provider_witness, h_msg, h_nonpull, h_nonzero, providerTable,
    h_providerTable, h_providerInteraction, ?_⟩
  rcases h_providerBranch with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_providerEval⟩ := h_arithMul
    left
    refine ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent, ?_⟩
    apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
    rw [← h_providerEval, ← h_mainEval]
    exact h_msg
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_providerEval⟩ := h_binExt
    right
    left
    refine ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent, ?_⟩
    apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
    rw [← h_providerEval, ← h_mainEval]
    exact h_msg
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_providerEval⟩ := h_binary
    right
    right
    left
    refine ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent, ?_⟩
    apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
    rw [← h_providerEval, ← h_mainEval]
    exact h_msg
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_providerEval⟩ := h_binaryAdd
    right
    right
    right
    refine ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent, ?_⟩
    apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
    rw [← h_providerEval, ← h_mainEval]
    exact h_msg

/-- Legacy-Main view of the full-ensemble operation-bus bridge.

    This specializes the selected unified Clean Main row back to the existing
    `Valid_Main` row used by opcode proofs.  It deliberately preserves all
    full-ensemble provider alternatives: later opcode-specific adapters may
    rule out branches only from provider-local facts, not by caller promise. -/
theorem exists_op_provider_row_matches_legacy_main_spec_of_active_main_table_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    (h_main_row :
      ∀ mainRow ∈ mainTable.table,
        eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
            length program).rowInputVar.core =
          ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_active : mainInteraction.mult = -1) :
    ∃ providerInteraction ∈ witness.interactionsWith OpBusChannel.toRaw,
      providerInteraction.msg = mainInteraction.msg
        ∧ providerInteraction.mult ≠ -1
        ∧ providerInteraction.mult ≠ 0
        ∧ ∃ providerTable ∈ witness.allTables,
          providerInteraction ∈ providerTable.interactionsWith OpBusChannel.toRaw
            ∧
            ((∃ providerRow ∈ providerTable.table,
                providerTable.component.Spec (providerTable.environment providerRow)
                  ∧ providerTable.component = arithMulProviderComponent
                  ∧ ZiskFv.Airs.OperationBus.matches_entry
                    (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
                    (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                      (eval (providerTable.environment providerRow)
                        (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                          arithMulProviderComponent.rowInputVar)) 1))
              ∨ (∃ providerRow ∈ providerTable.table,
                (ZiskFv.AirsClean.BinaryExtension.Spec
                    (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                      (providerTable.environment providerRow)) ∧
                  ZiskFv.AirsClean.BinaryExtension.StaticBinaryExtensionTableSpecFacts
                    (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                      (providerTable.environment providerRow)) ∧
                  ZiskFv.AirsClean.BinaryExtension.ShiftB0RangeSpecFact
                    (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                      (providerTable.environment providerRow)))
                  ∧ providerTable.component =
                    shiftTableConsumerComponent
                  ∧ ZiskFv.Airs.OperationBus.matches_entry
                    (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
                    (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                      (eval (providerTable.environment providerRow)
                        (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                          shiftTableConsumerComponent.rowInputVar)) 1))
              ∨ (∃ providerRow ∈ providerTable.table,
                (ZiskFv.AirsClean.Binary.Spec
                    (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                      (providerTable.environment providerRow)) ∧
                  ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
                    (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                      (providerTable.environment providerRow)))
                  ∧ providerTable.component =
                    ZiskFv.AirsClean.Binary.tableConsumerComponent
                  ∧ ZiskFv.Airs.OperationBus.matches_entry
                    (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
                    (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                      (eval (providerTable.environment providerRow)
                        (ZiskFv.AirsClean.Binary.opBusMessageExpr
                          ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1))
              ∨ (∃ providerRow ∈ providerTable.table,
                providerTable.component.Spec (providerTable.environment providerRow)
                  ∧ providerTable.component = ZiskFv.AirsClean.BinaryAdd.component
                  ∧ ZiskFv.Airs.OperationBus.matches_entry
                    (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
                    (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
                      (eval (providerTable.environment providerRow)
                        (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                          ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1))) := by
  obtain ⟨mainRow, h_mainRow, _h_mainSpec, _h_mainEval, providerInteraction,
      h_provider_witness, h_msg, h_nonpull, h_nonzero, providerTable,
      h_providerTable, h_providerInteraction, h_providerBranch⟩ :=
    exists_op_provider_row_matches_entry_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row mainRow h_mainRow]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  refine ⟨providerInteraction, h_provider_witness, h_msg, h_nonpull,
    h_nonzero, providerTable, h_providerTable, h_providerInteraction, ?_⟩
  rcases h_providerBranch with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_match⟩ := h_arithMul
    left
    exact ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      by
        rw [← h_main_entry]
        exact h_match⟩
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_match⟩ := h_binExt
    right
    left
    exact ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      by
        rw [← h_main_entry]
        exact h_match⟩
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_match⟩ := h_binary
    right
    right
    left
    exact ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      by
        rw [← h_main_entry]
        exact h_match⟩
  · obtain ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      h_match⟩ := h_binaryAdd
    right
    right
    right
    exact ⟨providerRow, h_providerRow, h_providerSpec, h_providerComponent,
      by
        rw [← h_main_entry]
        exact h_match⟩

/-- XOR specialization of the full-ensemble operation-bus provider bridge.

    For an active legacy Main row whose opcode is `OP_XOR`, balanced operation-bus
    coverage cannot use ArithMul, BinaryExtension, or BinaryAdd.  The remaining
    branch is the lookup-aware Binary provider row, with the provider table's
    full `Spec` retained for wrapper construction. -/
theorem exists_staticBinary_provider_row_matches_legacy_main_of_xor_active_main_table_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    (h_main_row :
      ∀ mainRow ∈ mainTable.table,
        eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
            length program).rowInputVar.core =
          ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_active : mainInteraction.mult = -1)
    (h_main_op : m.op r_main = ZiskFv.Trusted.OP_XOR) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  obtain ⟨providerInteraction, _h_provider_witness, _h_msg, _h_nonpull,
      _h_nonzero, providerTable, h_providerTable, _h_providerInteraction,
      h_providerBranches⟩ :=
    exists_op_provider_row_matches_legacy_main_spec_of_active_main_table_interaction
      m r_main witness h_constraints h_balanced h_specs h_mainTable
      h_mainComponent h_main_row h_main_active h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component, h_match⟩ :=
      h_arithMul
    exact False.elim
      (arithMul_provider_branch_ne_xor h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component, h_match⟩ :=
      h_binExt
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_xor h_component h_providerSpec
        h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component, h_match⟩ :=
      h_binary
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component, h_match⟩ :=
      h_binaryAdd
    exact False.elim (binaryAdd_provider_branch_ne_xor h_match h_main_op)

/-- Row-indexed XOR specialization of the full-ensemble operation-bus provider
    bridge.

Unlike `exists_staticBinary_provider_row_matches_legacy_main_of_xor_active_main_table_interaction`,
this adapter rewrites only the concrete Main table row that emitted the selected
interaction.  It is the construction-facing form: callers identify row `i` in
the selected Main table, and balance supplies the Binary provider row. -/
theorem exists_staticBinary_provider_row_matches_legacy_main_of_xor_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op : m.op r_main = ZiskFv.Trusted.OP_XOR) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_xor h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_xor h_component h_providerSpec
        h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim (binaryAdd_provider_branch_ne_xor h_match h_main_op)

/-- Row-indexed logical-Binary specialization of the full-ensemble operation-bus
    provider bridge.

For a concrete active Main row whose opcode is `AND`, `OR`, or `XOR`, balance
cannot use ArithMul, BinaryExtension, or BinaryAdd.  The remaining branch is the
lookup-aware Binary provider row. -/
theorem exists_staticBinary_provider_row_matches_legacy_main_of_logic_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op :
      m.op r_main = ZiskFv.Trusted.OP_AND
        ∨ m.op r_main = ZiskFv.Trusted.OP_OR
        ∨ m.op r_main = ZiskFv.Trusted.OP_XOR) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_staticBinaryLogic
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_staticBinaryLogic
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim (binaryAdd_provider_branch_ne_staticBinaryLogic h_match h_main_op)

/-- Row-indexed comparison-Binary specialization of the full-ensemble
    operation-bus provider bridge.

For a concrete active Main row whose opcode is `LT` or `LTU`, balance cannot
use ArithMul, BinaryExtension, or BinaryAdd.  The remaining branch is the
lookup-aware Binary provider row. -/
theorem exists_staticBinary_provider_row_matches_legacy_main_of_compare_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op :
      m.op r_main = ZiskFv.Trusted.OP_LT
        ∨ m.op r_main = ZiskFv.Trusted.OP_LTU) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_staticBinaryCompare
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_staticBinaryCompare
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim (binaryAdd_provider_branch_ne_staticBinaryCompare h_match h_main_op)

/-- For a concrete active Main row whose opcode is `EQ` (BEQ/BNE), balance cannot
use ArithMul, BinaryExtension, or BinaryAdd.  The remaining branch is the
lookup-aware Binary provider row. -/
theorem exists_staticBinary_provider_row_matches_legacy_main_of_eq_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op :
      m.op r_main = ZiskFv.Trusted.OP_EQ) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_staticBinaryEq
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_staticBinaryEq
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim (binaryAdd_provider_branch_ne_staticBinaryEq h_match h_main_op)

/-- Row-indexed `SUB` Binary specialization of the full-ensemble operation-bus
    provider bridge.

For a concrete active Main row whose opcode is `SUB`, balance cannot use
ArithMul, BinaryExtension, or BinaryAdd.  The remaining branch is the
lookup-aware Binary provider row. -/
theorem exists_staticBinary_provider_row_matches_legacy_main_of_sub_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op : m.op r_main = ZiskFv.Trusted.OP_SUB) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_staticBinarySub
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_staticBinarySub
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim (binaryAdd_provider_branch_ne_staticBinarySub h_match h_main_op)

/-- Row-indexed ADD provider specialization of the full-ensemble operation-bus
    provider bridge.

For a concrete active Main row whose opcode is `ADD`, balance cannot use
ArithMul or BinaryExtension. The remaining honest providers are lookup-aware
Binary and BinaryAdd, so the result preserves that disjunction for callers. -/
theorem exists_add_provider_row_matches_legacy_main_of_add_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op : m.op r_main = ZiskFv.Trusted.OP_ADD) :
    (∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1))
    ∨
    (∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.BinaryAdd.component
          ∧ providerTable.Spec
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.BinaryAdd.opBusMessage
                (ZiskFv.AirsClean.BinaryAdd.component.rowInput
                  (providerTable.environment providerRow))) 1)) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_staticBinaryAdd
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_staticBinaryAdd
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact Or.inl ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.BinaryAdd.opBusMessage
              (ZiskFv.AirsClean.BinaryAdd.component.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.BinaryAdd.component_eval_opBusMessageExpr]
        using h_match
    exact Or.inr ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, h_specs providerTable h_providerTable, h_match_row⟩

/-- Row-indexed W-mode ADD/SUB Binary specialization of the full-ensemble
    operation-bus provider bridge.

For a concrete active Main row whose opcode is `ADDW` or `SUBW`, balance cannot
use ArithMul, BinaryExtension, or BinaryAdd.  The remaining branch is the
lookup-aware Binary provider row. -/
theorem exists_staticBinary_provider_row_matches_legacy_main_of_w_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op :
      m.op r_main = ZiskFv.Trusted.OP_ADD_W
        ∨ m.op r_main = ZiskFv.Trusted.OP_SUB_W) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = ZiskFv.AirsClean.Binary.tableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.Binary.Spec
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.Binary.StaticBinaryTableSpecFacts
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.Binary.opBusMessage
                (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_staticBinaryW
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinaryExtension_provider_branch_ne_staticBinaryW
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.Binary.opBusMessage
              (ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [ZiskFv.AirsClean.Binary.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, binary_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim (binaryAdd_provider_branch_ne_staticBinaryW h_match h_main_op)

/-- Row-indexed BinaryExtension shift specialization of the full-ensemble
    operation-bus provider bridge.

For a concrete active Main row whose opcode is one of the BinaryExtension shift
opcodes, balance cannot use ArithMul, static Binary, or BinaryAdd.  The
remaining branch is the lookup-aware BinaryExtension provider row. -/
theorem exists_binaryExtension_provider_row_matches_legacy_main_of_shift_active_main_row_interaction
    {length : ℕ} {program : Program length}
    (m : ZiskFv.Airs.Main.Valid_Main FGL FGL) (r_main : ℕ)
    (witness : EnsembleWitness (fullRv64imEnsemble length program).ensemble)
    (h_constraints : witness.Constraints)
    (h_balanced : witness.BalancedChannels)
    (h_specs : witness.Spec)
    {mainTable : Table FGL}
    (h_mainTable : mainTable ∈ witness.allTables)
    (h_mainComponent :
      mainTable.component =
        ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus length program)
    {mainRow : Array FGL}
    (_h_mainRow : mainRow ∈ mainTable.table)
    (h_main_row :
      eval (mainTable.environment mainRow)
        (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
          length program).rowInputVar.core =
        ZiskFv.AirsClean.Main.rowAt m r_main)
    (h_main_active : m.is_external_op r_main = 1)
    {mainInteraction : Interaction FGL}
    (h_mainInteraction :
      mainInteraction ∈ mainTable.interactionsWith OpBusChannel.toRaw)
    (h_mainInteraction_eval :
      mainInteraction =
        ((OpBusChannel.emitted
          (-(ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core.is_external_op)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)).toRaw).eval
          (mainTable.environment mainRow))
    (h_active : mainInteraction.mult = -1)
    (h_main_op :
      m.op r_main = ZiskFv.Trusted.OP_SLL
        ∨ m.op r_main = ZiskFv.Trusted.OP_SRL
        ∨ m.op r_main = ZiskFv.Trusted.OP_SRA
        ∨ m.op r_main = ZiskFv.Trusted.OP_SLL_W
        ∨ m.op r_main = ZiskFv.Trusted.OP_SRL_W
        ∨ m.op r_main = ZiskFv.Trusted.OP_SRA_W) :
    ∃ providerTable ∈ witness.allTables,
      ∃ providerRow ∈ providerTable.table,
        providerTable.component = shiftTableConsumerComponent
          ∧ (∀ row ∈ providerTable.table, (ZiskFv.AirsClean.BinaryExtension.Spec
              (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.BinaryExtension.StaticBinaryExtensionTableSpecFacts
              (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                (providerTable.environment row)) ∧
            ZiskFv.AirsClean.BinaryExtension.ShiftB0RangeSpecFact
              (ZiskFv.AirsClean.BinaryExtension.shiftTableConsumerComponent.rowInput
                (providerTable.environment row))))
          ∧ ZiskFv.Airs.OperationBus.matches_entry
            (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
            (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
              (ZiskFv.AirsClean.BinaryExtension.opBusMessage
                (shiftTableConsumerComponent.rowInput
                  (providerTable.environment providerRow))) 1) := by
  have h_main_entry :
      ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
        (eval (mainTable.environment mainRow)
          (ZiskFv.AirsClean.Main.opBusMessageExpr
            (ZiskFv.AirsClean.Main.componentWithRomMemAndOpBus
              length program).rowInputVar.core)) 1 =
        ZiskFv.Airs.OperationBus.opBus_row_Main m r_main := by
    rw [ZiskFv.AirsClean.Main.eval_opBusMessageExpr]
    rw [h_main_row]
    rw [← ZiskFv.AirsClean.Main.opBusMessage_toEntry_rowAt_eq_opBus_row]
    rw [h_main_active]
  obtain ⟨_selectedMainRow, _h_selectedMainRow, _h_mainSpec, _h_selectedMainEval,
      providerInteraction, _h_provider_witness, h_msg, _h_nonpull, _h_nonzero,
      providerTable, h_providerTable, h_providerInteraction, h_providerBranches⟩ :=
    exists_op_provider_row_msg_eq_spec_of_active_main_table_interaction
      witness h_constraints h_balanced h_specs h_mainTable h_mainComponent
      h_mainInteraction h_active
  rcases h_providerBranches with h_arithMul | h_binExt | h_binary | h_binaryAdd
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_arithMul
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.ArithMul.primaryOpBusMessageExpr
                arithMulProviderComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (arithMul_provider_branch_ne_staticBinaryExtensionShift
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, h_providerRow, _h_providerSpec, h_component,
      h_providerEval⟩ := h_binExt
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryExtension.opBusMessageExpr
                shiftTableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    have h_match_row :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (ZiskFv.AirsClean.BinaryExtension.opBusMessage
              (shiftTableConsumerComponent.rowInput
                (providerTable.environment providerRow))) 1) := by
      simpa only [
        ZiskFv.AirsClean.BinaryExtension.eval_opBusMessageExpr,
      Component.rowInputVar, eval_varFromOffset_valueFromOffset, Component.rowInput]
        using h_match
    exact ⟨providerTable, h_providerTable, providerRow, h_providerRow,
      h_component, extension_table_full_spec_of_accepted witness h_constraints h_balanced
        h_providerTable h_component, h_match_row⟩
  · obtain ⟨providerRow, _h_providerRow, h_providerSpec, h_component,
      h_providerEval⟩ := h_binary
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.Binary.opBusMessageExpr
                ZiskFv.AirsClean.Binary.tableConsumerComponent.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (staticBinary_provider_branch_ne_staticBinaryExtensionShift
        h_component h_providerSpec h_match h_main_op)
  · obtain ⟨providerRow, _h_providerRow, _h_providerSpec, _h_component,
      h_providerEval⟩ := h_binaryAdd
    have h_match :
        ZiskFv.Airs.OperationBus.matches_entry
          (ZiskFv.Airs.OperationBus.opBus_row_Main m r_main)
          (ZiskFv.Channels.OperationBus.OpBusMessage.toEntry
            (eval (providerTable.environment providerRow)
              (ZiskFv.AirsClean.BinaryAdd.opBusMessageExpr
                ZiskFv.AirsClean.BinaryAdd.component.rowInputVar)) 1) := by
      rw [← h_main_entry]
      apply ZiskFv.Channels.OperationBus.matches_entry_of_eval_msg_eq
      rw [← h_providerEval, ← h_mainInteraction_eval]
      exact h_msg
    exact False.elim
      (binaryAdd_provider_branch_ne_staticBinaryExtensionShift h_match h_main_op)

end ZiskFv.AirsClean.FullEnsemble
