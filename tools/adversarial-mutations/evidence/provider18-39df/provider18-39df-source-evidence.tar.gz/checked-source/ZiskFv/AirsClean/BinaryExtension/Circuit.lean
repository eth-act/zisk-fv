import ZiskFv.AirsClean.BinaryExtension.Constraints
import ZiskFv.AirsClean.BinaryExtension.Soundness
import Clean.Air.FlatComponent
import Clean.Utils.Tactics

/-!
# BinaryExtension Clean Component (Phase C5)

Packages ZisK's BinaryExtension AIR as a Clean `Air.Flat.Component`.

BinaryExtension has no F-only `assertZero` constraints: its local semantic
content is table-lookup based, and its cross-AIR output is the operation-bus
push emitted by `main`. The Component `Spec` is therefore `True`; the terminal
table-consumer component emits on bus 124, where the exact static provider and
finished-channel balance carry membership.
-/

namespace ZiskFv.AirsClean.BinaryExtension

open Goldilocks
open Air.Flat
open ZiskFv.Channels.OperationBus (OpBusChannel)
open ZiskFv.Channels.BinaryExtensionTable (BinaryExtensionTableChannel)

/-- BinaryExtension as a Clean `GeneralFormalCircuit`. -/
def circuit : GeneralFormalCircuit FGL BinaryExtensionRow unit  where
  name := "BinaryExtension"
  main := main
  channelsWithRequirements := [OpBusChannel.toRaw]
  exposedChannels row _ :=
    expose OpBusChannel [OpBusChannel.pushed (opBusMessageExpr row)]
  Assumptions := fun _ _ => True
  Spec := fun row _ _ => Spec row
  ProverAssumptions := fun _ _ _ => True
  ProverSpec := fun _ _ _ => True
  soundness := by
    circuit_proof_start
    intro _
    simp [OpBusChannel]
  completeness := by circuit_proof_start [OpBusChannel]

/-- BinaryExtension as a Clean `Air.Flat.Component`. -/
def component : Air.Flat.Component FGL := { circuit := circuit }

/-- The BinaryExtensionTable consumer has the same local `True` specification
as `component`, but exposes its eight negative table messages. Membership is
provider-owned and is not a local consumer premise. -/
def tableConsumerCircuit : GeneralFormalCircuit FGL BinaryExtensionRow unit  where
  name := "BinaryExtensionWithTable"
  main := mainWithBinaryExtensionTable
  -- `elaborate_circuit` times out on the eight table emissions. These are the same
  -- two values the pre-migration `ElaboratedCircuit` stated by hand.
  elaborated :=
    { localLength _ := 0
      output _ _ := () }
  channelsWithRequirements := [OpBusChannel.toRaw, BinaryExtensionTableChannel.toRaw]
  exposedChannels row _ :=
    expose OpBusChannel [OpBusChannel.pushed (opBusMessageExpr row)] ++
    expose BinaryExtensionTableChannel
      [ BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 0
            a_byte := row.aCols.free_in_a_0
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsLo.free_in_c_0
            c_hi_byte := row.cColsLo.free_in_c_1
            op_is_shift := row.flags.op_is_shift }
      , BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 1
            a_byte := row.aCols.free_in_a_1
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsLo.free_in_c_2
            c_hi_byte := row.cColsLo.free_in_c_3
            op_is_shift := row.flags.op_is_shift }
      , BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 2
            a_byte := row.aCols.free_in_a_2
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsLo.free_in_c_4
            c_hi_byte := row.cColsLo.free_in_c_5
            op_is_shift := row.flags.op_is_shift }
      , BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 3
            a_byte := row.aCols.free_in_a_3
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsLo.free_in_c_6
            c_hi_byte := row.cColsLo.free_in_c_7
            op_is_shift := row.flags.op_is_shift }
      , BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 4
            a_byte := row.aCols.free_in_a_4
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsHi.free_in_c_8
            c_hi_byte := row.cColsHi.free_in_c_9
            op_is_shift := row.flags.op_is_shift }
      , BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 5
            a_byte := row.aCols.free_in_a_5
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsHi.free_in_c_10
            c_hi_byte := row.cColsHi.free_in_c_11
            op_is_shift := row.flags.op_is_shift }
      , BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 6
            a_byte := row.aCols.free_in_a_6
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsHi.free_in_c_12
            c_hi_byte := row.cColsHi.free_in_c_13
            op_is_shift := row.flags.op_is_shift }
      , BinaryExtensionTableChannel.emitted (-1)
          { op := row.flags.op
            byte_index := 7
            a_byte := row.aCols.free_in_a_7
            shift_amount := row.flags.free_in_b
            c_lo_byte := row.cColsHi.free_in_c_14
            c_hi_byte := row.cColsHi.free_in_c_15
            op_is_shift := row.flags.op_is_shift } ]
  -- Two `expose` blocks appended, so `exposedChannelsLawful_expose` cannot fire on
  -- the whole list; split the membership first.
  exposedChannels_eq := by
    intro input offset exposed h_mem
    simp only [expose, List.cons_append, List.nil_append, List.mem_cons,
      List.not_mem_nil, or_false] at h_mem
    rcases h_mem with rfl | rfl <;>
      simp [circuit_norm, mainWithBinaryExtensionTable, main,
        opBusMessageExpr, aLo, aHi, OpBusChannel, BinaryExtensionTableChannel]
  Assumptions := fun _ _ => True
  Spec := fun row _ _ => Spec row
  ProverAssumptions := fun _ _ _ => True
  ProverSpec := fun _ _ _ => True
  soundness := by
    circuit_proof_start
    intro _
    simp [OpBusChannel]
  completeness := by circuit_proof_start [OpBusChannel, BinaryExtensionTableChannel]

def tableConsumerComponent : Air.Flat.Component FGL := { circuit := tableConsumerCircuit }

/-- Channel consumer retaining exactly the shift-range lookup of
    `shiftStaticLookupCircuit`. Replacing that static component must not drop
    its `b_0` range constraint. No table-membership assumption is added. -/
def shiftTableConsumerCircuit : GeneralFormalCircuit FGL BinaryExtensionRow unit where
  name := "BinaryExtensionWithTableAndShiftRange"
  main := mainWithBinaryExtensionTableAndShiftRange
  elaborated :=
    { localLength _ := 0
      output _ _ := () }
  channelsWithRequirements := [OpBusChannel.toRaw, BinaryExtensionTableChannel.toRaw]
  exposedChannels := tableConsumerCircuit.exposedChannels
  exposedChannels_eq := by
    intro input offset exposed h_mem
    have he := tableConsumerCircuit.exposedChannels_eq input offset exposed h_mem
    simpa only [tableConsumerCircuit, mainWithBinaryExtensionTableAndShiftRange,
      circuit_norm] using he
  Assumptions := fun _ _ => True
  Spec := fun row _ _ => Spec row ∧
    ZiskFv.AirsClean.RangeTables.rangeTable24.Spec row.flags.b_0
  ProverAssumptions := fun row _ _ =>
    ZiskFv.AirsClean.RangeTables.rangeTable24.Spec row.flags.b_0
  ProverSpec := fun _ _ _ => True
  soundness := by
    circuit_proof_start
    refine ⟨?_, ?_⟩
    · simpa only [Table.fromStatic, StaticTable.toTable] using h_holds
    · intro _
      simp [OpBusChannel, BinaryExtensionTableChannel]
  completeness := by
    circuit_proof_start [OpBusChannel, BinaryExtensionTableChannel, Lookup.completeness_def]
    simpa only [Table.fromStatic, StaticTable.toTable] using h_assumptions

def shiftTableConsumerComponent : Air.Flat.Component FGL :=
  { circuit := shiftTableConsumerCircuit }

/-- Adding the range lookup changes no channel interaction. -/
theorem shiftTableConsumerComponent_interactionsWith
    (channel : RawChannel FGL) :
    shiftTableConsumerComponent.operations.interactionsWith channel =
      tableConsumerComponent.operations.interactionsWith channel := by
  rw [Component.interactionsWith_eq, Component.interactionsWith_eq]
  change ((mainWithBinaryExtensionTableAndShiftRange
      (varFromOffset BinaryExtensionRow 0)).operations (size BinaryExtensionRow)).interactionsWith channel =
    ((mainWithBinaryExtensionTable
      (varFromOffset BinaryExtensionRow 0)).operations (size BinaryExtensionRow)).interactionsWith channel
  cases h_main : mainWithBinaryExtensionTable
      (varFromOffset BinaryExtensionRow 0) (size BinaryExtensionRow) with
  | mk output operations =>
    simp only [mainWithBinaryExtensionTableAndShiftRange, Circuit.bind_def,
      Circuit.operations, Circuit.lookup, h_main, Operations.interactionsWith_append,
      Operations.interactionsWith_lookup, Operations.interactionsWith_nil, List.append_nil]

theorem component_interactionsWith_opBus :
    component.operations.interactionsWith OpBusChannel.toRaw =
      [((OpBusChannel.pushed (opBusMessageExpr component.rowInputVar)).toRaw)] := by
  apply Component.interactionsWith_of_exposedChannels
  change ⟨OpBusChannel.toRaw,
      [((OpBusChannel.pushed (opBusMessageExpr component.rowInputVar)).toRaw)]⟩ ∈
    component.exposedChannels
  simp only [component, circuit, Component.exposedChannels, expose, List.mem_singleton, List.map_cons,
    List.map_nil]

/-- The BinaryExtension `Spec` for a row, derived through the Clean
    Component. Since `Spec := True` at C5, this is mainly the load-bearing
    closure hook showing consumers can route through `circuit.soundness`.

    The proof still follows the normal F-3 idiom: normalize
    `circuit.soundness`, feed a constant-expression row, and discharge the
    generated obligations. That keeps this skeleton component aligned with
    the non-trivial AIRs instead of bypassing the component field. -/
theorem spec_via_component (row : BinaryExtensionRow FGL) :
    Spec row := by
  have hsound := circuit.soundness
  simp only [GeneralFormalCircuit.Soundness, circuit, circuit_norm] at hsound
  refine (hsound (Environment.fromInput row (fun _ n => (#[] : Array (Vector FGL n))))
    { aCols := {
        free_in_a_0 := .const row.aCols.free_in_a_0
        free_in_a_1 := .const row.aCols.free_in_a_1
        free_in_a_2 := .const row.aCols.free_in_a_2
        free_in_a_3 := .const row.aCols.free_in_a_3
        free_in_a_4 := .const row.aCols.free_in_a_4
        free_in_a_5 := .const row.aCols.free_in_a_5
        free_in_a_6 := .const row.aCols.free_in_a_6
        free_in_a_7 := .const row.aCols.free_in_a_7 }
      cColsLo := {
        free_in_c_0 := .const row.cColsLo.free_in_c_0
        free_in_c_1 := .const row.cColsLo.free_in_c_1
        free_in_c_2 := .const row.cColsLo.free_in_c_2
        free_in_c_3 := .const row.cColsLo.free_in_c_3
        free_in_c_4 := .const row.cColsLo.free_in_c_4
        free_in_c_5 := .const row.cColsLo.free_in_c_5
        free_in_c_6 := .const row.cColsLo.free_in_c_6
        free_in_c_7 := .const row.cColsLo.free_in_c_7 }
      cColsHi := {
        free_in_c_8 := .const row.cColsHi.free_in_c_8
        free_in_c_9 := .const row.cColsHi.free_in_c_9
        free_in_c_10 := .const row.cColsHi.free_in_c_10
        free_in_c_11 := .const row.cColsHi.free_in_c_11
        free_in_c_12 := .const row.cColsHi.free_in_c_12
        free_in_c_13 := .const row.cColsHi.free_in_c_13
        free_in_c_14 := .const row.cColsHi.free_in_c_14
        free_in_c_15 := .const row.cColsHi.free_in_c_15 }
      flags := {
        op := .const row.flags.op
        free_in_b := .const row.flags.free_in_b
        op_is_shift := .const row.flags.op_is_shift
        b_0 := .const row.flags.b_0
        b_1 := .const row.flags.b_1 } }
    row ?_).1
  · simp [circuit_norm]

end ZiskFv.AirsClean.BinaryExtension
