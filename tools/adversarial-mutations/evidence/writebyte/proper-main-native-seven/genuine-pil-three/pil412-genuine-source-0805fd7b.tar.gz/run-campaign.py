from pathlib import Path
import collections, hashlib, json, os, re, subprocess, sys, time

repo = Path.cwd()
base = repo / 'build/writebyte-pil-412-campaign'
spec = json.loads((base / 'cases-source-spec.json').read_text())
cases = json.loads((base / 'copied-source-freeze.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
compiler = Path('/nix/store/09qxd6wcq9w1920sydkh23h8lhr3bikp-compile-mutation/bin/compile-mutation')
generator = Path('/nix/store/6z2qwkmrvdv4ypvynvkxil2ch3vndiy9-pil-extract-0.1.0/bin/pil-extract')
production = Path('/nix/store/jadjdsv2y69gq6mq6xfiqx5cvas5l82x-zisk-fv-extracted-lean-1.0')
lean = Path('/home/cody/.elan/toolchains/leanprover--lean4---v4.28.0/bin/lean')
lease_path = Path('/home/cody/zisk-fv-tuples-six/build/native-six418/checked-six-kind-lease.json')
lease = json.loads(lease_path.read_text())
assert sha(lease_path) == '1e8c6bec9cb45b7f6951c578b47826a9bc5b742b7b7c62a57574fa5d38ab15c2'
prior = repo / 'tools/adversarial-mutations/evidence/writebyte/native-source-ba6a5457'
prior_before = json.loads((prior / 'private-gate-before-attempt3.json').read_text())
prior_full = json.loads((prior / 'full-private-before.json').read_text())
assert json.loads((prior / 'full-private-after.json').read_text())['roots'] == 91
fresh = {row['module']: row for row in prior_full['source_and_actual_compiled_objects']}
write_modules = {'Extraction/Circuit', 'Extraction/LookupWiring', 'Extraction/MemAlignWriteByte',
    'ZiskFv/AirsClean/MemAlignWriteByte/Source',
    'ZiskFv/AirsClean/MemAlignWriteByte/ExtractedWiring',
    'ZiskFv/AirsClean/MemAlignWriteByte/NativeTupleSource'}
consumer_paths = [repo / fresh[name]['source'] for name in sorted(write_modules) if name in fresh]
immutable_paths = [compiler, generator, lean, lease_path,
    Path('/nix/store/l1qla9chybhkiw893rqfyj75jx61px0j-pil2-compiler-0.9.0/src/pil.js'),
    Path('/nix/store/nr0dnrnibq8114xa0i7zr7qg6n05q03g-nodejs-20.20.2/bin/node'),
    production / 'LookupWiring.lean', production / 'MemAlignWriteByte.lean',
    Path('/nix/store/phg76nimggryd3c1pj1kk28948j1hqiv-zisk-fv-extracted-lean-1.0.drv'),
    Path('/home/cody/zisk-fv-rowmap-main-integration/build/native-trace-normal-evidence/normal-producer-artifact-comparison.json')]
for payload in ['state-machines/arith/src/arith_frops_fixed.bin',
        'state-machines/binary/src/binary_basic_frops_fixed.bin',
        'state-machines/binary/src/binary_extension_frops_fixed.bin']:
    immutable_paths.append(Path('/nix/store/14aay7640sy7qaarlja5g72gba45rc7w-zisk-pilout-git-b632745-fixed') / payload)
immutable_paths.append(base / 'immutable-store-provenance.json')
readonly_objects = lease['own_sources'] + lease['own_fresh_verified_objects'] + lease['borrowed_verified_inputs']

def original_tree(root):
    result = {}
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): result[str(p.relative_to(root))] = {'kind': 'symlink', 'link': os.readlink(p)}
        elif p.is_file(): result[str(p.relative_to(root))] = {'kind': 'file', 'sha256': sha(p)}
    return result

def integrity(freeze):
    for row in freeze['immutable_inputs'] + freeze['unchanged_consumer_sources']:
        assert sha(row['path']) == row['sha256'], ('FROZEN SOURCE/EXECUTABLE CHANGED', row)
    for row in readonly_objects:
        assert sha(row['path']) == row['sha256'], ('CHECKED LEASE CHANGED', row)
    for row in fresh.values():
        assert sha(row['output']) == row['object_sha256'], ('OWN91 CAPSULE CHANGED', row)
        assert sha(repo / row['source']) == row['source_sha256']

def run(command, log, env):
    start = time.monotonic()
    proc = subprocess.run([str(x) for x in command], cwd=repo, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log.write_text(proc.stdout)
    record = {'command': [str(x) for x in command], 'returncode': proc.returncode,
        'seconds': time.monotonic() - start, 'log': str(log.relative_to(repo))}
    print(json.dumps(record), flush=True)
    return record, proc.stdout

def metadata(root):
    links = dict(prior_before['readonly_links'])
    for module, row in fresh.items():
        links[module + '.olean'] = {'path': row['output'], 'sha256': row['object_sha256']}
    for relative, row in links.items():
        module = relative.split('.olean', 1)[0].split('.ilean', 1)[0]
        if module in write_modules: continue
        assert sha(row['path']) == row['sha256']
        dest = root / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        assert not dest.parent.is_symlink()
        if dest.is_symlink(): assert dest.resolve() == Path(row['path']).resolve()
        elif dest.exists(): raise RuntimeError(('Unexpected private nonlink input', dest))
        else: dest.symlink_to(row['path'])
    for module in write_modules:
        for suffix in ['.olean', '.olean.hash', '.olean.private', '.olean.server', '.ilean']:
            assert not Path(str(root / module) + suffix).is_symlink()

if sys.argv[1] == 'freeze':
    freeze = {'status': 'COHESIVE PRE-EXECUTION FREEZE; no producer or kernel run yet',
        'producer_source_commit': '599d039d2b0ae2bba1383f71b3a8d0c5febd30e2',
        'verified_copy_helper_source_commit': '527a76ed31a218ebbfe8cd78032e3713e07a8340',
        'upstream': spec['upstream'], 'case_order': [row['case'] for row in cases],
        'case_spec_sha256': sha(base / 'cases-source-spec.json'),
        'runner_sha256': sha(Path(__file__)),
        'immutable_inputs': [{'path': str(p), 'sha256': sha(p)} for p in immutable_paths],
        'unchanged_consumer_sources': [{'path': str(p), 'sha256': sha(p)} for p in consumer_paths],
        'owned91_capsule': str(prior), 'original91_roots_preserved_not_new_campaign_RAW': True,
        'checked_six_lease_sha256': sha(lease_path),
        'actual_lean_flags': lease['lean_options'],
        'resources': {'LEAN_NUM_THREADS': 2, 'CARGO_BUILD_JOBS': 2, 'NIX_CORES': 2,
            'NIX_MAX_JOBS': 1, 'Node_explicit_old_space_MiB': 16384,
            'producer_concurrency': 1, 'allowed_concurrent_parent_lane': 'Mem1308'},
        'read_only_case_inputs': prior_before['readonly_links'],
        'own91_fresh_compiled_objects': list(fresh.values()),
        'case_writable_modules_and_all_sidecars_excluded': sorted(write_modules),
        'classification': 'ONLY named unchanged source tuple kernel rejection after actual compiler+generator+generatedmodules+Source pass; compiler/setup/timeout failures are NOTkills',
        'missing_attribute_probe': 'Historical ownflake compile-mutation attribute missing; metadata evaluation failure only, never kill; actual built verified-copy wrapper used',
        'source_trees': {row['case']: original_tree(Path(row['source_root'])) for row in cases},
        'no_expected_proof_model_shared_generator_core_or_protected_edits': True}
    integrity(freeze)
    (base / 'cohesive-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n')
    print('FROZEN', sha(base / 'cohesive-freeze.json'), flush=True)
    sys.exit(0)

assert sys.argv[1] == 'run'
freeze = json.loads((base / 'cohesive-freeze.json').read_text())
assert sha(Path(__file__)) == freeze['runner_sha256']
assert sha(base / 'cases-source-spec.json') == freeze['case_spec_sha256']
integrity(freeze)
results = []
for item in cases:
    name = item['case']; case = base / 'cases' / name; source = Path(item['source_root'])
    assert original_tree(source) == freeze['source_trees'][name]
    assert sha(source / spec['upstream']['relative_path']) == item['actual_target_sha256']
    gen = case / 'generated' / 'Extraction'; gen.mkdir(parents=True, exist_ok=True)
    out = case / 'lean'; out.mkdir(exist_ok=True)
    metadata(out)
    env = os.environ.copy(); env.update(LEAN_NUM_THREADS='2', CARGO_BUILD_JOBS='2',
        NODE_OPTIONS='--max-old-space-size=16384',
        NIX_CONFIG='cores = 2\nmax-jobs = 1\nextra-experimental-features = nix-command flakes',
        LEAN_PATH=str(out) + ':' + lease['LEAN_PATH_READONLY'])
    assert str(repo / '.lake/build/lib/lean') not in env['LEAN_PATH']
    result = {'case': name, 'source_target_sha256': item['actual_target_sha256'],
        'LEAN_PATH': env['LEAN_PATH'], 'stages': [], 'classification': 'INCOMPLETE'}
    pilout = case / 'actual-source.pilout'
    record, text = run([compiler, source, pilout], case / '01-actual-pil-compiler.log', env)
    result['stages'].append(record)
    if record['returncode']: result['classification'] = 'COMPILER_FAILURE_NOT_KILL'
    if record['returncode'] == 0:
        result['pilout_sha256'] = sha(pilout)
        commands = [
            [generator, 'circuit-shim', '--output', gen / 'Circuit.lean'],
            [generator, 'lookup-wiring', '--pilout', pilout, '--output', gen / 'LookupWiring.lean'],
            [generator, 'air', '--pilout', pilout, '--air', 'MemAlignWriteByte', '--skip-unsupported', '--output', gen / 'MemAlignWriteByte.lean']]
        for i, command in enumerate(commands):
            record, text = run(command, case / f'02-generator-{i}.log', env)
            result['stages'].append(record)
            if record['returncode']:
                result['classification'] = 'GENERATOR_FAILURE_NOT_KILL'; break
        if all(stage['returncode'] == 0 for stage in result['stages']):
            result['generated_sha256'] = {p.name: sha(p) for p in gen.glob('*.lean')}
            if name in ['baseline', 'comment-neutral']:
                for leaf in ['LookupWiring.lean', 'Circuit.lean', 'MemAlignWriteByte.lean']:
                    proc = subprocess.run(['cmp', str(gen / leaf), str(production / leaf)], cwd=repo)
                    assert proc.returncode == 0, ('CANONICAL BYTECMP FAILED', name, leaf)
                result['actual_normal34_bytecmp'] = True
            for module, src in [
                ('Extraction/Circuit', gen / 'Circuit.lean'),
                ('Extraction/LookupWiring', gen / 'LookupWiring.lean'),
                ('Extraction/MemAlignWriteByte', gen / 'MemAlignWriteByte.lean'),
                ('ZiskFv/AirsClean/MemAlignWriteByte/Source', repo / 'ZiskFv/AirsClean/MemAlignWriteByte/Source.lean'),
                ('ZiskFv/AirsClean/MemAlignWriteByte/ExtractedWiring', repo / 'ZiskFv/AirsClean/MemAlignWriteByte/ExtractedWiring.lean'),
                ('ZiskFv/AirsClean/MemAlignWriteByte/NativeTupleSource', repo / 'ZiskFv/AirsClean/MemAlignWriteByte/NativeTupleSource.lean')]:
                obj = out / (module + '.olean'); obj.parent.mkdir(parents=True, exist_ok=True)
                assert not obj.is_symlink()
                record, text = run([lean, *lease['lean_options'], '-o', obj, src],
                    case / ('03-kernel-' + module.replace('/', '-') + '.log'), env)
                record['module'] = module
                result['stages'].append(record)
                if record['returncode']:
                    expected = next((c['unchanged_named_kernel_reject'].split('.')[-1] for c in spec['mutations'] if c['name'] == name), None)
                    actual_named = []
                    if module.endswith('/ExtractedWiring'):
                        source_lines = src.read_text().splitlines()
                        errors = [int(line) for line in re.findall(re.escape(str(src)) + r':(\d+):\d+: error', text)]
                        for line in errors:
                            names = [re.match(r'(?:theorem|def)\s+(\w+)', s).group(1)
                                for s in source_lines[:line] if re.match(r'(?:theorem|def)\s+(\w+)', s)]
                            if names: actual_named.append(names[-1])
                    result['named_kernel_failures'] = actual_named
                    result['expected_named_failure'] = expected
                    result['classification'] = ('NAMED_SOURCE_TUPLE_KERNEL_REJECT' if
                        expected is not None and expected in actual_named and
                        ("Tactic `rfl` failed" in text or "Tactic 'rfl' failed" in text) else 'KERNEL_FAILURE_NOT_NAMED_KILL')
                    break
            else:
                result['classification'] = 'CONTROL_PASS' if name in ['baseline', 'comment-neutral'] else 'REAL_BLINDSPOT_MUTANT_PASSED'
    for relative, frozen in freeze['source_trees'][name].items():
        p = source / relative
        assert (os.readlink(p) == frozen['link']) if frozen['kind'] == 'symlink' else sha(p) == frozen['sha256']
    integrity(freeze)
    result['source_consumer_executables_and_all_readonly_CI_inputs_unchanged'] = True
    (case / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    results.append(result); (base / 'campaign-results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(name, result['classification'], flush=True)
    if name in ['baseline', 'comment-neutral'] and result['classification'] != 'CONTROL_PASS': sys.exit(1)
    if name not in ['baseline', 'comment-neutral'] and result['classification'] != 'NAMED_SOURCE_TUPLE_KERNEL_REJECT': sys.exit(1)
print('COMPLETE canonical baseline + harmless comment control + THREE genuine PIL-source named-kernel tuple rejections', flush=True)
