import Mathlib

set_option linter.all false

/-!
# Generated Extraction Circuit Shim

This module is intentionally tiny. It is the generated-only interface used by
the old per-AIR extraction files under `build/extraction/Extraction/`.
It avoids the deleted root `ZiskFv.Circuit` API and also avoids colliding with
Clean's root `Circuit` monad by living under the `Extraction` namespace.
-/

namespace Extraction

class Circuit (F ExtF : Type) (C : Type → Type → Sort u) [Field F] [Field ExtF] where
  main : C F ExtF → (id column row rotation : ℕ) → F
  preprocessed : C F ExtF → (column row rotation : ℕ) → F
  challenge : C F ExtF → (index : ℕ) → ExtF
  exposed : C F ExtF → (index : ℕ) → ExtF

end Extraction
