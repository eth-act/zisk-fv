import Mathlib

import Extraction.Circuit

set_option linter.all false

register_simp_attr MemAlignWriteByte_air_simplification
register_simp_attr MemAlignWriteByte_constraint_and_interaction_simplification

namespace MemAlignWriteByte.extraction

-- airgroup: Zisk (id 0)  air: MemAlignWriteByte (id 20)
-- witness column names:
--   stage 1 col 0: sel_high_4b
--   stage 1 col 1: sel_high_2b
--   stage 1 col 2: sel_high_b
--   stage 1 col 3: direct_value
--   stage 1 col 4: composed_value
--   stage 1 col 5: written_composed_value
--   stage 1 col 6: written_byte_value
--   stage 1 col 7: value_16b
--   stage 1 col 8: value_8b
--   stage 1 col 9: byte_value
--   stage 1 col 10: addr_w
--   stage 1 col 11: step
--   stage 1 col 12: mem_write_values[0]
--   stage 1 col 13: mem_write_values[1]
--   stage 2 col 0: gsum
--   stage 2 col 1: im_cluster
--   stage 2 col 2: im_cluster
--   stage 2 col 3: im_single

-- air value names:
--   stage 1 air value 0: MemAlignWriteByte.padding_size
--   stage 2 air value 1: MemAlignWriteByte.im_direct[0]
--   stage 2 air value 2: MemAlignWriteByte.im_direct[1]
--   stage 2 air value 3: MemAlignWriteByte.im_direct[2]

  @[simp]
  def constraint_0_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem_align_byte.pil:39 sel_high_4b*(1-sel_high_4b)
    (((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_1_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem_align_byte.pil:40 sel_high_2b*(1-sel_high_2b)
    (((Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_2_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem_align_byte.pil:41 sel_high_b*(1-sel_high_b)
    (((Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_3_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem_align_byte.pil:63 composed_value-(((byte_value*(byte_value_factor))+(value_8b*(value_8b_factor)))+(value_16b*(value_16b_factor)))
    (((Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0)) - ((((Extraction.Circuit.main c (id := 1) (column := 9) (row := row) (rotation := 0)) * (((((16777216 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))) + ((65536 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) + ((256 * (1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))) + ((1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))))) + ((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) * (((((16777216 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))) + ((65536 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))) + ((256 * (1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) + ((1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))))) + ((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * ((65536 * (1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))))))) = 0

  @[simp]
  def constraint_4_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem_align_byte.pil:87 written_composed_value-(((written_byte_value*(byte_value_factor))+(value_8b*(value_8b_factor)))+(value_16b*(value_16b_factor)))
    (((Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)) - ((((Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0)) * (((((16777216 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))) + ((65536 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) + ((256 * (1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))) + ((1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))))) + ((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) * (((((16777216 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))) + ((65536 * (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))) + ((256 * (1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)))) * (1 - (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) + ((1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))) * (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0)))))) + ((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * ((65536 * (1 - (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0))))))) = 0

  @[simp]
  def constraint_5_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem_align_byte.pil:91 mem_write_values[0]-((sel_high_4b*(direct_value-written_composed_value))+written_composed_value)
    (((Extraction.Circuit.main c (id := 1) (column := 12) (row := row) (rotation := 0)) - (((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0))))) = 0

  @[simp]
  def constraint_6_every_row {C : Type → Type → Sort u} {F ExtF : Type} [Field F] [Field ExtF] [Extraction.Circuit F ExtF C] (c : C F ExtF) (row: ℕ) :=
    -- mem/pil/mem_align_byte.pil:92 mem_write_values[1]-((sel_high_4b*(written_composed_value-direct_value))+direct_value)
    (((Extraction.Circuit.main c (id := 1) (column := 13) (row := row) (rotation := 0)) - (((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_7_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:590 (im_cluster*(((Zisk.gsum_e[2])+std_gamma)*((Zisk.gsum_e[3])+std_gamma)))-((-1*((Zisk.gsum_e[3])+std_gamma))+((Zisk.gsum_e[2])+std_gamma))
    ((((Extraction.Circuit.main c (id := 2) (column := 1) (row := row) (rotation := 0)) * (((((((((((((((Extraction.Circuit.main c (id := 1) (column := 13) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 12) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 8) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0)) + 1)) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 10) (row := row) (rotation := 0)) * 8)) * (Extraction.Circuit.challenge c (index := 0))) + 2) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1))) * ((((((((((((Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 1) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + (((Extraction.Circuit.main c (id := 1) (column := 10) (row := row) (rotation := 0)) * 8) + ((((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * 4) + ((Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)) * 2)) + (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) * (Extraction.Circuit.challenge c (index := 0))) + 2) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1))))) - ((18446744069414584320 * ((((((((((((Extraction.Circuit.main c (id := 1) (column := 6) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 1) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + (((Extraction.Circuit.main c (id := 1) (column := 10) (row := row) (rotation := 0)) * 8) + ((((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * 4) + ((Extraction.Circuit.main c (id := 1) (column := 1) (row := row) (rotation := 0)) * 2)) + (Extraction.Circuit.main c (id := 1) (column := 2) (row := row) (rotation := 0))))) * (Extraction.Circuit.challenge c (index := 0))) + 2) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1)))) + ((((((((((((((Extraction.Circuit.main c (id := 1) (column := 13) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 12) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 8) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0)) + 1)) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 10) (row := row) (rotation := 0)) * 8)) * (Extraction.Circuit.challenge c (index := 0))) + 2) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1)))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_8_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:590 (im_cluster*(((Zisk.gsum_e[4])+std_gamma)*((Zisk.gsum_e[5])+std_gamma)))-((-1*((Zisk.gsum_e[5])+std_gamma))+(-1*((Zisk.gsum_e[4])+std_gamma)))
    ((((Extraction.Circuit.main c (id := 2) (column := 2) (row := row) (rotation := 0)) * (((((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1))) * ((((((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 9) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 88) + (Extraction.Circuit.challenge c (index := 1))))) - ((18446744069414584320 * ((((((Extraction.Circuit.main c (id := 1) (column := 8) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 9) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 88) + (Extraction.Circuit.challenge c (index := 1)))) + (18446744069414584320 * ((((Extraction.Circuit.main c (id := 1) (column := 7) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 103) + (Extraction.Circuit.challenge c (index := 1))))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_9_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:567 (im_single*((Zisk.gsum_e[1])+std_gamma))+1
    ((((Extraction.Circuit.main c (id := 2) (column := 3) (row := row) (rotation := 0)) * ((((((((((((((((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + (((Extraction.Circuit.main c (id := 1) (column := 0) (row := row) (rotation := 0)) * ((Extraction.Circuit.main c (id := 1) (column := 3) (row := row) (rotation := 0)) - (Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0)))) + (Extraction.Circuit.main c (id := 1) (column := 4) (row := row) (rotation := 0)))) * (Extraction.Circuit.challenge c (index := 0))) + 8) * (Extraction.Circuit.challenge c (index := 0))) + (Extraction.Circuit.main c (id := 1) (column := 11) (row := row) (rotation := 0))) * (Extraction.Circuit.challenge c (index := 0))) + ((Extraction.Circuit.main c (id := 1) (column := 10) (row := row) (rotation := 0)) * 8)) * (Extraction.Circuit.challenge c (index := 0))) + 1) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_10_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:599 (((gsum-('gsum*(1-__L1__)))-((im_cluster+im_cluster)+im_single))*((Zisk.gsum_e[0])+std_gamma))+1
    ((((((Extraction.Circuit.main c (id := 2) (column := 0) (row := row) (rotation := 0)) - ((Extraction.Circuit.main c (id := 2) (column := 0) (row := row - 1) (rotation := 0)) * (1 - (Extraction.Circuit.preprocessed c (column := 0) (row := row) (rotation := 0))))) - (((Extraction.Circuit.main c (id := 2) (column := 1) (row := row) (rotation := 0)) + (Extraction.Circuit.main c (id := 2) (column := 2) (row := row) (rotation := 0))) + (Extraction.Circuit.main c (id := 2) (column := 3) (row := row) (rotation := 0)))) * ((((Extraction.Circuit.main c (id := 1) (column := 5) (row := row) (rotation := 0)) * (Extraction.Circuit.challenge c (index := 0))) + 107) + (Extraction.Circuit.challenge c (index := 1)))) + 1)) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_11_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (MemAlignWriteByte.im_direct[0]*((Zisk.direct_gsum_e[0])+std_gamma))-MemAlignWriteByte.padding_size
    ((((Extraction.Circuit.exposed c (index := 1)) * (((((((8 * (Extraction.Circuit.challenge c (index := 0))) * (Extraction.Circuit.challenge c (index := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 1) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1)))) - (Extraction.Circuit.exposed c (index := 0)))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_12_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (MemAlignWriteByte.im_direct[1]*((Zisk.direct_gsum_e[1])+std_gamma))-(Zisk.direct_gsum_s[1])
    ((((Extraction.Circuit.exposed c (index := 2)) * (((((((Extraction.Circuit.challenge c (index := 0)) * (Extraction.Circuit.challenge c (index := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 2) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1)))) - (0 - (Extraction.Circuit.exposed c (index := 0))))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_13_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:656 (MemAlignWriteByte.im_direct[2]*((Zisk.direct_gsum_e[2])+std_gamma))-MemAlignWriteByte.padding_size
    ((((Extraction.Circuit.exposed c (index := 3)) * ((((((((8 * (Extraction.Circuit.challenge c (index := 0))) + 1) * (Extraction.Circuit.challenge c (index := 0))) * (Extraction.Circuit.challenge c (index := 0))) + 2) * (Extraction.Circuit.challenge c (index := 0))) + 10) + (Extraction.Circuit.challenge c (index := 1)))) - (Extraction.Circuit.exposed c (index := 0)))) = 0

  @[simp]
  -- Mixed witness/challenge constraint emitted for single-field circuits.
  def constraint_14_every_row {C : Type → Type → Sort u} {F : Type} [Field F] [Extraction.Circuit F F C] (c : C F F) (row: ℕ) :=
    -- std_sum.pil:696 __L1__'*((Zisk.gsum_result-gsum)-((MemAlignWriteByte.im_direct[0]+MemAlignWriteByte.im_direct[1])+MemAlignWriteByte.im_direct[2]))
    (((Extraction.Circuit.preprocessed c (column := 0) (row := row + 1) (rotation := 0)) * (((Extraction.Circuit.exposed c (index := 0)) - (Extraction.Circuit.main c (id := 2) (column := 0) (row := row) (rotation := 0))) - (((Extraction.Circuit.exposed c (index := 1)) + (Extraction.Circuit.exposed c (index := 2))) + (Extraction.Circuit.exposed c (index := 3)))))) = 0

end MemAlignWriteByte.extraction
