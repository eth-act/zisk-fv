from pathlib import Path
import hashlib, io, json, re, shutil, tarfile
repo = Path.cwd()
base = repo / 'build/writebyte-pil-412-campaign'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze = json.loads((base / 'cohesive-freeze.json').read_text())
results = json.loads((base / 'campaign-results.json').read_text())
consumer = repo / 'ZiskFv/AirsClean/MemAlignWriteByte/ExtractedWiring.lean'
consumer_lines = consumer.read_text().splitlines()
case_specs = {c['name']: c for c in json.loads((base / 'cases-source-spec.json').read_text())['mutations']}
strict = {}
for row in results:
    if row['case'] not in case_specs:
        continue
    expected = case_specs[row['case']]['unchanged_named_kernel_reject'].split('.')[-1]
    stage = next((s for s in row['stages'] if s.get('module', '').endswith('/ExtractedWiring')), None)
    matching = []
    if stage is not None and stage['returncode'] != 0:
        text = (repo / stage['log']).read_text()
        headers = list(re.finditer(r'(?m)^' + re.escape(str(consumer)) +
            r':(\d+):(\d+): (error(?:\([^\n)]*\))?|warning(?:\([^\n)]*\))?):', text))
        for i, header in enumerate(headers):
            line = int(header.group(1))
            names = [re.match(r'(?:theorem|def)\s+(\w+)', s).group(1)
                for s in consumer_lines[:line] if re.match(r'(?:theorem|def)\s+(\w+)', s)]
            block = text[header.start():headers[i+1].start() if i+1 < len(headers) else len(text)]
            if names and names[-1] == expected and header.group(3).startswith('error') and re.search(r"Tactic [`']rfl[`'] failed", block):
                matching.append({'declaration': expected, 'line': line, 'column': int(header.group(2)),
                    'unchanged_source_sha256': sha(consumer), 'actual_kernel_diagnostic': block})
    strict[row['case']] = {'expected_declaration': expected,
        'same_named_declaration_actual_rfl_equation_reject': bool(matching),
        'matching_full_diagnostics': matching,
        'classification_note': 'Unknown identifier/setup/compiler errors never inherit a kill from some OTHER rfl failure in the file.'}
(base / 'named-diagnostic-classification.json').write_text(json.dumps(strict, indent=2) + '\n')
archive = base / 'pil412-genuine-source-0805fd7b.tar.gz'
selected = {}
for p in base.iterdir():
    if p.is_file() and p.suffix in {'.json', '.log', '.exit', '.py'}:
        selected[str(p.relative_to(base))] = p
for row in results:
    case = base / 'cases' / row['case']
    for p in case.iterdir():
        if p.is_file() and (p.suffix in {'.json', '.log', '.pilout'}):
            selected[str(p.relative_to(base))] = p
    for p in (case / 'generated' / 'Extraction').glob('*.lean'):
        selected[str(p.relative_to(base))] = p
    source = case / 'source' / freeze['upstream']['relative_path']
    selected[str(source.relative_to(base))] = source
for row in freeze['unchanged_consumer_sources']:
    selected['unchanged-consumer/' + Path(row['path']).name] = Path(row['path'])
for p in (base / 'scoped-pil').glob('*.pil'):
    selected[str(p.relative_to(base))] = p
members = [{'path': name, 'sha256': sha(path), 'bytes': path.stat().st_size}
    for name, path in sorted(selected.items())]
with tarfile.open(archive, 'w:gz', compresslevel=6) as tf:
    for name, path in sorted(selected.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        data = path.read_bytes()
        info = tarfile.TarInfo(name); info.size = len(data); info.mtime = 0
        info.uid = info.gid = 0; info.uname = info.gname = ''; info.mode = 0o644
        tf.addfile(info, io.BytesIO(data))
summary = {
    'source_freeze_commit': '716c4408',
    'source_freeze_sha256': sha(base / 'cohesive-freeze.json'),
    'producer_source_commit': freeze['producer_source_commit'],
    'verified_copy_compiler_helper_commit': freeze['verified_copy_helper_source_commit'],
    'upstream': freeze['upstream'],
    'actual_outcomes': [{'case': row['case'], 'classification': row['classification'],
        'named_kernel_failures': row.get('named_kernel_failures', []),
        'strict_same_named_rfl_equation_reject': strict.get(row['case'], {}).get('same_named_declaration_actual_rfl_equation_reject', False),
        'actual_normal34_bytecmp': row.get('actual_normal34_bytecmp', False),
        'pilout_sha256': row.get('pilout_sha256'),
        'generated_sha256': row.get('generated_sha256', {}),
        'all_frozen_inputs_preserved': row.get('source_consumer_executables_and_all_readonly_CI_inputs_unchanged', False)} for row in results],
    'controls_pass': len(results) >= 2 and all(r['classification'] == 'CONTROL_PASS' for r in results[:2]),
    'named_kernel_kills': sum(item['same_named_declaration_actual_rfl_equation_reject'] for item in strict.values()),
    'expected_three_cases': [c['name'] for c in json.loads((base / 'cases-source-spec.json').read_text())['mutations']],
    'complete': len(results) == 5 and all(r['classification'] == 'CONTROL_PASS' for r in results[:2]) and len(strict) == 3 and all(x['same_named_declaration_actual_rfl_equation_reject'] for x in strict.values()),
    'archive': {'path': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'members': members, 'contains_actual_compiler_pilout': True,
        'contains_compiled_objects_cache_or_foreign_links': False,
        'unmodified_upstream_rest': 'Reconstructed from exact frozen immutable b632/NAR/tree member hashes, not duplicated as 5 full Rust trees'},
    'prior_gates_separate': '4fde7ffe BOTH91 actual unfiltered RAW/std3 and old166/69 are not relabelled or rerun by source campaign',
    'held_boundary': ['All actual3Direct sourcePIL messages and originalAIR0 zero/negative invariants unchanged; no source count conversion',
        'No upstream/pin/shared generator/core205/expected consumer proof/model/Root changes',
        'No nativeABI/sourceWorld/Accepted/Root/provider/weightedbus88/#413closure claim'],
    'kill_rule': 'Actual pinned copied PIL compiler → same real GEN LookupWiring → unchanged named decoder kernel failure. Setup/compiler/generator/timeout/unknown-identifier failures are not kills.',
}
(base / 'archive-result.json').write_text(json.dumps(summary, indent=2) + '\n')
out = repo / 'tools/adversarial-mutations/evidence/writebyte/pil412-result-716c4408'
out.mkdir()
for name, path in selected.items():
    if path.suffix == '.pilout' or '/source/' in name:
        continue
    dest = out / name; dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, dest)
shutil.copyfile(base / 'archive-result.json', out / 'archive-result.json')
print(json.dumps({k: summary[k] for k in ['complete','controls_pass','named_kernel_kills','actual_outcomes']}, indent=2))
print(json.dumps({k: summary['archive'][k] for k in ['path','sha256','bytes']}, indent=2))
