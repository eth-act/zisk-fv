#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,tempfile,time
R=Path('/home/cody/zisk-fv-binary-c12-source');B=R/'build/binary-c12-source';LFILE=B/'gate/ready-lease.json';LEXPECTED='e2689c02a0972124f6b2d65b4d871cdb9ae82be5766cc791ad9b9a45f1135ea9';HEAD='0af084581996b2fd4bb2f0db32d286d183858bb0'
SOURCE=Path('/nix/store/ma4jf8qlafpzsiv644h0jxz3pkw69d7w-source');NORMAL=Path('/nix/store/jadjdsv2y69gq6mq6xfiqx5cvas5l82x-zisk-fv-extracted-lean-1.0');COMPILER=Path('/nix/store/09qxd6wcq9w1920sydkh23h8lhr3bikp-compile-mutation/bin/compile-mutation');GEN=Path('/nix/store/6z2qwkmrvdv4ypvynvkxil2ch3vndiy9-pil-extract-0.1.0/bin/pil-extract');NORMAL_CASE=Path('/tmp/byte-direct412-64d6dc5a-v_qtni_g/cases/baseline');TARGET='state-machines/binary/pil/binary.pil';BEFORE='    assumes_padding_operation(op: OP_ADD, padding_size:);';AFTER='    assumes_padding_operation(op: OP_ADD + 1, padding_size:);'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def load(p):return json.loads(Path(p).read_text())
def tree(root):
 out={}
 for p in sorted(Path(root).rglob('*')):
  if p.is_symlink():out[str(p.relative_to(root))]=dict(kind='symlink',target=os.readlink(p))
  elif p.is_file():out[str(p.relative_to(root))]=dict(kind='file',sha256=sha(p),bytes=p.stat().st_size)
 return out
def imports(text):
 out=[]
 for line in text.splitlines():
  match=re.match(r'^(?:public\s+)?import\s+([^\s]+)$',line.strip())
  if match:out.append(match[1])
  elif line.strip() and not line.lstrip().startswith('--'):break
 return out
assert sha(LFILE)==LEXPECTED;L=load(LFILE);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
assert sha(COMPILER)=='62884766bb8c0f4f2726c92a666dada220fb93b4ec9e48c0f04d14772bdb9a3c';assert sha(GEN)=='11b5dd62b8d9dd4425a8ae52228e57a069176c564d4c97f89ca1ef129d82367b';normal_result=load(NORMAL_CASE/'result.json');assert normal_result['stages'][0]['returncode']==0;assert sha(NORMAL_CASE/'actual-source.pilout')=='324dc09b3ca641e721dd726db6f0f39193234695930c04e7bddae7008a535369'
ARENA=Path(tempfile.mkdtemp(prefix='binary-c12-0af08458-',dir='/tmp'));MARKER=B/'genuine-mutation-arena.json';assert not MARKER.exists();dump(MARKER,dict(arena=str(ARENA),source_commit=HEAD,runner_sha256=sha(__file__)))
source_tree=tree(SOURCE);oldtree=load('/home/cody/zisk-fv-tuples-six/build/byte-direct412/source-campaign-freeze.json')['original_source_tree'];assert source_tree==oldtree
raw=(SOURCE/TARGET).read_text();assert raw.count(BEFORE)==1;mutant=ARENA/'opcode-add-one';mutant.mkdir();copy=mutant/'source';subprocess.run(['cp','-a','--reflink=never','--no-preserve=mode',str(SOURCE),str(copy)],check=True);subprocess.run(['chmod','-R','u+w',str(copy)],check=True);assert tree(copy)==source_tree;(copy/TARGET).write_text(raw.replace(BEFORE,AFTER));mutant_tree=tree(copy);expected=dict(source_tree);expected[TARGET]=dict(kind='file',sha256=sha(copy/TARGET),bytes=(copy/TARGET).stat().st_size);assert mutant_tree==expected;dump(mutant/'source-before.json',mutant_tree);dump(ARENA/'normal-source-before.json',source_tree)
sourcefreeze=load(B/'gate/r2/source-freeze.json');sources=sourcefreeze['sources'];assert sourcefreeze['source_commit']==HEAD
for x in sources:assert sha(x['path'])==x['sha256']
rows={x['module']:dict(x) for x in L['canonical_source_import_closure']};generated=['Extraction.Circuit','Extraction.LookupWiring','Extraction.Mem','Extraction.Binary']
for module in generated:
 p=NORMAL/(module.split('.')[-1]+'.lean');assert p.is_file();rows[module]=dict(module=module,path=str(p),sha256=sha(p),direct_imports=imports(p.read_text()),generated=True)
seeds=set(generated);affected=set(seeds)
while True:
 more={m for m,r in rows.items() if any(x in affected for x in r['direct_imports'])};new=affected|more
 if new==affected:break
 affected=new
order=[];seen=set()
def visit(module):
 if module in seen or module not in affected:return
 seen.add(module)
 for dep in rows[module]['direct_imports']:visit(dep)
 order.append(module)
for m in generated+L['modules']:visit(m)
assert set(order)==affected and all(m in affected for m in L['modules']);prefixes=tuple(m.replace('.','/')+'.' for m in affected)
tools=[dict(path=str(p),sha256=sha(p)) for p in [COMPILER,GEN,Path(L['lean']),Path('/nix/store/l1qla9chybhkiw893rqfyj75jx61px0j-pil2-compiler-0.9.0/src/pil.js'),Path('/nix/store/nr0dnrnibq8114xa0i7zr7qg6n05q03g-nodejs-20.20.2/bin/node'),Path('/nix/store/phg76nimggryd3c1pj1kk28948j1hqiv-zisk-fv-extracted-lean-1.0.drv'),Path(__file__),LFILE,NORMAL_CASE/'result.json',NORMAL_CASE/'actual-source.pilout']]
for x in L['source_and_tool_inputs']:tools.append(x)
for p in NORMAL.glob('*.lean'):
 if p.name in ['Circuit.lean','LookupWiring.lean','Mem.lean','Binary.lean']:tools.append(dict(path=str(p),sha256=sha(p)))
freeze=dict(source_commit=HEAD,source_pin='b63274507a040bf9e09d22214df43066e8f80cb7',source_root=str(SOURCE),arena=str(ARENA),consumer_sources=sources,independent_contract=dict(opcode=10,source_bus=5000,full_slots=[10,0,0,0,0,0,0,0,0,0,0],signed_multiplicity='-rawAIR0, ANYp',source_inverse='AIR1, ALL3coeff',challenges='stage2index0/1, ALL3coeff',no_p_count_world_or_Accepted_claim=True),mutation=dict(file=TARGET,before=BEFORE,after=AFTER,mutant_pil_sha256=sha(copy/TARGET),exactly_one_PIL_change_no_Rust_or_pin_edit=True),normal_actual_compiler_provenance=dict(result=str(NORMAL_CASE/'result.json'),sha256=sha(NORMAL_CASE/'result.json'),actual_pilout=str(NORMAL_CASE/'actual-source.pilout'),actual_pilout_sha256=sha(NORMAL_CASE/'actual-source.pilout'),stage=normal_result['stages'][0],reused_verified_actual_compiler_NOT_old_consumer_CI=True),fresh_generated_modules=generated,fresh_import_affected_modules=order,all_fresh_4_names_and_ALL_siblings_excluded=L['modules'],tools=tools,readonly_dependency_lease_sha256=LEXPECTED,resource_contract=dict(Node_MiB=16384,Cargo=2,Lean=2,compiler_concurrency=1,Nix=False),no_RAW_319_or_old_scope_rerun=True)
dump(ARENA/'freeze.json',freeze)
def verify(label):
 assert sha(LFILE)==LEXPECTED;assert subprocess.check_output(['git','-C','/home/cody/zisk-fv-m-inputs','rev-parse','HEAD'],text=True).strip()==L['reserved_M_head']
 for x in tools+sources+L['generated_source_inputs']:assert sha(x['path'])==x['sha256'],x['path']
 for x in L['canonical_source_import_closure']:
  if not x['own']:assert sha(x['path'])==x['sha256'] and sha(x['checked_source'])==x['checked_source_sha256']
 for x in L['readonly_dependency_leaves']:assert sha(x['path'])==x['sha256'],x['path']
 dump(ARENA/(label+'-strict.json'),dict(all_source_compiler_options_runtime_dependency_SOURCES_and_sidecars_exact=True,source_commit=HEAD,lease_sha256=LEXPECTED))
def overlay(case):
 out=case/'lean';out.mkdir();links=[]
 for x in L['readonly_dependency_leaves']:
  rel=Path(x['metadata_link']).relative_to(L['LEAN_PATH'])
  if rel.as_posix().startswith(prefixes):continue
  dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(Path(x['path']).resolve());links.append(dict(link=str(dest),target=x['path'],sha256=x['sha256']))
 for module in affected:assert not any((out/module.replace('.','/')).parent.glob(module.split('.')[-1]+'.*'))
 dump(case/'readonly-overlay.json',links);return out
ENV=dict(os.environ,NODE_OPTIONS='--max-old-space-size=16384',CARGO_BUILD_JOBS='2',LEAN_NUM_THREADS='2')
def run(case,label,command,env):
 log=case/(label+'.log');t=time.monotonic()
 with log.open('w') as f:code=subprocess.run([str(x) for x in command],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 row=dict(command=[str(x) for x in command],returncode=code,seconds=time.monotonic()-t,log=str(log));dump(case/(label+'-result.json'),row);print(json.dumps(row),flush=True)
 if code:print(log.read_text(),flush=True)
 return row
results=[];verify('before');code=1
try:
 for name in ['normal-control','opcode-add-one']:
  case=ARENA/name;case.mkdir(exist_ok=True);out=overlay(case);env=dict(ENV,LEAN_PATH=str(out));gen=case/'generated/Extraction';gen.mkdir(parents=True);result=dict(case=name,source_commit=HEAD,stages=[],kernels=[],classification='INCOMPLETE',fresh4=L['modules']);pilout=NORMAL_CASE/'actual-source.pilout'
  if name=='opcode-add-one':
   assert results[0]['classification']=='FRESH_NEW4_NORMAL_CONTROL_GREEN';pilout=case/'actual-source.pilout';stage=run(case,'01-actual-source-compiler',[COMPILER,copy,pilout],env);result['stages'].append(stage);assert stage['returncode']==0,'ACTUAL_COMPILER_FAILURE_NOT_KILL';assert sha(copy/TARGET)==freeze['mutation']['mutant_pil_sha256']
   for rel,x in mutant_tree.items():
    p=copy/rel
    assert os.readlink(p)==x['target'] if x['kind']=='symlink' else sha(p)==x['sha256'],rel
   dump(case/'source-after.json',tree(copy))
  result['actual_pilout']=str(pilout);result['actual_pilout_sha256']=sha(pilout)
  commands=[[GEN,'circuit-shim','--output',gen/'Circuit.lean'],[GEN,'lookup-wiring','--pilout',pilout,'--output',gen/'LookupWiring.lean']]+[[GEN,'air','--pilout',pilout,'--air',air,'--skip-unsupported','--output',gen/(air+'.lean')] for air in ['Mem','Binary']]
  for i,command in enumerate(commands):
   stage=run(case,'02-generator-'+str(i),command,env);result['stages'].append(stage);assert stage['returncode']==0,'GENERATOR_FAILURE_NOT_KILL'
  result['generated_sha256']={p.name:sha(p) for p in gen.glob('*.lean')};result['normal_bytecmp']={p.name:sha(p)==sha(NORMAL/p.name) for p in gen.glob('*.lean')}
  if name=='normal-control':assert all(result['normal_bytecmp'].values())
  else:
   assert result['normal_bytecmp']['Circuit.lean'] and result['normal_bytecmp']['Mem.lean'];assert not result['normal_bytecmp']['Binary.lean'] and not result['normal_bytecmp']['LookupWiring.lean'];text=(gen/'LookupWiring.lean').read_text();actual=next(x for x in text.splitlines() if x.startswith('def constraint_Binary_12 :'));assert 'Expr.constant "11"' in actual;result['actual_mutated_constraint_Binary_12']=actual
  failed={};named=[]
  for i,module in enumerate(order):
   dependency=next((d for d in rows[module]['direct_imports'] if d in failed),None)
   if dependency is not None:
    failed[module]='BLOCKED_BY_REJECTED_DEPENDENCY';result['kernels'].append(dict(module=module,classification='BLOCKED_BY_REJECTED_DEPENDENCY_NOT_KILL',dependency=dependency,no_stale_CI_reused=True));continue
   source=gen/(module.split('.')[-1]+'.lean') if module in generated else Path(rows[module]['path']);root=case/'generated' if module in generated else R;target=out/(module.replace('.','/')+'.olean');target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();stage=run(case,'03-kernel-'+module.replace('.','-'),[L['lean'],*L['lean_options'],'-R',root,'-o',target,source],env);stage.update(module=module,source=str(source),source_sha256=sha(source));result['kernels'].append(stage)
   if stage['returncode']:
    failed[module]='KERNEL_REJECT'
    if module=='ZiskFv.AirsClean.BinaryPaddingOperations':
     text=Path(stage['log']).read_text();headers=list(re.finditer(r'(?m)^'+re.escape(str(source))+r':(\d+):(\d+): error[^\n]*',text));lines=source.read_text().splitlines()
     for j,h in enumerate(headers):
      line=int(h[1]);decls=[m[1] for s in lines[:line] if (m:=re.match(r'(?:private\s+)?(?:theorem|def)\s+([\w?]+)',s))];block=text[h.start():headers[j+1].start() if j+1<len(headers) else len(text)]
      if decls and decls[-1]=='actual_residual_eq_expected' and ('ofBase 11' in block or 'literal? "11"' in block) and 'ofBase 10' in block and 'view.inverse' in block and 'view.alpha' in block and not re.search(r'unknown identifier|unknown module|object file.*does not exist|maximum.*(heartbeat|recursion)|out of memory|unexpected token',block,re.I):named.append(dict(module=module,declaration=decls[-1],source_sha256=sha(source),actual_kernel_diagnostic=block))
   else:stage.update(object=str(target),object_sha256=sha(target),all_siblings=[dict(path=str(p),sha256=sha(p)) for p in sorted(target.parent.glob(target.stem+'.*')) if p.is_file()])
  if name=='normal-control':assert not failed and all(any(k['module']==m and k.get('returncode')==0 for k in result['kernels']) for m in L['modules']);result['classification']='FRESH_NEW4_NORMAL_CONTROL_GREEN'
  else:
   result['named_actual_typed_residual_rejections']=named;assert named,'NO_NAMED_TYPED_SOURCE_RESIDUAL_REJECTION_NOT_KILL';assert failed.get('ZiskFv.AirsClean.BinaryPaddingOperations')=='KERNEL_REJECT';result['classification']='GENUINE_BINARY_C12_SOURCE_OPCODE_TYPED_RESIDUAL_REJECT'
  dump(case/'result.json',result);results.append(result);dump(ARENA/'results.json',results)
 code=0
finally:
 verify('after');final=dict(complete=code==0,source_commit=HEAD,arena=str(ARENA),fresh_control_green=bool(results and results[0]['classification']=='FRESH_NEW4_NORMAL_CONTROL_GREEN'),genuine_binary_typed_source_reject=bool(len(results)==2 and results[1]['classification']=='GENUINE_BINARY_C12_SOURCE_OPCODE_TYPED_RESIDUAL_REJECT'),results=results,no_old_RAW_Node_campaign_or_Nix_rerun=True);dump(ARENA/'final-result.json',final);dump(B/'genuine-binary-mutation-result.json',dict(path=str(ARENA/'final-result.json'),sha256=sha(ARENA/'final-result.json'),complete=final['complete']));print(json.dumps({k:v for k,v in final.items() if k!='results'}),flush=True)
raise SystemExit(code)
