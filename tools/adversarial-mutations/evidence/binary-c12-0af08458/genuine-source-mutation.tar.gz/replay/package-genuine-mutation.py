#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,tarfile
R=Path('/home/cody/zisk-fv-binary-c12-source');B=R/'build/binary-c12-source'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
marker=load(B/'genuine-binary-mutation-result.json');assert marker['complete'];resultfile=Path(marker['path']);assert sha(resultfile)==marker['sha256'];A=resultfile.parent;final=load(resultfile);assert final['complete'] and final['fresh_control_green'] and final['genuine_binary_typed_source_reject'];freeze=load(A/'freeze.json');normal,mutant=final['results'];assert mutant['named_actual_typed_residual_rejections'];assert freeze['source_commit']=='0af084581996b2fd4bb2f0db32d286d183858bb0';S=Path(freeze['source_root']);files={}
def add(p,arc):
 p=Path(p);assert p.is_file() and not p.is_symlink();assert '.olean' not in p.name and p.suffix!='.ir';files[str(arc)]=p
# Exact consumer bytes, complete source PIL input closure, and actual generated
# outputs/pilout/logs. Never duplicate any compiled CI or runtime cache.
for x in freeze['consumer_sources']:
 p=Path(x['path']);assert sha(p)==x['sha256'];add(p,'consumer-source/'+str(p.relative_to(R)))
for p in S.rglob('*.pil'):add(p,'normal-source-pil/'+str(p.relative_to(S)))
STD=Path('/nix/store/zqhhhzb9rq7gcbv46c1fz4k91pk42yni-source/pil2-components/lib/std/pil')
assert STD.is_dir()
for p in STD.rglob('*.pil'):add(p,'compiler-standard-pil/'+str(p.relative_to(STD)))
add(A/'opcode-add-one/source'/freeze['mutation']['file'],'mutated-source-pil/'+freeze['mutation']['file'])
for p in A.rglob('*'):
 if p.is_file() and not p.is_symlink() and 'lean' not in p.relative_to(A).parts and 'source' not in p.relative_to(A).parts and p.suffix in {'.json','.log','.lean','.pilout'}:add(p,'campaign/'+str(p.relative_to(A)))
normalpilout=Path(normal['actual_pilout']);add(normalpilout,'normal-actual-compiler/actual-source.pilout');normalcase=normalpilout.parent
for name in ['result.json','source-before.json','01-actual-compiler.log']:
 p=normalcase/name
 if p.is_file():add(p,'normal-actual-compiler/'+name)
add(B/'run-genuine-mutation.py','replay/run-genuine-mutation.py');add(Path(__file__),'replay/package-genuine-mutation.py');add(B/'gate/ready-lease.json','lineage/readonly-dependency-lease.json');add(B/'checked4-handback.json','lineage/checked4-baseline-handback.json')
for row in freeze['tools']:
 p=Path(row['path'])
 if p.name=='compile-mutation':add(p,'tool-source/compile-mutation')
 if p.suffix=='.drv':add(p,'tool-source/'+p.name)
summary=dict(source_commit=freeze['source_commit'],arena=str(A),source_pin=freeze['source_pin'],experiment='ONEgenuine isolatedb632productionBinaryc12OP_ADD→OP_ADD+1 sourcecall; independent0afexpectedop10/11slots/-rawp/bus5000unchanged; actual09Node16GiB+6zGEN. NOupstreamRust/pin/proofchanges.',normal_control=normal['classification'],normal_all4_fresh_consumer_kernels={k['module']:k.get('returncode') for k in normal['kernels'] if k['module'] in freeze['all_fresh_4_names_and_ALL_siblings_excluded']},normal_fresh_kernel_count=len(normal['kernels']),mutant_classification=mutant['classification'],named_typed_source_rejections=mutant['named_actual_typed_residual_rejections'],mutant_consumer_status=[k for k in mutant['kernels'] if k['module'] in freeze['all_fresh_4_names_and_ALL_siblings_excluded']],blocked_dependencies_are_NOT_kills=True,baseline319_RAW_NOT_rerun=True,normal_compiler_actual_prior_provenance_reused_not_old_consumer_CI=True,actual_PILout_sha256={x['case']:x['actual_pilout_sha256'] for x in final['results']},actual_generated_sha256={x['case']:x['generated_sha256'] for x in final['results']},freeze_sha256=sha(A/'freeze.json'),final_result_sha256=sha(resultfile),source_expected_model_data_unchanged=True,no_SourceWorld_native_rid_rank_ABI_Accepted_producer_count_actualbalance_or_whole372_claim=True,evidence=[dict(path=k,sha256=sha(p),bytes=p.stat().st_size) for k,p in files.items()])
manifest=B/'genuine-binary-mutation-handback.json';manifest.write_text(json.dumps(summary,indent=2)+'\n');add(manifest,'genuine-binary-mutation-handback.json');archive=A/'binary-c12-genuine-opcode-0af08458-source-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for arc,p in files.items():tf.add(p,arcname=arc,recursive=False)
print(json.dumps(dict(manifest=str(manifest),manifest_sha256=sha(manifest),archive=str(archive),archive_sha256=sha(archive),bytes=archive.stat().st_size,members=len(files),normal_fresh_kernels=len(normal['kernels']),named_rejection_count=len(mutant['named_actual_typed_residual_rejections'])),indent=2))
